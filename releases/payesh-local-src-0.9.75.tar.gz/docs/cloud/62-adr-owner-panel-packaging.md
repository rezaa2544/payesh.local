# ADR‑62 — بسته‌بندی پنل مالک: استثنای WebView فقط برای پنل مالک

> ⛔ **این ADR لغو شده است** (ADR‑126 = [`126-adr-native-owner-panel.md`](126-adr-native-owner-panel.md)، D‑49). پنل مالک اکنون اپ بومی Flutter است (`apps/payesh/owner`). ساخت‌های WebView این سند فقط کنترل منفی CI هستند و منتشر نمی‌شوند. متن زیر سابقهٔ تاریخی است.

| مورد | مقدار |
|---|---|
| شناسه | **ADR‑62** (نام سند؛ ثبت تصمیم در Decision Log = **D‑44** / **O‑27**) |
| وضعیت | **لغوشده (Superseded) با ADR‑126 / D‑49** · ۱۴۰۵/۰۸/۲۲ — دستور مالک: پنل مالک هم باید بومی باشد. پیشین: پذیرفته — تصمیم صریح مالک (O‑27 = گزینهٔ A) · ۱۴۰۵/۰۸/۱۹ |
| ردیف Notion | ۹۹ — پنل مالک · PR‑4 (workflow بسته‌بندی) |
| مبنا | `docs/cloud/61-owner-panel-app-proposal.md` §۴ (O‑27 پیشنهادی، بند ۲، ۳ و ۵)؛ قانون اساسی §۴.۸ و §۱۴ |
| پیاده‌سازی | `.github/workflows/owner-panel.yml` · `apps/owner-panel/{android,desktop,installer,scripts}` · `apps/owner-panel/tests/packaging.test.js` |

## 1. تصمیم

مالک گزینهٔ A سند ۶۱ را برای O‑27 انتخاب کرد: پنل مالک سه خروجی جدا دارد که هر سه یک پوستهٔ **نازک** روی همان SPA ایستای `apps/owner-panel/web` (PR‑3) هستند:

| خروجی (نام ثابت) | ساخت | پوسته |
|---|---|---|
| `payesh-owner-setup.exe` | Inno Setup روی `windows-latest` | WinForms + **WebView2** (`PayeshOwner.exe`) |
| `payesh-owner.apk` | Gradle/AGP روی `ubuntu-latest` | Activity + **Android WebView** |
| `payesh-owner-web.zip` | اسکریپت قطعی Node | SPA + `server/static-server.js` (بدون وابستگی) |
| `SHA256SUMS` | گیت `owner-gate` | قالب `sha256sum` |

## 2. دامنهٔ استثنا (و آنچه تغییر نمی‌کند)

- **استثنای WebView فقط برای ابزار مدیریتی مالک پلتفرم است.** هیچ کاربر مدرسه این اپ را نصب نمی‌کند.
- **ردیف ۶۳ و دروازهٔ استقلال بومی کلاینت مدرسه تغییر نمی‌کند و تضعیف نمی‌شود.** این ADR هیچ معیار، آستانه یا فهرست مجاز آن دروازه را عوض نمی‌کند و نمی‌تواند به‌عنوان سابقه برای اپ مدرسه استناد شود.
- O‑09 (پشتهٔ کلاینت مدرسه) **باز می‌ماند**؛ این تصمیم پاسخ آن نیست.
- O‑25 / ADR‑43 (انتخاب فناوری کلاینت، ردیف ۹۰) **باز می‌ماند**؛ D‑43 برای آن رزرو است.
- فایل‌های اپ مدرسه (`desktop/`, `install/android/`, `installer/payesh.iss`, `.github/workflows/build.yml`) در این PR تغییر نکرده‌اند.

## 3. قیود امنیتی پوسته (آزمون می‌شوند)

1. **قفل مبدأ:** مبدأ سرور در اولین اجرا از کاربر پرسیده می‌شود؛ فقط `https://host[:port]` (بدون مسیر/پرس‌وجو/userinfo). استثنا فقط `http://localhost` و `http://127.0.0.1` برای توسعه. هر ناوبری، frame، پنجرهٔ جدید یا دانلود خارج از مبدأ مسدود است (`OriginPolicy` در Java و C#، هر دو با ۲۱ مورد آزمون یکسان).
2. **بدون پل JS:** Android بدون `addJavascriptInterface`؛ WebView2 با `AreHostObjectsAllowed=false` و `IsWebMessageEnabled=false`.
3. **TLS:** خطای گواهی ⇒ لغو (`handler.cancel()` / `ServerCertificateErrorAction.Cancel`)؛ Android: `cleartextTrafficPermitted="false"` جز loopback، `MIXED_CONTENT_NEVER_ALLOW`.
4. **بدون آدرس/توکن/کلید سخت‌کد.** هیچ URL سرور در APK یا exe پخته نمی‌شود (CI رشته‌های dex/arsc را می‌سنجد).
5. Android: `allowBackup=false`، فقط مجوز `INTERNET`، `debuggable=false`، `FLAG_SECURE`، بدون دسترسی فایل/محتوا. ویندوز: DevTools خاموش، مجوزها (دوربین/مکان/…) رد، autofill/ذخیرهٔ رمز خاموش، نصب بدون UAC فقط برای کاربر جاری.

## 4. شناسه‌های جدا از اپ مدرسه

| مورد | پنل مالک | اپ مدرسه |
|---|---|---|
| Android `applicationId`/`namespace` | `ir.payesh.owner` | `ir.payesh.local` |
| Inno `AppId` | `{20AE76FD-560D-41ED-B6F5-7F66F3308129}` | `{7C4E2A51-9F3B-4E7A-9C21-5B8A1D3E6F02}` |
| پوشهٔ نصب | `{localappdata}\Programs\PayeshOwner` | `{autopf}\Payesh` |
| میان‌بر / نام برنامه | «پنل مالک پایش» | «پایش-لوکال» |
| فایل اجرایی | `PayeshOwner.exe` | `Payesh.exe` |
| مانیفست ویندوز | `Payesh.Owner.Desktop` | `Payesh.Local.Desktop` |
| دادهٔ کاربر | `%LOCALAPPDATA%\PayeshOwner` | جدا |

## 5. امضا و انتشار

- نام Secretها (فقط نام؛ مقدار هرگز در مخزن/گزارش نمی‌آید): Android `PAYESH_OWNER_KEYSTORE_B64`, `PAYESH_OWNER_KEYSTORE_PASS`, `PAYESH_OWNER_KEY_ALIAS`, `PAYESH_OWNER_KEY_PASS`؛ ویندوز `PAYESH_OWNER_WIN_PFX_B64`, `PAYESH_OWNER_WIN_PFX_PASS`. این‌ها عمداً با Secretهای اپ مدرسه (`PAYESH_KEYSTORE_*`) مشترک نیستند.
- **بدون Secret:** exe و APK ساخته می‌شوند ولی «امضانشده / فقط آزمایشی» برچسب می‌خورند؛ CI ثابت می‌کند واقعاً امضا ندارند (`apksigner verify` باید شکست بخورد؛ Authenticode باید `NotSigned` باشد) و **هرگز منتشر نمی‌شوند** — اصلاح‌شده در §9: APK همچنان منتشر نمی‌شود؛ exe امضانشده با برچسب، SHA256 و توضیح SmartScreen منتشر می‌شود.
- **Secret موجود ولی نامعتبر ⇒ قرمز.** امضاشده یعنی: APK با v2+v3 و اثر انگشت گواهی؛ exe با `Get-AuthenticodeSignature = Valid`. گیت هر ادعای «signed» بدون این شاهد را رد می‌کند.
- انتشار فقط روی `main` و فقط در prerelease `owner-continuous` با عنوان «انتشار رسمی نیست»: بستهٔ وب و `SHA256SUMS` همیشه؛ exe/APK فقط اگر امضای تأییدشده دارند (وگرنه asset قبلی حذف می‌شود). همهٔ خروجی‌ها، امضاشده یا نه، در artifact آزمایشی `payesh-owner-test-only` می‌مانند.

## 6. گیت (fail-closed)

`apps/owner-panel/scripts/check-owner-artifacts.js` در job `owner-gate`: نبودن هر خروجی، فایل خالی/کوچک، نوع فایل نادرست، ناهمخوانی sha256 با meta همان job، ساختار ناقص (APK بدون dex/manifest؛ zip بدون index/app/static-server یا با commit دیگر)، ادعای امضای بی‌شاهد، یا فایل ناشناخته ⇒ **قرمز**. شکست هر یک از سه job ساخت هم گیت را قرمز می‌کند. خودآزمایی گیت ۱۵ کنترل منفی دارد.

## 7. آنچه این ADR اثبات نمی‌کند

- نصب و اجرای واقعی روی دستگاه مالک (ویندوز/Android): **OWNER / تأییدنشده [?]**. فقط نصب/حذف بی‌صدا روی runner ویندوز CI اجرا می‌شود.
- امضای واقعی: تا تنظیم Secretها توسط مالک **وجود ندارد**؛ هیچ ادعای امضا یا انتشار رسمی نمی‌شود.
- ورود واقعی روی سرور تولیدی مالک: **OWNER / تأییدنشده [?]** — صادرکننده (D‑45، §8) در مخزن و آزمون‌ها هست؛ اجرای migration 004 و ساخت حساب نخست روی سرور با مالک است.
- امنیت: **UNKNOWN** تا پنتست انسانی مستقل (D‑41).

## 8. افزودهٔ D‑45 — صادرکنندهٔ ورود (O‑17 = گزینهٔ A، ۱۴۰۵/۰۸/۱۹)

تصمیم صریح مالک: رمز + TOTP برای همهٔ اپراتورها اجباری؛ بدون محدودیت IP؛ حداکثر ۳ اپراتور؛ حساب نخست با اسکریپت روی سرور.

| جزء | پیاده‌سازی |
|---|---|
| مسیر | `POST /api/platform/v1/auth/login` (`login_id`، `password`، `totp`) ⇒ توکن `platform.v1` با عمر ۸ ساعت و `amr=[pwd,otp]`؛ نقش از جدول خوانده می‌شود |
| داده | `db/migrations/owner-panel/004_owner_login.{up,down}.sql`: `platform_credentials` (بدون هیچ grant جدولی به runtime)، `login_event` (append-only)، `login_lookup` (فقط تطبیق دقیق)، `record_login_attempt` (مرجع نهایی تکرار/قفل) |
| رمز | scrypt N=2^15, r=8, p=1، نمک ۱۶ بایتی؛ CHECK دیتابیس رمز ساده را رد می‌کند؛ حداقل ۱۲ نویسه |
| TOTP | RFC 6238 (SHA1، ۳۰ ثانیه، ۶ رقم، پنجرهٔ ±۱)؛ گام پذیرفته‌شده باید از گام قبلی بزرگ‌تر باشد ⇒ تکرار رد |
| قفل/سهمیه | ۵ شکست پیاپی ⇒ قفل ۱۵ دقیقه؛ سهمیهٔ ۱۰ تلاش در ۵ دقیقه برای هر شناسه و هر IP (جدول `api_rate_limit`) |
| سقف | trigger با قفل جدول: بیش از ۳ ردیف `platform_credentials` ⇒ `23514` |
| ساخت حساب | `apps/owner-panel/scripts/create-operator.js` روی سرور با `PAYESH_PLATFORM_MIGRATION_URL`؛ رمز بدون نمایش پرسیده می‌شود؛ فقط URI `otpauth://` یک‌بار چاپ می‌شود |
| پاسخ شکست | برای حساب ناموجود/رمز/کد/تکرار/قفل/غیرفعال یکسان `401 invalid_credentials`؛ بدون migration 004 ⇒ `501 login_not_installed` (fail-closed) |
| آزمون | `apps/owner-panel/tests/owner-login.test.js` (بردارهای RFC، ≥۳۰ کنترل منفی، جهش‌های تکرار/سقف/قفل) + ورود سرتاسری در `owner-spa.test.js` |

باقی‌مانده: راز TOTP در دیتابیس رمزنگاری جداگانه ندارد (دسترسی فقط نقش مالک migration)؛ امنیت **UNKNOWN** تا پنتست انسانی مستقل (D‑41).

## 9. افزودهٔ مالک بر D‑44 — انتشار exe امضانشده و لینک‌های README (ردیف ۱۰۰، ۱۴۰۵/۰۸/۱۹)

تصمیم صریح مالک: کلید امضای Android روی PC مالک ساخته و فقط از مسیر امن در GitHub Secrets گذاشته می‌شود؛ **APK فقط پس از امضای معتبر** منتشر می‌شود؛ **exe بدون امضا با SHA256 و توضیح محدودیت SmartScreen** منتشر می‌شود؛ بستهٔ وب هم ساخته می‌شود؛ هیچ خروجی ناموفق یا امضانشده‌ای «انتشار معتبر» معرفی نمی‌شود.

| جزء | پیاده‌سازی |
|---|---|
| گیت | `check-owner-artifacts.js`: `release_eligible` = وب همیشه؛ exe همیشه، با `signing=unsigned-smartscreen-warning` اگر امضا نشده؛ APK فقط `signed-verified`. `owner-artifacts-status.json` فهرست `published_unsigned` را دارد |
| انتشار | `owner-panel.yml` فقط روی main و فقط prerelease `owner-continuous`؛ یادداشت انتشار هر بار به‌روز می‌شود (هشدار مالک، SmartScreen، روش مقایسهٔ SHA256) |
| README | بلوک بالای صفحه با چهار لینک مستقیم `releases/download/owner-continuous/{payesh-owner-setup.exe,payesh-owner.apk,payesh-owner-web.zip,SHA256SUMS}` و هشدار «نصبی فقط برای مالک؛ تست روی دستگاه واقعی هنوز تأیید نشده [?]» |
| گیت هم‌ترازی | قاعدهٔ `P6_readme_links` در `apps/owner-panel/tests/packaging.test.js` (در `npm test` و workflow): نام لینک‌ها = نام خروجی‌های حلقهٔ انتشار + `SHA256SUMS`؛ جدول دانلود مدرسه دست‌نخورده؛ ۶ جهش منفی |

ردیف ۶۳ و الزام بومی‌بودن اپ مدرسه تغییر نمی‌کند. امضای Authenticode exe تا تنظیم `PAYESH_OWNER_WIN_PFX_*` توسط مالک وجود ندارد.

