# ردیف ۲۱۱ — گزارش آزمون‌های DP (Helper توزیعی)

تاریخ اجرا: ۲۰۲۶-۱۱-۲۸ — شاخهٔ `feat/helper-dp-205-211`

## نتایج (اجرای واقعی روی ویندوز صاحب مخزن)
- `node tests/helper-jobs-130.js` ⇒ `HELPER-JOBS-130-OK checks=12` (پسرفت صفر در قرارداد v1).
- `node tests/helper-dp-211.js` ⇒ `HELPER-DP-211-OK checks=8`:
  1. بردارهای v2: حضور/کار + سازگاری v1 (۲۰۵)
  2. کاتالوگ + رد کلاس دادهٔ نامجاز برای بیرونی/مدرسهٔ دیگر (۲۰۸)
  3. توکن مدرسه: صدور/اعتبارسنجی/رد متقابل (۲۰۹)
  4. انتخاب بهترین executor (۲۰۵)
  5. polling تطبیقی/backoff (۲۱۰)
  6. e2e روی صندوقچهٔ stub: executor نوع actions کار واقعی را lease و کامل می‌کند (۲۰۶/۲۰۷)
  7. **کشتن executor وسط کار**: اجارهٔ منقضی توسط دیگری برداشته می‌شود؛ اجرای دوم کار را دوباره اعمال نمی‌کند (idempotency)
  8. **بدون هیچ executor**: failover محلی `by: local` سالم می‌ماند (قانون طلایی)
- `tools/helper-executor/run.mjs` بدون Secret ⇒ سبز با `configured:false` و نام Secretهای غایب (هرگز مقدار خواسته/چاپ نمی‌شود).
- Worker: `fetch('/health')` محلی ⇒ ۲۰۰ `ok:true`؛ مسیر executor فقط با Secret فعال می‌شود.

## مرز صادقانه
- Flutter/Dart روی ماشین ویندوز این اجرا نصب نیست؛ `helper_v2_test.dart` نوشته شد ولی اجرا نشد (لازم است روی محیط Flutter اجرا شود).
- Secretهای Worker ‏(۲۰۶) و Actions ‏(۲۰۷) باید از پنل‌ها تنظیم شوند؛ تا آن لحظه هر دو `configured:false` و صف روی محلی/مالک کار می‌کند.
