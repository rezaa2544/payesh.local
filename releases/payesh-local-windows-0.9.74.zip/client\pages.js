/* ═══════════════════════════════════════════════════════════════════
   پایش-لوکال — نماها (بدون چارچوب)
   هر تابع یک رشتهٔ HTML برمی‌گرداند. کنش‌ها با data-act مدیریت می‌شوند.
   ═══════════════════════════════════════════════════════════════════ */
'use strict';

const PAGES = {};

/* ردیف ۱۷۹: طرح «مینیمال حرفه‌ای» با پوستهٔ روشن / تاریک / سیستم به انتخاب کاربر.
   انتخاب در localStorage «payesh.theme» می‌ماند (بدون آن = پیرو سیستم‌عامل) و پیش از ساخته
   شدن صفحه روی <html data-theme> می‌نشیند تا رنگ اشتباه چشمک نزند. */
const THEME_KEY = 'payesh.theme';
const THEME_LABEL = { system: 'پوسته: سیستم', light: 'پوسته: روشن', dark: 'پوسته: تاریک' };
const THEME_ICON = { system: '🌓', light: '☀️', dark: '🌙' };
function themeMode() {
  try {
    const v = localStorage.getItem(THEME_KEY);
    return v === 'light' || v === 'dark' ? v : 'system';
  } catch (e) { return 'system'; }
}
function applyTheme(mode) {
  if (typeof document === 'undefined' || !document.documentElement) return;
  const el = document.documentElement;
  if (mode === 'light' || mode === 'dark') el.setAttribute('data-theme', mode);
  else el.removeAttribute('data-theme');
}
function nextThemeMode(mode) { return { system: 'light', light: 'dark', dark: 'system' }[mode] || 'light'; }
function setThemeMode(mode) {
  try {
    if (mode === 'light' || mode === 'dark') localStorage.setItem(THEME_KEY, mode);
    else localStorage.removeItem(THEME_KEY);
  } catch (e) { /* حالت خصوصی مرورگر: فقط همین صفحه */ }
  applyTheme(mode);
}
function themeButtonHtml(extraClass) {
  const m = themeMode();
  return `<button class="btn sm ghost ${extraClass || ''}" data-act="theme-cycle" data-theme-mode="${m}" title="${THEME_LABEL[m]}">${THEME_ICON[m]} ${THEME_LABEL[m]}</button>`;
}
try { applyTheme(themeMode()); } catch (e) { /* محیط آزمون بدون DOM */ }
/* ردیف ۱۶۱: پیوندهای دانلود همیشه مستقیم به خودِ فایل‌اند، نه صفحهٔ انتشار یا صفحهٔ معرفی */
const NATIVE_APK_URL = 'https://github.com/rezaa2544/payesh.local/releases/download/native-continuous/payesh-native.apk';
const TAILSCALE_WIN_URL = 'https://pkgs.tailscale.com/stable/tailscale-setup-latest.exe';
window.PAGES = PAGES;

/* ── اجزای کوچک ─────────────────────────────────────────────────── */
/* ردیف ۱۶۶: زنگ‌های شیفت این هفته (schedule.js)؛ بی آن، همهٔ زنگ‌ها */
function pageBellRows() { return typeof schedBellRows === 'function' ? schedBellRows() : list('bell_schedules'); }

function pageHead(title, sub, actions) {
  return `<div class="topbar">
    <div><h2>${esc(title)}</h2>${sub ? `<div class="small muted">${esc(sub)}</div>` : ''}</div>
    <div class="row no-print">${actions || ''}</div>
  </div>`;
}
/* ردیف ۱۸۵: کارت‌های صفحه ستونی کنار هم (styles.css .flow)؛ داشبورد مدیر چیدمان خودش را دارد. */
function flowHtml(view) {
  return /dashboard-topbar/.test(String(view || '')) ? view : `<div class="flow">${view}</div>`;
}
function card(body, cls = '') { return `<div class="card ${cls}">${body}</div>`; }
function empty(msg) { return `<div class="card center muted" style="padding:26px">${esc(msg)}</div>`; }
function badge(text, kind = '') { return `<span class="badge ${kind}">${esc(text)}</span>`; }

const ROLE_FA = {
  manager: 'مدیر', vice: 'معاون', teacher: 'دبیر', parent: 'ولی', student: 'دانش‌آموز',
  counselor: 'مشاور', staff: 'کارمند', office: 'اجرایی', guard: 'نگهبان',
};

/* حالت گوشی/بدون سرور (در app.js تعریف می‌شود) */
function isPhoneMode() { return typeof PHONE_MODE !== 'undefined' && PHONE_MODE; }

function navConfig(role) {
  const base = [];
  if (role === 'manager') {
    base.push(['home', '🏠', 'داشبورد'], ['users', '👥', 'کاربران'], ['followup', '⚠️', 'پیگیری'], ['classes', '🏛️', 'کلاس‌ها'],
      ['schedule', '🗓️', 'برنامه'], ['attendance-report', '✅', 'حضور'], ['leaves', '📨', 'مرخصی‌ها'], ['reports', '📑', 'گزارش‌ها'], ['cqueue', '📨', 'ارجاع مشاور'],
      ['announcements', '📢', 'اطلاعیه‌ها'], ['health', '🩺', 'سلامت'], ['network', '🌐', 'شبکه'],
      ['cloud', '☁️', 'حافظهٔ ابری'], ['system', '⚙️', 'سیستم']);
  } else if (role === 'teacher') {
    base.push(['home', '🏠', 'امروز'], ['schedule', '🗓️', 'برنامه'], ['attendance', '✅', 'حضور'], ['grades', '📝', 'نمره'],
      ['students', '👥', 'دانش‌آموزان'], ['announcements', '📢', 'اطلاعیه‌ها'], ['system', '⚙️', 'سیستم']);
  } else if (role === 'parent') {
    base.push(['home', '👨‍👩‍👦', 'فرزندان'], ['schedule', '🗓️', 'برنامه'], ['leaves', '📨', 'مرخصی'], ['announcements', '📢', 'اطلاعیه‌ها'], ['system', '⚙️', 'سیستم']);
  } else if (role === 'student') {
    base.push(['home', '🏠', 'خانه'], ['schedule', '🗓️', 'برنامه'], ['record', '📁', 'پرونده'], ['announcements', '📢', 'اطلاعیه‌ها'], ['system', '⚙️', 'سیستم']);
  } else if (role === 'counselor') {
    /* ردیف ۱۸۷ (تعریفِ p2): خانهٔ مشاور «صف ارجاع» است */
    base.push(['cqueue', '📨', 'صف ارجاع'], ['home', '🏠', 'خانه'], ['announcements', '📢', 'اطلاعیه‌ها'], ['system', '⚙️', 'سیستم']);
  } else {
    base.push(['home', '🏠', 'خانه'], ['announcements', '📢', 'اطلاعیه‌ها'], ['system', '⚙️', 'سیستم']);
  }
  /* روی گوشی «شبکه» و «حافظهٔ ابری» معنا ندارد (سروری در کار نیست) */
  if (isPhoneMode()) return base.filter(([r]) => r !== 'network' && r !== 'cloud');
  return base;
}

/* نوار همیشگیِ بالای برنامه: نسخه + چراغ وضعیت (سبز = به‌روز، کهربایی = نسخهٔ تازه،
   آبی = در حال دانلود) — همان چیزی که در نسخهٔ کامل بالای صفحه دیده می‌شود. */
function updateBarHtml() {
  const cur = (S.server && S.server.version) || (typeof CLIENT_VERSION !== 'undefined' ? CLIENT_VERSION : '');
  const st = S.upd || {};
  const busy = st.status === 'downloading' || st.status === 'installing';
  const ready = st.status === 'ready';
  const avail = !!(S.remote && S.remote.available);
  const latest = st.latest || (S.remote && (S.remote.remote_version || S.remote.version)) || '';
  const dot = busy ? '#2563eb' : (ready || avail) ? '#f59e0b' : '#16a34a';
  const text = busy ? ('در حال دانلود ' + fa(st.percent || 0) + '٪')
    : ready ? ('نسخهٔ ' + esc(latest) + ' آمادهٔ نصب است')
    : avail ? ('نسخهٔ تازهٔ ' + esc(latest) + ' موجود است')
    : 'برنامه به‌روز است';
  const isManager = S.role === 'manager';
  const bundled = typeof BUNDLED !== 'undefined' && BUNDLED;
  if (busy || ready) {
    const body = updateBarBody();
    if (body) return body;
  }
  const calm = !busy && !ready && !avail;
  return `<div class="updbar${calm ? ' is-ok' : ''}" id="update-bar" dir="rtl">
    <span class="upd-dot" style="background:${dot}" title="${esc(text)}"></span>
    <span class="small">نسخهٔ <b class="ltr">${esc(cur)}</b><span class="${calm ? 'sr-only' : ''}"> — ${text}</span></span>
    ${calm ? `<button type="button" class="upd-new" data-act="whats-new-all" title="همهٔ تغییرات نسخه‌ها">· تازه‌ها</button>` : ''}
    ${isManager && !bundled && (avail || ready)
      ? `<button class="btn xs primary" data-act="${ready ? 'update-install' : 'update-now'}">${ready ? 'نصب و راه‌اندازی دوباره' : 'دانلود و نصب'}</button>`
      : ''}
    ${isManager && !bundled && !avail && !ready && !busy
      ? `<button class="icon-b xs" data-act="update-recheck" title="بررسی آپدیت" aria-label="بررسی آپدیت">${typeof d2Ico === 'function' ? d2Ico('sync') : '↻'}</button>`
      : ''}
  </div>`;
}

/* Row 180 (طرح ۲ مو به مو): جستجوی سریع نوار کناری — مدیر در «کاربران»،
   دبیر/معاون/مشاور در «دانش‌آموزان»؛ Ctrl K کادر را فعال می‌کند. */
function sideSearchRoute(role) {
  if (role === 'manager') return 'users';
  return navConfig(role).some(([r]) => r === 'students') ? 'students' : '';
}
function sideSearchHtml(role) {
  const route = sideSearchRoute(role);
  if (!route) return '';
  return `<label class="d2-search" for="side-q">${typeof d2Ico === 'function' ? d2Ico('search') : ''}<input id="side-q" type="search" data-focus-key="side-q" data-side-search="${route}" placeholder="${route === 'users' ? 'جستجوی دانش‌آموز…' : 'جستجوی دانش‌آموز…'}" value="${esc(S.q || '')}" autocomplete="off" aria-label="جستجو"><kbd class="ltr">Ctrl K</kbd></label>`;
}
/* وقتی برنامه به‌روز است، نوار نسخه یک برچسب کوچک در پایین نوار کناری است
   (طرح: «نسخه · تازه‌ها»)؛ فقط نسخهٔ تازه/دانلود/آمادهٔ نصب بالای صفحه می‌آید. */
function updateBarIsCalm(html) { return /class="updbar is-ok"/.test(html || ''); }

function shellHtml(view) {
  const role = S.role || 'student';
  const nav = navConfig(role);
  const cloudDot = role === 'manager' && !(S.server && S.server.cloudReady) && !(S.server && S.server.publicUrl);
  const mkNav = (mobile) => nav.map(([r, ico, label]) => {
    const on = S.route === r || (r === 'home' && ['home', 'child', 'record'].includes(S.route));
    const dot = r === 'cloud' && cloudDot ? '<span class="d2-dot" title="حافظهٔ ابری هنوز تنظیم نشده" aria-label="نیاز به تنظیم"></span>' : '';
    return mobile
      ? `<a class="bn ${on ? 'on' : ''}" href="#/${r}"><span class="ico">${ico}</span>${esc(label)}</a>`
      : `<a class="navitem ${on ? 'on' : ''}" href="#/${r}"><span>${ico}</span>${esc(label)}${dot}</a>`;
  }).join('');
  const upd = updateBarHtml();
  const calm = updateBarIsCalm(upd);
  return `
  <div class="shell">
    <aside class="sidebar">
      <div class="brand d2-brand"><img class="d2-logo brand-mark" src="/icons/logo-mark.png" alt="پایش"><span class="d2-bn"><b>${esc((S.server.school && S.server.school.name) || 'پایش-لوکال')}</b><small>${esc(role === 'manager' ? 'مدیر مدرسه' : (ROLE_FA[role] || role))}</small></span></div>
      ${sideSearchHtml(role)}
      <nav class="d2-nav">${mkNav(false)}</nav>
      <div class="d2-foot">
        ${calm ? upd : ''}
        <div class="d2-acc"><span class="avatar">${esc(String(S.user ? S.user.name : '').trim().charAt(0))}</span><span class="d2-bn"><b>${esc(S.user ? S.user.name : '')}</b><small>${esc(ROLE_FA[role] || role)}</small></span></div>
        <div class="d2-theme">${themeButtonHtml('theme-side')}</div>
      </div>
    </aside>
    <main class="main">${canonicalBarHtml()}${calm ? '' : upd}${offlineBarHtml()}${flowHtml(view)}</main>
  </div>
  <nav class="bottomnav">${mkNav(true)}</nav>`;
}

/* نوار آدرس عمومی:
   اگر آدرس ثابتِ کارآمدی ثبت نشده، مدیر یک یادآوری کوچک می‌بیند (قابل بستن). */
function canonicalBarHtml() {
  /* روی گوشی هیچ آدرس/شبکه‌ای در کار نیست — هیچ نواری نشان نمی‌دهیم */
  if (typeof PHONE_MODE !== 'undefined' && PHONE_MODE) return '';
  const pub = S.server && S.server.publicUrl;
  if (pub) {
    try { if (location.origin === new URL(pub).origin) return ''; } catch (e) { return ''; }
    if (localStorage.getItem('payesh.originbar.off') === pub) return '';
    return `<div class="banner warn" id="origin-bar">
      <div>🌐 آدرس رسمی برنامه این است؛ با همان هم می‌توانید از هر اینترنتی وارد شوید:
        <span class="ltr small" style="font-weight:700">${esc(pub.replace(/^https?:\/\//, ''))}</span></div>
      <button class="btn sm primary" data-act="transfer">انتقال به آدرس رسمی</button>
    </div>`;
  }
  if (S.role !== 'manager') return '';
  /* هیچ پیام «فقط شبکهٔ مدرسه» نداریم: هر دستگاه خودش کار می‌کند و حافظهٔ
     مشترک ابری همه‌جا در دسترس است. فقط اگر خودِ حافظه تنظیم نشده باشد،
     یک یادآوری کوچک با دکمهٔ تنظیم خودکار نشان می‌دهیم. */
  if (S.server && S.server.cloudReady) return '';
  /* طرح ۲: بالای داشبورد هیچ نواری نیست؛ یادآوری فقط در صفحهٔ «حافظهٔ ابری»
     (و یک نقطهٔ کوچک کنار همان گزینه در نوار کناری). */
  if (S.route !== 'cloud') return '';
  if (localStorage.getItem('payesh.originbar.off') === 'none') return '';
  return `<div class="banner warn" id="origin-bar">
    <div>☁️ حافظهٔ مشترک ابری هنوز آماده نیست — با یک کلیک خودکار تنظیم می‌شود؛ بعد از آن گوشی و خانه هم به همه‌چیز دسترسی دارند.</div>
    <button class="btn sm primary" data-act="cloud-phone-check">تنظیم خودکار</button>
    <button class="btn sm ghost" data-act="originbar-off">بستن</button>
  </div>`;
}

/* نوار آپدیت:
   ۱) اگر نسخهٔ تازه‌ای در مخزن منتشر شده (S.remote) — مدیر با یک کلیک همان
      بخش‌های تغییرکرده را روی خود سیستم می‌نشاند.
   ۲) وگرنه اگر فایل‌های همین دستگاه با سرور فرق دارند (S.update) — دلتای
      مرورگر اعمال می‌شود. */
function updateBarBody() {
  /* در نسخهٔ بسته‌بندی‌شده (APK) فایل‌ها داخل خود برنامه‌اند؛ آپدیت با نصب APK تازه است */
  if (typeof BUNDLED !== 'undefined' && BUNDLED) return '';
  const r = S.remote;
  const st = S.upd;
  /* حین دانلود، نوار پیشرفت نشان داده می‌شود (مثل k3-reval) */
  if (st && (st.status === 'downloading' || st.status === 'installing')) {
    const pct = Math.max(0, Math.min(100, Number(st.percent) || 0));
    return `<div class="banner info" id="update-bar">
      <div style="flex:1;min-width:200px">
        <div>⬇️ ${st.status === 'installing' ? 'در حال نصب نسخهٔ' : 'در حال دانلود نسخهٔ'} <b>${esc(st.latest || '')}</b>
          ${st.totalKb ? ' — ' + fa(st.receivedKb || 0) + ' از ' + fa(st.totalKb) + ' کیلوبایت' : ''}</div>
        <div style="height:8px;background:#e5e7eb;border-radius:999px;overflow:hidden;margin-top:6px">
          <div style="width:${pct}%;height:100%;background:#6366f1;transition:width .3s"></div></div>
      </div>
      <span class="small" style="font-weight:700">${fa(pct)}٪</span>
    </div>`;
  }
  if (st && st.status === 'ready') {
    return `<div class="banner info" id="update-bar">
      <div>✅ نسخهٔ <b>${esc(st.latest)}</b> دانلود شد و آمادهٔ نصب است${st.mode === 'patch' && st.savedMb ? ` — ${fa(st.savedMb)} مگابایت کم‌تر از نصب کامل` : ''}</div>
      <button class="btn sm primary" data-act="update-install">نصب و راه‌اندازی دوباره</button>
      <button class="btn sm ghost" data-act="update-later">بعداً</button>
    </div>`;
  }
  if (r && r.available && !isUpdateDismissed(r.remote_version)) {
    const kb = Math.max(1, Math.round((r.total_size || 0) / 1024));
    const n = (r.changed || []).length;
    const bits = [];
    if (r.counts && r.counts.client) bits.push(`${fa(r.counts.client)} فایل رابط`);
    if (r.counts && r.counts.server) bits.push(`${fa(r.counts.server)} فایل برنامه`);
    const saved = st && st.mode === 'patch' && st.savedMb ? ` · ${fa(st.savedMb)} مگابایت کم‌تر از نصب کامل` : '';
    return `<div class="banner info" id="update-bar">
      <div>🎁 نسخهٔ <b>${esc(r.remote_version)}</b> منتشر شده — فقط ${fa(n)} فایل تغییر کرده (${fa(kb)} کیلوبایت${bits.length ? ' · ' + bits.join('، ') : ''})${saved}</div>
      <button class="btn sm primary" data-act="update-now">دانلود و نصب (یک کلیک)</button>
      <button class="btn sm ghost" data-act="update-later">بعداً</button>
    </div>`;
  }
  if (!S.update) return '';
  const n = (S.update.changed || []).length;
  const kb = Math.round((S.update.total_size || 0) / 1024);
  return `<div class="banner info" id="update-bar">
    <div>🎁 نسخهٔ <b>${esc(S.update.version)}</b> آماده است — ${fa(n)} فایل تغییر کرده (${fa(kb)} کیلوبایت)</div>
    <button class="btn sm primary" data-act="update-apply">به‌روزرسانی</button>
  </div>`;
}
function isUpdateDismissed(version) {
  try { return localStorage.getItem('payesh.upd.dismiss') === String(version); } catch (e) { return false; }
}
function offlineBarHtml() {
  if (S.online) return '';
  const q = S.queue.length;
  if (S.offline) {
    return `<div class="banner warn">📴 سیستم مدرسه در دسترس نیست — همهٔ فایل‌های برنامه روی همین دستگاه است و آخرین اطلاعات نمایش داده می‌شود.
      ${q ? `${fa(q)} تغییر در صف مانده و با اولین اتصال ارسال می‌شود.` : ''}
      <button class="btn sm ghost" data-act="retry">اتصال دوباره</button></div>`;
  }
  return `<div class="banner warn">📴 آفلاین هستید — برنامه کار می‌کند و ${fa(q)} تغییر در صف است. با وصل شدن شبکه خودکار ارسال می‌شود.</div>`;
}
function updateTopChrome() {
  const bar = $('#update-bar');
  const html = updateBarHtml();
  const calm = updateBarIsCalm(html);
  const foot = $('.sidebar .d2-foot');
  const inFoot = !!(bar && foot && foot.contains(bar));
  if (bar && (!html || inFoot === (calm && !!foot))) { bar.outerHTML = html || '<div id="update-bar" hidden></div>'; return; }
  if (bar) bar.remove();
  if (!html) return;
  if (calm && foot) { foot.insertAdjacentHTML('afterbegin', html); return; }
  const main = $('.main');
  if (main) main.insertAdjacentHTML('afterbegin', html);
}


/* جایگزینی صفحه با نگه‌داشتن فوکوس و صفحه‌کلید (تنها یک نسخه در app.js هست،
   ولی صفحه‌های ورود این‌جا ساخته می‌شوند؛ پس هر دو مسیر از همین می‌گذرند) */
function setApp(html) {
  const root = $('#app');
  if (!root) return;
  const snap = (typeof focusSnapshot === 'function') ? focusSnapshot() : null;
  root.innerHTML = html;
  if (snap && typeof focusRestore === 'function') focusRestore(snap);
}

/* ══════════════ صفحه‌های ورود ══════════════ */
function renderSetup() {
  setApp(`
  <div class="auth">
    <img class="logo-img" src="/icons/logo.png" alt="پایش — سامانهٔ مدیریت مدرسه">
    <h1>راه‌اندازی پایش-لوکال</h1>
    <div class="sub">این فرم فقط یک‌بار پر می‌شود؛ بعد از آن همیشه صفحهٔ ورود می‌آید.</div>
    <form data-form="setup" class="card">
      <label class="field"><span>نام مدرسه</span><input class="input" name="school_name" required placeholder="دبیرستان کاردانش ..."></label>
      <div class="row">
        <label class="field grow"><span>نوع مدرسه</span>
          <select class="input" name="school_type">
            <option>کاردانش</option><option>فنی و حرفه‌ای</option><option>متوسطه دوم</option>
            <option>متوسطه اول</option><option>ابتدایی</option>
          </select></label>
        <label class="field grow"><span>سال تحصیلی</span><input class="input" name="school_year" value="۱۴۰۵–۱۴۰۶"></label>
      </div>
      <label class="field"><span>نام مدیر</span><input class="input" name="manager_name" required placeholder="نام و نام خانوادگی"></label>
      <label class="field"><span>شمارهٔ همراه مدیر (نام کاربری ورود)</span><input class="input ltr" name="phone" inputmode="numeric" data-digits placeholder="09xxxxxxxxx"></label>
      <label class="field"><span>رمز عبور مدیر</span><input class="input ltr" type="password" name="password" minlength="4" required autocomplete="new-password" placeholder="حداقل ۴ نویسه"></label>
      <label class="field"><span>تکرار رمز عبور</span><input class="input ltr" type="password" name="password2" minlength="4" required autocomplete="new-password"></label>
      <button class="btn primary block" type="submit">ایجاد مدرسه</button>
      <p class="small muted center" style="margin-top:10px">بعد از این، با «شمارهٔ همراه + رمز عبور» وارد می‌شوید.</p>
    </form>
    <div class="card tight small muted center">
      محل ذخیرهٔ داده: <span class="ltr">${esc((S.server && S.server.dataDir) || '—')}</span>
      ${S.deviceToken ? '<div style="margin-top:6px;color:#b45309">این دستگاه قبلاً به مدرسه وصل بوده باشد؛ اگر دادهٔ قبلی را می‌خواهید، پیش از ساخت مدرسهٔ تازه به مدیر اطلاع دهید.</div>' : ''}
    </div>
  </div>`)
}

function claimCard() {
  const local = /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(location.host || '');
  if (!local) return '';
  if (!(S.server && S.server.setupDone)) return '';
  const noPassword = S.server.hasPassword === false;
  /* پیش‌فرض: اگر رمزی وجود دارد، فقط یک لینک کم‌رنگ؛ اگر ندارد، فرم باز */
  if (!noPassword && !S.claimOpen) {
    return `<p class="small center" style="margin-top:8px"><a href="#" data-act="claim-open">رمز عبور را نمی‌دانم (فقط روی همین رایانه)</a></p>`;
  }
  return `
    <form data-form="claim" class="card">
      <div class="card-title">${noPassword ? 'حساب مدیر هنوز رمز عبور ندارد' : 'تعیین رمز تازهٔ مدیر'}</div>
      <p class="small muted">چون این رایانه خودِ رایانهٔ مدرسه است، از همین‌جا رمز مدیر را می‌سازید و بلافاصله وارد می‌شوید. از گوشی‌های دیگر این کار ممکن نیست.</p>
      <label class="field"><span>شمارهٔ همراه مدیر</span>
        <input class="input ltr" name="phone" inputmode="numeric" data-digits placeholder="09xxxxxxxxx" value="${esc(S.claimPhone || '')}"></label>
      <label class="field"><span>رمز عبور تازه</span>
        <input class="input ltr" type="password" name="password" autocomplete="new-password" placeholder="••••"></label>
      <button class="btn primary block" type="submit">ساختن رمز و ورود</button>
    </form>`;
}

function renderPair() {
  const href = location.hash;
  /* کد پیوند می‌تواند از سه راه بیاید: #/join/CODE (کارت قدیمی)،
     #/pair=CODE (QR یا پیوند کوتاه) و #/pair?c=CODE (پیوند دستی) */
  const m = href.match(/#\/(?:join|pair)[=\/]?([A-Za-z0-9-]{4,})/) || href.match(/[?&]c=([A-Za-z0-9-]{4,})/);
  const pre = m ? m[1].replace(/-/g, '').toUpperCase() : '';
  /* پیش‌فرض همیشه «شمارهٔ همراه + رمز عبور»؛ کد پیوند فقط راهِ سریعِ فرعی است */
  let mode = 'password';
  if (pre) mode = 'pair';
  else if (S.loginMode) mode = S.loginMode;
  else if (S.server && S.server.setupDone && S.server.hasPassword === false) mode = 'pair';
  const body = mode === 'pair' ? `
      <label class="field"><span>کد پیوند</span>
        <input class="input code-input" name="code" value="${esc(pre)}" maxlength="12" placeholder="XXXX-XXXX" autocomplete="off"></label>
      <button class="btn primary block" type="submit">ورود و ثبت این دستگاه</button>
      <div class="row" style="gap:8px;margin-top:8px">
        <button class="btn grow" type="button" data-act="scan-camera">📷 اسکن با دوربین</button>
        <button class="btn grow" type="button" data-act="scan-gallery">🖼️ عکس از گالری</button>
      </div>
      <p class="small muted center" style="margin-top:10px">کد روی کارتی است که مدیر از «کاربران → کارت پیوند» چاپ می‌کند.<br>هر کد تا وقتی مدیر «کد تازه» نسازد کار می‌کند.</p>
      <p class="small center" style="margin-top:6px"><a href="#" data-act="login-mode" data-id="password">ورود با شمارهٔ همراه و رمز عبور</a></p>
      ${pre ? scanLandingHtml(pre) : ''}`
    : `
      <label class="field"><span>شمارهٔ همراه، کد ملی یا نام کاربری</span>
        <input class="input ltr" name="phone" data-login data-focus-key="phone"
          autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false"
          maxlength="32" placeholder="09xxxxxxxxx" autofocus></label>
      <label class="field"><span>رمز عبور</span>
        <input class="input ltr" type="password" name="password" data-focus-key="password"
          autocomplete="new-password" autocorrect="off" autocapitalize="none" spellcheck="false" placeholder="••••••"></label>
      <button class="btn primary block" type="submit">ورود</button>
      <div class="row" style="gap:8px;margin-top:10px">
        <button class="btn grow" type="button" data-act="login-mode" data-id="pair">کارت پیوند</button>
        <button class="btn grow" type="button" data-act="scan-open">📷 اسکن QR</button>
      </div>`;

  setApp(`
  <div class="auth">
    <img class="logo-img" src="/icons/logo.png" alt="پایش — سامانهٔ مدیریت مدرسه">
    <h1>ورود به پایش</h1>
    <div class="sub">${S.server.school ? esc(S.server.school) : 'سامانهٔ مدرسه'}</div>
    <form data-form="${mode === 'pair' ? 'pair' : 'login'}" class="card" autocomplete="off">${body}</form>
    ${claimCard()}
    <div class="card tight small muted">
      سرور: <span class="ltr">${esc(location.host)}</span> · نسخه ${esc(S.server.version || '')}
      ${S.user ? '' : `<br><a href="#" data-act="forget-device">دستگاه دیگری انتخاب شود</a>`}
    </div>
  </div>`)
}

/* ── راهنمای اسکنِ QR روی کارت پیوند ──────────────────────────────
   کاربر QR را با دوربین گوشی می‌اسکند و به همین صفحه می‌رسد. اگر برنامه
   نصب باشد با یک دکمه باز و خودکار وارد می‌شود؛ اگر نصب نباشد همین‌جا
   نصبش می‌کنیم و بعد از نصب همان دکمه او را وارد حسابش می‌کند. */
function pairDeepLink(code) {
  const host = (typeof location !== 'undefined' ? location.origin : '');
  return 'payesh://pair?c=' + encodeURIComponent(String(code || '')) + '&h=' + encodeURIComponent(host);
}
function scanLandingHtml(code) {
  const plain = String(code || '').replace(/[^0-9A-Za-z]/g, '');
  const apk = NATIVE_APK_URL; /* row 161: direct file, never the release page */
  const bundled = typeof window !== 'undefined' && window.PAYESH_BUNDLED === true;
  if (bundled) return '';
  return `<div class="card tight" style="margin-top:12px;text-align:right">
      <b>📷 با اسکن این کد چه می‌شود؟</b>
      <div class="small muted" style="margin-top:6px;line-height:1.9">
        ۱) اگر برنامهٔ پایش روی این گوشی نصب است، دکمهٔ زیر را بزنید — بدون رمز وارد حساب خودتان می‌شوید.<br>
        ۲) اگر نصب نیست، اول «نصب برنامه» را بزنید؛ بعد از نصب برگردید و همان دکمهٔ اول را بزنید.<br>
        کد پیوند: <b class="ltr">${esc(plain.replace(/^(.{4})(.{4})$/, '$1-$2'))}</b>
      </div>
      <a class="btn primary block" style="margin-top:10px" href="${esc(pairDeepLink(plain))}" data-deeplink="1">باز کردن برنامه و ورود خودکار</a>
      <a class="btn block" style="margin-top:8px" href="${esc(apk)}" rel="noopener">⬇️ نصب برنامه (اندروید)</a>
      <button class="btn ghost block" style="margin-top:8px" type="button" data-act="pair-here">ورود در همین مرورگر (آیفون و رایانه)</button>
    </div>`;
}

function renderTransfer(code) {
  setApp(`
  <div class="auth">
    <img class="logo-img" src="/icons/logo.png" alt="پایش — سامانهٔ مدیریت مدرسه">
    <h1>انتقال به آدرس رسمی</h1>
    <div class="sub">برای ادامه، رمز عبور خودتان را وارد کنید</div>
    <form data-form="transfer" class="card">
      <input type="hidden" name="code" value="${esc(code)}">
      <label class="field"><span>رمز عبور</span>
        <input class="input ltr" type="password" name="password" autocomplete="current-password" placeholder="رمز عبور"></label>
      <button class="btn primary block" type="submit">فعال‌سازی روی این آدرس</button>
      <p class="small muted center" style="margin-top:10px">بعد از این، با شمارهٔ همراه و همین رمز وارد می‌شوید.</p>
    </form>
    <div class="card tight small muted center">
      <a href="#/" data-act="forget-device">انصراف</a>
    </div>
  </div>`)
}

function renderLock() {
  const pw = (S.unlockMode || localStorage.getItem('payesh.authmode')) === 'password';
  const user = (localStorage.getItem('payesh.lastname') || '');
  setApp(`
  <div class="auth">
    <img class="logo-img" src="/icons/logo.png" alt="پایش — سامانهٔ مدیریت مدرسه">
    <h1>پایش</h1>
    <div class="sub">${user ? esc(user) + ' — ' : ''}رمز عبور خود را وارد کنید</div>
    <form data-form="unlock" class="card">
      <label class="field"><input class="input ltr" type="password" name="password" autocomplete="current-password" placeholder="رمز عبور" autofocus></label>
      <button class="btn primary block" type="submit">ورود</button>
    </form>
    <div class="center" style="margin-top:8px"><a href="#" class="small" data-act="forget-device">این دستگاه من نیست</a></div>
  </div>`)
}

/* صفحهٔ ورود «بدون سرور»: روی گوشی و هر رایانه‌ای که به سیستم مدرسه
   دسترسی ندارد، همین صفحه می‌آید — نه پیام بن‌بست «سرور در دسترس نیست». */
/* نسخهٔ نصب‌شده — برای اینکه کاربر بداند نسخهٔ تازه روی گوشی است یا نه */
function buildStamp() {
  const v = (typeof CLIENT_VERSION !== 'undefined' && CLIENT_VERSION) || '';
  const b = (typeof window !== 'undefined' && window.PAYESH_BUILD) || '';
  return (v ? 'نسخهٔ ' + fa(v) : '') + (b && b.indexOf(v) !== 0 ? ' · ساخت ' + b : '');
}

function renderPhoneLogin(force) {
  /* اگر همین صفحه روی نمایش است، دوباره نساز: بازسازیِ نابهنگام، فوکوس را
     می‌برد و صفحه‌کلید گوشی بسته می‌شود. */
  if (!force && document.querySelector('form[data-form="phone-login"]')) return;
  const last = (window.PayeshPhone && window.PayeshPhone.lastUser && window.PayeshPhone.lastUser()) || null;
  const cloud = (window.PayeshPhone && window.PayeshPhone.storedConfig
      && (window.PayeshPhone.storedConfig() || window.PayeshPhone.bakedConfig()))
    || window.PAYESH_CLOUD || {};
  const cloudLine = cloud.endpoint
    ? `حافظهٔ مشترک: <span class="ltr">${esc(String(cloud.endpoint).replace(/^https?:\/\//, ''))}</span>` +
      (cloud.bucket ? ` · صندوقچه <span class="ltr">${esc(cloud.bucket)}</span>` : ' · صندوقچه خودکار')
    : 'حافظهٔ مشترک در برنامه تنظیم نشده';
  setApp(`
  <div class="auth">
    <img class="logo-img" src="/icons/logo.png" alt="پایش — سامانهٔ مدیریت مدرسه">
    <h1>ورود به پایش</h1>
    <div class="sub">شمارهٔ همراه (یا کد ملی) و رمزی که مدیر مدرسه برایتان ساخته است</div>
    <form data-form="phone-login" class="card" autocomplete="off">
      <label class="field"><span>شمارهٔ همراه (یا کد ملی)</span>
        <input class="input ltr" name="phone" data-focus-key="phone" inputmode="numeric"
          autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false"
          maxlength="11" placeholder="09xxxxxxxxx" value="${esc((last && last.phone) || '')}"></label>
      <label class="field"><span>رمز عبور</span>
        <input class="input ltr" type="password" name="password" data-focus-key="password"
          autocomplete="new-password" autocorrect="off" autocapitalize="none" spellcheck="false"
          placeholder="رمز عبور"></label>
      <button class="btn primary block" type="submit">ورود</button>
      <div class="small muted center" style="margin-top:6px;font-size:11px">${cloudLine}</div>
      <div class="small muted center" style="margin-top:2px;font-size:10px;opacity:.75">${esc(buildStamp())}</div>
    </form>
    <details class="center small" style="margin-top:12px;max-width:420px">
      <summary style="cursor:pointer">پیام خطا داد؟ اینجا را باز کنید</summary>
      <div class="muted" style="margin-top:8px;text-align:right;line-height:1.9">
        ۱) اینترنت گوشی را روشن کنید (داده همراه یا وای‌فای).<br>
        ۲) اگر بازهم نشد، یک‌بار در <b>سیستم مدرسه</b> برنامه را باز کنید تا تنظیم‌ها و اجازهٔ دسترسی خودکار انجام شود.<br>
        ۳) بعد همین‌جا دوباره «ورود» را بزنید.
      </div>
      <div class="row" style="margin-top:10px"><button class="btn sm" type="button" data-act="phone-diagnose">بررسی دقیق اتصال</button></div>
      <div id="diag-out" class="small" style="margin-top:8px;text-align:right;line-height:2"></div>
    </details>
    <div class="center small" style="margin-top:14px">
      <button class="btn sm ghost" data-act="retry">تلاش مجدد برای اتصال به سیستم مدرسه</button>
    </div>
  </div>`)
}

function renderOffline() {
  renderPhoneLogin();
}

/* تشخیص محل فیزیکی، مطابق مدل کلاس/محل مورد استفاده در برنامهٔ هفتگی. */
function dashboardIsRoom(c) {
  return !!c && (String(c.kind || '') === 'room' || (!c.kind && !c.grade && !c.branch));
}

/* ══════════════ داشبورد مدیر ══════════════ */
/* ردیف ۱۸۰ — آیکن‌های خطی طرح ۲ (lucide) */
function d2Ico(name, size) {
  const P = {
    sync: '<path d="M21 12a9 9 0 0 0-15-6.7L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 15 6.7l3-2.7"/><path d="M16 16h5v5"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
    chat: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    back: '<path d="m9 18 6-6-6-6"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  };
  const z = size || 18;
  return `<svg viewBox="0 0 24 24" width="${z}" height="${z}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name] || ''}</svg>`;
}

function managerHome() {
  const students = sortBy(list('users').filter(rosterStudent), 'name');
  const classes = sortBy(list('classes'), 'name');
  const today = todayISO();
  const attToday = list('attendance').filter(a => a.date === today);
  const present = attToday.filter(a => a.status === 'present').length;
  const absent = attToday.filter(a => a.status === 'absent').length;
  const late = attToday.filter(a => a.status === 'late').length;
  /* پوشش حضور مدرسه بر مبنای پایه/رشته است، نه نام محل برگزاری. */
  const cohortClasses = classes.filter(c => !dashboardIsRoom(c));
  const coverageByKey = new Map();
  /* ردیف ۲۰۴: «پایه دهم» و «دهم» یک گروه‌اند (همان قاعدهٔ صفحهٔ پایه و رشته) */
  const cohortKey = (grade, branch, classId) => (grade || branch)
    ? 'cohort|' + gradeKey(grade) + '\u001f' + defKey(branch)
    : 'class|' + (Number(classId) || 'unknown');
  const ensureCoverage = (grade, branch, classId, name) => {
    const g = String(grade || '').trim(), b = String(branch || '').trim();
    const key = cohortKey(g, b, classId);
    if (!coverageByKey.has(key)) coverageByKey.set(key, { key, grade: g, branch: b, classIds: new Set(), students: new Map(), fallbackName: String(name || '').trim() });
    const group = coverageByKey.get(key);
    if (Number(classId)) group.classIds.add(Number(classId));
    if (!group.fallbackName && name) group.fallbackName = String(name).trim();
    return group;
  };
  cohortClasses.forEach(c => {
    if (String(c.grade || '').trim() || String(c.branch || '').trim()) ensureCoverage(c.grade, c.branch, c.id, c.name);
  });
  students.forEach(student => {
    const cls = byId('classes', student.class_id) || {};
    /* ردیف ۲۰۴: پایه و رشته اول از گروه خود دانش‌آموز، بعد از فیلد خودش (field یا branch) */
    const place = stuPlace(student);
    const grade = place.g.trim();
    const branch = place.b.trim();
    const group = ensureCoverage(grade, branch, student.class_id, cls.name || student.name);
    group.students.set(Number(student.id), student);
  });
  const coverage = [...coverageByKey.values()].map(group => {
    const records = attToday.filter(a => group.classIds.has(Number(a.class_id)) || group.students.has(Number(a.student_id)));
    const checked = new Set(records.map(a => Number(a.student_id)).filter(Boolean)).size || records.length;
    const roster = group.students.size;
    const ratio = roster ? Math.min(100, Math.round(checked * 100 / roster)) : 0;
    const tone = !roster ? (checked ? 'amber' : '') : checked >= roster ? 'green' : checked ? 'amber' : 'red';
    return { group, records, checked, roster, ratio, tone,
      present: records.filter(a => a.status === 'present').length,
      absent: records.filter(a => a.status === 'absent').length,
      late: records.filter(a => a.status === 'late').length };
  }).sort((a, b) => alphaCompare(a.group.grade, b.group.grade) || alphaCompare(a.group.branch, b.group.branch) || alphaCompare(a.group.fallbackName, b.group.fallbackName));
  const doneCount = coverage.filter(x => x.checked > 0).length;

  /* پوشش کلاس‌ها: محل‌هایی که همین زنگ در آن‌ها واقعاً برنامه در حال اجراست سبزند. */
  const rooms = classes.filter(dashboardIsRoom);
  const bellNow = currentBell();
  const todaySlots = bellNow ? list('schedule').filter(s => Number(s.weekday) === weekdayIndex() && Number(s.bell_order) === Number(bellNow.order)) : [];
  const recentAnn = sortBy(list('announcements'), 'date').reverse().slice(0, 3);

  const dashboardDay = weekdayIndex();
  const currentBellLabel = bellNow ? (bellNow.label || 'زنگ ' + fa(bellNow.order)) : 'بین زنگ‌های درسی';

  /* Row 180 «مینیمال حرفه‌ای» (طرح ۲، مو به مو): سلام + «امروز · زنگ»، سپس `.mgrid`:
     «حضور امروز» (حلقه) کنار «هفتهٔ جاری»، «غایبان و تأخیرها» کنار «اطلاعیه‌ها». */
  const hour = now().getHours();
  const hello = (hour < 12 ? 'صبح بخیر' : hour < 17 ? 'ظهر بخیر' : hour < 20 ? 'عصر بخیر' : 'شب بخیر') +
    (S.user && String(S.user.name || '').trim() ? '، ' + String(S.user.name).trim() : '');
  const pct = students.length ? Math.min(100, Math.round(present * 100 / students.length)) : 0;
  const perDay = new Map();
  list('attendance').forEach(a => {
    const d = String(a.date || '').slice(0, 10);
    if (d.length < 10 || d > today) return;
    const x = perDay.get(d) || [0, 0];
    x[0] += 1; if (a.status === 'present' || a.status === 'late') x[1] += 1;
    perDay.set(d, x);
  });
  const week = [...perDay.keys()].sort().slice(-6).map(d => [d, Math.round(perDay.get(d)[1] * 100 / perDay.get(d)[0])]);
  const dayLetter = iso => (J_DAYS[weekdayIndex(new Date(iso + 'T12:00:00'))] || ' ').charAt(0);
  const away = attToday.filter(a => (a.status === 'absent' || a.status === 'late') && byId('users', a.student_id))
    .map(a => { const st = byId('users', a.student_id); return [st.name || '', (byId('classes', a.class_id || st.class_id) || {}).name || '', a.status]; })
    .slice(0, 5);
  const chev = '<svg class="d2-chev" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="m15 18-6-6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const cardH = (title, sub, route) => `<div class="card-h"><h3>${esc(title)}${sub ? ` <small>${esc(sub)}</small>` : ''}</h3>${route ? `<a class="lnk" href="#/${route}">همه ${chev}</a>` : ''}</div>`;

  return `
  <div class="topbar dashboard-topbar d2-top">
    <div class="hello"><h2>${esc(hello)}</h2>
      <p class="dashboard-now" aria-label="وضعیت زنگ جاری"><span class="dashboard-now-date">${esc(J_DAYS[dashboardDay] + '، ' + fa(jdate(today)))}</span> · <span class="dashboard-now-line"><span class="dashboard-now-kicker">الان در</span><strong>${esc(currentBellLabel)}</strong></span>${bellNow ? ' <span class="muted">در حال برگزاری</span>' : ''}</p></div>
    <div class="dashboard-topbar-left top-act">
      <div class="row no-print">
        <button class="btn sm primary" data-act="goto" data-route="announcements">＋ اطلاعیهٔ جدید</button>
        <a class="icon-b${recentAnn.length ? ' dot' : ''}" href="#/announcements" title="اطلاعیه‌ها" aria-label="اطلاعیه‌ها">${d2Ico('bell')}</a>
        <span class="avatar me" aria-hidden="true">${esc(String((S.user && S.user.name) || 'م').trim().charAt(0))}</span>
      </div>
    </div>
  </div>
  ${leavePendingCount() ? `<a class="card dash-leaves" id="dash-leaves" href="#/leaves" style="display:flex;align-items:center;gap:10px;text-decoration:none;border-inline-start:4px solid #d97706">
    <span aria-hidden="true">📨</span><b>${fa(leavePendingCount())} درخواست مرخصی در انتظار تأیید</b><span class="small muted" style="margin-inline-start:auto">بررسی ←</span></a>` : ''}
  <div class="mgrid" id="dash-mgrid">
    <section class="card mhero" id="dash-hero">
      <div class="ring" style="--p:${pct}"><div><b>${fa(pct)}٪</b><small>حاضر</small></div></div>
      <div class="hero-t"><h3>حضور امروز</h3><p>${fa(present)} نفر از ${fa(students.length)} دانش‌آموز</p>
        <div class="chips"><span class="chip c-ok">حاضر ${fa(present)}</span><span class="chip c-bad">غایب ${fa(absent)}</span><span class="chip c-warn">تأخیر ${fa(late)}</span></div></div>
    </section>
    <section class="card mweek" id="dash-week">${cardH('هفتهٔ جاری', 'درصد حضور')}
      ${week.length ? `<div class="bars">${week.map(([d, v]) => `<div class="bar${d === today ? ' on' : ''}" title="${fa(v)}٪"><i style="height:${Math.max(4, v)}%"></i><span>${esc(dayLetter(d))}</span></div>`).join('')}</div>` : '<div class="small muted d2-empty">هنوز حضوری ثبت نشده است</div>'}
    </section>
    <section class="card mlist" id="dash-away">${cardH('غایبان و تأخیرها', '', 'attendance-report')}
      ${away.length ? `<ul class="lst">${away.map(([n, c, st]) => `<li><span class="av">${esc(String(n).trim().charAt(0) || '؟')}</span><div class="nm"><b>${esc(n)}</b><small>${esc(c)}</small></div><span class="badge ${st === 'late' ? 'amber' : 'red'}">${st === 'late' ? 'تأخیر' : 'غایب'}</span></li>`).join('')}</ul>` : '<div class="small muted d2-empty">امروز غیبت یا تأخیری ثبت نشده است</div>'}
    </section>
    <section class="card mlist" id="dash-recent">${cardH('اطلاعیه‌ها', '', 'announcements')}
      ${recentAnn.length ? `<ul class="lst">${recentAnn.map(a => `<li><span class="n-ic">${'<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>'}</span><div class="nm"><b>${esc(a.title)}</b><small>${esc(fa(jdate(a.date)))}</small></div><a class="d2-go" href="#/announcements" aria-label="باز کردن">${chev}</a></li>`).join('')}</ul>` : '<div class="small muted d2-empty">اطلاعیه‌ای نیست</div>'}
    </section>
  </div>

  <div class="dashboard-coverage-grid">
  <section id="dashboard-attendance-coverage">${card(`<div class="row between" style="margin-bottom:10px"><div><b class="dashboard-card-title">پوشش حضور امروز · پایه و رشته</b><div class="small muted">تعداد دانش‌آموزانی که حضورشان برای امروز ثبت شده است.</div></div><span class="badge ${doneCount ? 'green' : 'amber'}">${fa(doneCount)} از ${fa(coverage.length)} گروه دارای ثبت</span></div>
    ${coverage.length ? `<div class="table-wrap dashboard-table-wrap"><table class="dashboard-table dashboard-attendance-table"><thead><tr><th>پایه</th><th>رشته</th><th>دانش‌آموزان</th><th>ثبت‌شده</th><th>حاضر / غایب / تأخیر</th><th>پوشش</th></tr></thead><tbody>
      ${coverage.map(({ group, records, checked, roster, ratio, tone, present: p, absent: a, late: l }) => `<tr data-dashboard-cohort="${esc(group.key)}">
        <td><strong>${esc(group.grade || '—')}</strong></td><td><strong>${esc(group.branch || (group.grade ? '—' : group.fallbackName || '—'))}</strong></td>
        <td>${fa(roster)}</td><td><strong>${fa(checked)} / ${fa(roster)}</strong></td>
        <td><span class="dash-status-counts"><span class="badge green">${fa(p)} حاضر</span><span class="badge red">${fa(a)} غایب</span><span class="badge amber">${fa(l)} تأخیر</span></span></td>
        <td><span class="badge ${tone}">${roster ? fa(ratio) + '٪' : records.length ? 'ثبت دارد' : 'بدون دانش‌آموز'}</span></td></tr>`).join('')}
      </tbody></table></div>` : '<div class="dashboard-empty">هنوز پایه یا رشته‌ای برای پوشش حضور تعریف نشده است.</div>'}`)}</section>

  <section id="dashboard-room-coverage">${card(`<div class="row between" style="margin-bottom:10px"><div><b class="dashboard-card-title">${isFieldSchoolNow() ? 'پوشش محل‌های برگزاری' : 'پوشش کلاس‌ها'}</b><div class="small muted">${bellNow ? 'وضعیت محل‌ها در زنگ ' + esc(bellNow.label || fa(bellNow.order)) + ' · ' + esc(clock24(bellNow.start) || bellNow.start || '') : 'در حال حاضر زنگ درسی فعالی نیست.'}</div></div><span class="badge ${todaySlots.some(s => Number(s.room_id) > 0) ? 'green' : ''}">${fa(rooms.length)} کلاس / محل</span></div>
    ${rooms.length ? `<div class="table-wrap dashboard-table-wrap"><table class="dashboard-table dashboard-room-table"><thead><tr><th>${isFieldSchoolNow() ? 'محل برگزاری' : 'کلاس / محل'}</th><th>وضعیت</th><th>پایه و رشته</th><th>درس</th><th>دبیر</th></tr></thead><tbody>
      ${rooms.map(room => {
        const active = todaySlots.filter(s => {
          const scheduledClass = byId('classes', s.class_id) || {};
          const roomId = Number(s.room_id) || (scheduledClass.kind === 'room' ? Number(s.class_id) : 0);
          return roomId === Number(room.id);
        });
        const slot = active[0] || null;
        const cohort = slot ? (byId('classes', slot.class_id) || {}) : {};
        const grade = String((slot && slot.grade) || cohort.grade || '').trim();
        const branch = String((slot && slot.branch) || cohort.branch || '').trim();
        const subject = slot ? (byId('subjects', slot.subject_id) || {}).name || '—' : '—';
        const teacher = slot ? (byId('users', slot.teacher_id) || {}).name || '—' : '—';
        const status = slot ? 'در حال برگزاری' : bellNow ? 'خالی در این زنگ' : 'خالی اکنون';
        return `<tr class="dashboard-room-row ${slot ? 'is-occupied' : ''}" data-room-id="${esc(room.id)}">
          <td><strong>${esc(room.name || '—')}</strong></td><td><span class="badge ${slot ? 'green' : ''}">${status}</span></td>
          <td>${slot ? `<strong>${esc(grade || '—')}${branch ? ' · ' + esc(branch) : ''}</strong>` : '<span class="muted">—</span>'}</td>
          <td>${esc(subject)}</td><td>${esc(teacher)}</td></tr>`;
      }).join('')}
      </tbody></table></div>` : `<div class="dashboard-empty">${isFieldSchoolNow() ? 'هنوز محل برگزاری تعریف نشده است.' : 'هنوز کلاس یا محل برگزاری تعریف نشده است.'}</div>`}`)}</section>
  </div>

  `;
}

function statCard(ico, num, label, tone = '') {
  return `<div class="card tight stat">
    <div class="ico">${ico}</div>
    <div><div class="num" style="color:${tone === 'red' ? 'var(--red)' : tone === 'green' ? 'var(--green)' : tone === 'amber' ? 'var(--amber)' : 'inherit'}">${num}</div><div class="lbl">${esc(label)}</div></div>
  </div>`;
}

/* ══════════════ خانهٔ دبیر ══════════════ */
function teacherScheduleFor(day) {
  const active = typeof schedWorkDays === 'function' ? schedWorkDays() : [0, 1, 2, 3, 4, 5];
  if (!active.includes(Number(day))) return [];
  return list('schedule').filter(s => Number(s.teacher_id) === Number(S.user.id) && Number(s.weekday) === Number(day));
}
function currentBell() {
  const bells = sortBy(pageBellRows().filter(b => String(b.type || 'lesson') === 'lesson'), 'order');
  const m = nowMin();
  return bells.find(b => m >= toMin(b.start) && m <= toMin(b.end)) || null;
}
function nextBell() {
  const bells = sortBy(pageBellRows().filter(b => String(b.type || 'lesson') === 'lesson'), 'order');
  const m = nowMin();
  return bells.find(b => toMin(b.start) > m) || null;
}
function attendanceFor(classId, date) {
  return list('attendance').filter(a => Number(a.class_id) === Number(classId) && a.date === date);
}

function teacherHome() {
  const day = weekdayIndex();
  const rows = teacherScheduleFor(day);
  const bells = new Map(pageBellRows().map(b => [Number(b.order), b]));
  const cur = currentBell();
  const nxt = nextBell();
  const today = todayISO();

  const slotCard = (s, highlight) => {
    const b = bells.get(Number(s.bell_order)) || {};
    const cls = byId('classes', s.class_id) || {};
    const subj = byId('subjects', s.subject_id) || {};
    const done = attendanceFor(s.class_id, today).length > 0;
    return `<div class="item" style="${highlight ? 'border-color:var(--primary);background:var(--soft)' : ''}">
      <div style="width:64px;text-align:center">
        <div style="font-weight:800">${esc((clock24(b.start) || b.start) || '')}</div>
        <div class="small muted">${esc((clock24(b.end) || b.end) || '')}</div>
      </div>
      <div class="grow">
        <div class="t">${esc(cls.name || '—')}</div>
        <div class="s">${esc(subj.name || '—')} ${highlight ? '· زنگ جاری' : ''}</div>
      </div>
      ${done ? badge('ثبت شده', 'green') : badge('ثبت نشده', 'red')}
      <a class="btn sm primary" href="#/attendance/${s.class_id}/${s.bell_order}">ثبت</a>
    </div>`;
  };

  return `
  ${pageHead('امروز من', J_DAYS[day] + '، ' + jdate(today), `<button class="btn sm" data-act="sync">🔄</button>`)}
  ${cur ? card(`<div class="row between"><div><div class="small muted">زنگ جاری</div><b style="font-size:17px">${esc(clock24(cur.start) || cur.start)} – ${esc(clock24(cur.end) || cur.end)}</b></div>
      <div class="badge purple">${esc(cur.label || '')}</div></div>`) :
    card(`<div class="row between"><div><div class="small muted">زنگ جاری</div><b>${nxt ? 'زنگ بعدی: ' + esc(clock24(nxt.start) || nxt.start) : 'زنگ درسی در جریان نیست'}</b></div></div>`)}
  ${card(`<div class="row between" style="margin-bottom:8px"><b>برنامهٔ امروز</b><span class="small muted">${fa(rows.length)} زنگ</span></div>
    ${rows.length ? `<div class="list">${rows.map(s => slotCard(s, cur && Number(s.bell_order) === Number(cur.order))).join('')}</div>` : '<div class="muted small">امروز کلاسی در برنامه ندارید.</div>'}`)}
  ${card(`<div class="row"><a class="btn grow" href="#/grades">📝 ثبت نمره</a><a class="btn grow" href="#/students">👥 دانش‌آموزان</a></div>`)}`;
}

/* ══════════════ حضور و غیاب ══════════════ */
const ATT_LABEL = { present: 'حاضر', absent: 'غایب', late: 'تأخیر', early_exit: 'خروج', excused: 'موجه' };

PAGES.attendance = (params) => {
  const clsId = Number(params[0] || 0);
  const bell = params[1] || '';
  const date = todayISO();
  if (!clsId) {
    const mine = new Set(list('schedule').filter(x => Number(x.teacher_id) === Number(S.user.id)).map(x => Number(x.class_id)));
    const classes = sortBy(list('classes').filter(c => S.role !== 'teacher' || mine.has(Number(c.id))), 'name');
    return pageHead('حضور و غیاب', 'کلاس را انتخاب کنید') + card(classes.length
      ? `<div class="list">${classes.map(c => {
          const n = list('users').filter(u => u.role === 'student' && Number(u.class_id) === Number(c.id)).length;
          const done = attendanceFor(c.id, date).length;
          return `<a class="item" href="#/attendance/${c.id}">
            <div class="grow"><div class="t">${esc(c.name)}</div><div class="s">${fa(n)} دانش‌آموز · ${fa(c.grade || '')}</div></div>
            ${badge(done ? 'ثبت‌شده' : 'ثبت‌نشده', done ? 'green' : 'amber')}</a>`;
        }).join('')}</div>`
      : empty('کلاسی به شما تخصیص نیافته است.'));
  }

  const roster = sortBy(list('users').filter(u => u.role === 'student' && Number(u.class_id) === clsId && u.active !== false), 'name');
  const existing = new Map(attendanceFor(clsId, date).map(a => [Number(a.student_id), a]));
  const cls = byId('classes', clsId) || {};
  const draft = S.attDraft && S.attDraft.key === clsId + ':' + date ? S.attDraft : (S.attDraft = { key: clsId + ':' + date, map: new Map() });
  /* ردیف ۱۹۷: مرخصی تأییدشدهٔ امروز — برچسب «مرخصی» و پیش‌فرض «موجه» برای تمام‌روز */
  const leaveOf = (sid) => leaveApprovedOn(sid, date);
  const statusOf = (sid) => {
    if (draft.map.has(sid)) return draft.map.get(sid);
    const e = existing.get(sid);
    return e ? e.status : attDefaultStatus(sid, date);
  };
  const counts = { present: 0, absent: 0, late: 0, early_exit: 0 };
  roster.forEach(s => { const v = statusOf(s.id); if (counts[v] != null) counts[v]++; });

  if (!roster.length) return pageHead('حضور و غیاب', cls.name || '') + empty('دانش‌آموزی برای این کلاس ثبت نشده است.');

  /* ردیف ۱۸۰ — طرح ۲: سر صفحه با برگشت، تراشهٔ کلاس‌ها، سه کارت خلاصه، «همه حاضرند؟» با
     «همه حاضر ✓» بنفش، ردیف هر دانش‌آموز (آواتار، نام، «ردیف n»، گروه دکمه‌های خط‌دار)،
     دکمهٔ مشکی تمام‌عرض «ثبت حضور · n نفر». کلاس‌ها و data-act ها همان قبلی است. */
  const mineCls = S.role === 'teacher'
    ? sortBy(list('classes').filter(c => list('schedule').some(x => Number(x.teacher_id) === Number(S.user.id) && Number(x.class_id) === Number(c.id))), 'name')
    : [];
  return `<div class="d2-top att-top"><div class="hello"><h1>حضور و غیاب</h1><p>${esc(cls.name || '')} · ${esc(fa(jdate(date)))}</p></div>
    <a class="icon-b" href="#/home" title="بازگشت" aria-label="بازگشت">${d2Ico('back')}</a></div>
  ${mineCls.length > 1 ? `<div class="kid-chips">${[...mineCls].sort((a, b) => (Number(b.id) === clsId) - (Number(a.id) === clsId)).map(c => `<a class="kid-chip sq${Number(c.id) === clsId ? ' on' : ''}" href="#/attendance/${c.id}">${esc(c.name)}</a>`).join('')}</div>` : ''}
  <div class="att-sum">
    <div><b class="c-ok">${fa(counts.present)}</b><span>حاضر</span></div>
    <div><b class="c-warn">${fa(counts.late)}</b><span>تأخیر</span></div>
    <div><b class="c-bad">${fa(counts.absent)}</b><span>غایب</span></div>
  </div>
  <div class="att-allrow"><span class="small muted">همه حاضرند؟</span>
    <button class="lnk-b muted" data-act="att-all" data-status="absent">همه غایب</button>
    <button class="lnk-b" data-act="att-all" data-status="present">همه حاضر ${d2Ico('check', 15)}</button></div>
  <div id="att-list" class="att-d2">${roster.map((s, i) => {
      const v = statusOf(s.id);
      return `<div class="att-row" data-sid="${s.id}">
        <span class="avatar">${esc(String(s.name || '؟').trim().charAt(0))}</span>
        <div class="att-name"><b>${esc(s.name)}</b><small>ردیف ${fa(i + 1)}</small>${leaveOf(s.id) ? `<small class="att-leave" style="color:#b45309;font-weight:700">${esc(leaveTagFa(leaveOf(s.id)))}</small>` : ''}</div>
        <div class="att-btns">
          <button class="att-btn ${v === 'present' ? 'on-p' : ''}" data-act="att-set" data-s="present">حاضر</button>
          <button class="att-btn ${v === 'late' ? 'on-l' : ''}" data-act="att-set" data-s="late">تأخیر</button>
          <button class="att-btn ${v === 'absent' ? 'on-a' : ''}" data-act="att-set" data-s="absent">غایب</button>
          <button class="att-btn ${v === 'early_exit' ? 'on-e' : ''}" data-act="att-set" data-s="early_exit">خروج</button>
          ${leaveOf(s.id) || v === 'excused' ? `<button class="att-btn ${v === 'excused' ? 'on-p' : ''}" data-act="att-set" data-s="excused">موجه</button>` : ''}
        </div>
      </div>`;
    }).join('')}</div>
  <button class="btn primary block att-save" data-act="att-save" data-class="${clsId}" data-bell="${esc(bell)}">${d2Ico('check', 18)} ثبت حضور · ${fa(roster.length)} نفر</button>`;
};

/* ══════════════ نمرات ══════════════ */
PAGES.grades = (params) => {
  if (S.role === 'teacher' || S.role === 'manager') {
    const classes = sortBy(S.role === 'manager' ? list('classes') :
      list('classes').filter(c => teacherScheduleFor(0).concat(teacherScheduleFor(1), teacherScheduleFor(2), teacherScheduleFor(3), teacherScheduleFor(4)).some(s => Number(s.class_id) === Number(c.id))), 'name');
    if (!classes.length) return pageHead('ثبت نمره') + empty('کلاسی به شما تخصیص نیافته است.');
    const sel = S.gradeSel || (S.gradeSel = { class: classes[0].id, subject: '', term: 'نوبت اول' });
    const subjects = sortBy(list('subjects'), 'name');
    if (!sel.subject) {
      const sc = list('schedule').find(s => Number(s.class_id) === Number(sel.class));
      sel.subject = sc ? sc.subject_id : (subjects[0] && subjects[0].id);
    }
    const roster = sortBy(list('users').filter(u => u.role === 'student' && Number(u.class_id) === Number(sel.class) && u.active !== false), 'name');
    const subject = byId('subjects', sel.subject) || {};
    const existing = new Map(list('grades')
      .filter(g => Number(g.class_id) === Number(sel.class) && Number(g.subject_id) === Number(sel.subject) && String(g.term) === String(sel.term))
      .map(g => [Number(g.student_id), g]));
    const draft = (S.gradeDraft && S.gradeDraft.key === sel.class + ':' + sel.subject + ':' + sel.term)
      ? S.gradeDraft : (S.gradeDraft = { key: sel.class + ':' + sel.subject + ':' + sel.term, map: new Map() });
    const valOf = (sid) => {
      if (draft.map.has(sid)) return draft.map.get(sid);
      const e = existing.get(sid);
      return e ? (e.practical_score != null ? e.practical_score : e.score) : '';
    };
    const isWorkshop = !!subject.workshop;

    return `${pageHead('ثبت نمره', subject.name || 'یک درس را انتخاب کنید')}
    <div class="card tight">
      <div class="row">
        <label class="field grow" style="margin:0"><span>پایه / رشته</span>
          <select class="input" id="g-class">${classes.map(c => `<option value="${c.id}" ${Number(c.id) === Number(sel.class) ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>
        <label class="field grow" style="margin:0"><span>درس</span>
          <select class="input" id="g-subject">${subjects.map(s => `<option value="${s.id}" ${Number(s.id) === Number(sel.subject) ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select></label>
        <label class="field grow" style="margin:0"><span>نوبت</span>
          <select class="input" id="g-term">${['نوبت اول', 'نوبت دوم', 'پایانی'].map(t => `<option ${t === sel.term ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        <button class="btn sm" data-act="grade-reload" style="align-self:end">نمایش</button>
      </div>
    </div>
    ${card(`<div class="row between" style="margin-bottom:8px"><b>${esc(subject.name || '')}</b>
        <span class="small muted">${isWorkshop ? 'درس کارگاهی — نمرهٔ عملی' : 'نمره از ۲۰'}</span></div>
      ${roster.length ? `<table><thead><tr><th>دانش‌آموز</th><th style="width:110px">نمره</th><th style="width:90px">وضعیت</th></tr></thead><tbody>
        ${roster.map(s => {
          const e = existing.get(s.id);
          return `<tr><td>${esc(s.name)}</td>
            <td><input class="input ltr" style="padding:.3rem" inputmode="decimal" data-grade="${s.id}" value="${esc(valOf(s.id))}" placeholder="—"></td>
            <td>${e ? badge(e.status === 'approved' ? 'تأییدشده' : 'در انتظار', e.status === 'approved' ? 'green' : 'amber') : badge('جدید', '')}</td></tr>`;
        }).join('')}
      </tbody></table>
      <button class="btn primary block" style="margin-top:12px" data-act="grade-save">ثبت نمرات</button>` :
        '<div class="muted small">دانش‌آموزی در این کلاس نیست.</div>'}
    `)}`;
  }
  return pageHead('نمرات') + empty('دسترسی ندارید.');
};

/* ══════════════ دانش‌آموزان دبیر ══════════════ */
PAGES.students = () => {
  const myClasses = new Set(list('schedule').filter(s => Number(s.teacher_id) === Number(S.user.id)).map(s => Number(s.class_id)));
  /* ردیف ۱۸۷: همهٔ دانش‌آموزان فقط برای مدیر/معاون (سرور هم همین را می‌دهد) */
  const all = S.role === 'manager';
  const students = sortBy(list('users').filter(u => u.role === 'student' && (all || myClasses.has(Number(u.class_id)))), 'name');
  const q = (S.q || '').trim();
  const rows = students.filter(s => !q || String(s.name).includes(q));
  return `${pageHead(all ? 'دانش‌آموزان مدرسه' : 'دانش‌آموزان من', fa(students.length) + ' نفر', '')}
  <div class="card tight"><input class="input" id="q-search" data-focus-key="q-search" data-search="q" placeholder="جستجو…" value="${esc(q)}"></div>
  ${rows.length ? card(`<div class="list">${rows.map(s => {
    const cls = byId('classes', s.class_id) || {};
    const g = list('grades').filter(x => Number(x.student_id) === Number(s.id));
    const avg = g.length ? (g.reduce((a, x) => a + Number(x.score || 0), 0) / g.length) : 0;
    return `<div class="item"><div class="grow"><div class="t">${esc(s.name)}</div><div class="s">${esc(cls.name || '')}</div></div>
      <span class="badge">معدل ${fa(avg.toFixed(1))}</span></div>`;
  }).join('')}</div>`) : empty('دانش‌آموزی یافت نشد.')}`;
};

/* ══════════════ مدیر: کاربران ══════════════ */
/* ردیف ۲۰۳: «نام» و «نام خانوادگی» جدا — name همهٔ نام را دارد؛ نام خانوادگیِ ثبت‌شده از
   انتهای آن بریده می‌شود، وگرنه پیش از آخرین کلمه (دو کلمه اگر آخری «زاده/نژاد/پور…» باشد). */
function splitName(u) {
  const norm = v => String(v == null ? '' : v).replace(/\s+/g, ' ').trim();
  const n = norm(u && u.name), l = norm(u && u.last_name), f = norm(u && u.first_name);
  const words = n ? n.split(' ') : [];
  const key = v => (typeof impNorm === 'function' ? impNorm(v) : v);
  if (l) {
    if (!n) return { first: f, last: l };
    const lw = l.split(' ').length;
    if (words.length > lw && key(words.slice(words.length - lw).join(' ')) === key(l)) {
      return { first: words.slice(0, words.length - lw).join(' '), last: l };
    }
    if (key(n) === key(l)) return { first: f, last: l };
    return { first: n, last: l };
  }
  if (words.length < 2) return { first: n, last: '' };
  const tails = ['زاده', 'نژاد', 'پور', 'فر', 'راد', 'نیا', 'وند', 'منش', 'کیا', 'دوست', 'فرد', 'مقدم', 'لو', 'زاد', 'آبادی', 'اصل', 'خواه', 'پناه', 'تبار'];
  let cut = words.length - 1;
  if (words.length >= 3 && tails.indexOf(key(words[words.length - 1])) > -1) cut--;
  return { first: words.slice(0, cut).join(' '), last: words.slice(cut).join(' ') };
}
/* نام کامل — اگر «نام» خودش نام خانوادگی را داشته باشد، دوباره تکرار نمی‌شود
   (باگ: «آرسام سعیدی سعیدی»). */
function fullName(u) {
  const n = String((u && u.name) || '').replace(/\s+/g, ' ').trim();
  const l = String((u && u.last_name) || '').replace(/\s+/g, ' ').trim();
  if (!l) return n;
  if (!n) return l;
  const nn = impNorm(n), ll = impNorm(l);
  if (nn === ll) return n;
  if (nn.endsWith(' ' + ll)) return n;
  if (nn.split(' ').indexOf(ll) > -1) return n;
  return n + ' ' + l;
}

PAGES.users = () => {
  if (S.role !== 'manager') return pageHead('کاربران') + empty('دسترسی ندارید.');
  const q = (S.q || '').trim();
  const role = S.roleFilter || '';
  let users = list('users');
  if (role) users = users.filter(u => u.role === role);
  /* ردیف ۱۸۵: دانش‌آموزان بر اساس پایه و رشته جدا می‌شوند ('-' = بدون پایه/رشته) */
  const gradeOf = u => String((byId('classes', u.class_id) || {}).grade || u.grade || '').trim();
  const branchOf = u => String((byId('classes', u.class_id) || {}).branch || u.field || u.branch || '').trim();
  const gf = role === 'student' ? String(S.gradeFilter || '') : '';
  const bf = role === 'student' ? String(S.branchFilter || '') : '';
  /* ردیف ۲۰۴: همان قاعدهٔ صفحهٔ پایه و رشته — «پایه دهم»، «۱۰» و «دهم» یک گزینه‌اند و هر سه را می‌گیرند */
  const hit = (v, want, key) => !want || (want === '-' ? !v : key(v) === key(want));
  if (gf || bf) users = users.filter(u => hit(gradeOf(u), gf, gradeKey) && hit(branchOf(u), bf, defKey));
  const studentsAll = list('users').filter(u => u.role === 'student');
  const optsOf = (kind, of) => {
    const key = kind === 'grade' ? gradeKey : defKey;
    const m = new Map();
    for (const v of [...lookupList(kind).map(l => String(l.name || '').trim()), ...studentsAll.map(of)]) {
      if (v && key(v) && !m.has(key(v))) m.set(key(v), v);
    }
    const lvl = v => (kind === 'grade' && typeof impGradeLevel === 'function' ? impGradeLevel(v) : 0);
    return [...m.values()].sort((a, b) => (lvl(a) - lvl(b)) || a.localeCompare(b, 'fa'));
  };
  const filterSel = (id, key, all, none, opts, cur) => `<select class="input" id="${id}" data-set="${key}">
      <option value="">${all}</option>${opts.map(o => `<option value="${esc(o)}" ${cur === o ? 'selected' : ''}>${esc(o)}</option>`).join('')}
      <option value="-" ${cur === '-' ? 'selected' : ''}>${none}</option></select>`;
  if (q) users = users.filter(u => String(u.name).includes(q) || String(u.phone || '').includes(q) || String(u.national_id || '').includes(q));
  users = sortBy(users, 'name').slice(0, 300);

  const picked = S.picked instanceof Set ? S.picked : new Set();
  const pickedVisible = users.filter(u => picked.has(Number(u.id)));
  const allPicked = users.length > 0 && pickedVisible.length === users.length;

  const openIssues = importIssueRows();
  const fuCount = followupCount();

  return `${pageHead('کاربران', fa(list('users').length) + ' کاربر',
    `<button class="btn sm" data-act="import-open">📥 ورود دسته‌ای (اکسل/CSV)</button>
     <button class="btn sm primary" data-act="user-add">+ کاربر جدید</button>`)}

  ${fuCount ? `<div class="card tight" style="border-color:#fcd34d;background:#fffbeb">
    <div class="row between" style="gap:8px;flex-wrap:wrap">
      <div><b>🕒 ${fa(fuCount)} مورد نیاز به پیگیری دارد</b>
        <div class="small muted" style="margin-top:4px">${fa(openIssues.length)} ردیف از ورود دسته‌ای + ${fa(fuCount - openIssues.length)} دانش‌آموز که ${isFieldSchoolNow() ? 'پایه یا رشته‌اش' : 'کلاسش'} درست نیست (رشته یا پایه‌اش حذف شده یا پایه نداشت).</div></div>
      <span class="row" style="gap:8px;flex-wrap:wrap">
        <a class="btn sm ghost" href="#/followup">صفحهٔ پیگیری</a>
        <button class="btn sm" data-act="issues-open">مشاهده و اصلاح</button>
      </span>
    </div></div>` : ''}

  <div class="card tight wide filter-bar" id="usr-filters">
    <input class="input" id="q-search" data-focus-key="q-search" data-search="q" placeholder="جستجوی نام، شماره یا کد ملی…" value="${esc(q)}">
    <div class="pill-tabs">
      ${[['', 'همه'], ['student', 'دانش‌آموز'], ['teacher', 'دبیر'], ['parent', 'ولی'], ['manager', 'مدیر'], ['vice', 'معاون'], ['counselor', 'مشاور'], ['staff', 'کارمند'], ['office', 'اجرایی'], ['guard', 'نگهبان']].map(([v, t]) =>
        `<span class="pill ${role === v ? 'on' : ''}" data-act="role-filter" data-role="${v}">${t}</span>`).join('')}
    </div>
    ${role === 'student' ? filterSel('usr-grade-filter', 'gradeFilter', 'همهٔ پایه‌ها', 'بدون پایه', optsOf('grade', gradeOf), gf)
      + filterSel('usr-branch-filter', 'branchFilter', 'همهٔ رشته‌ها', 'بدون رشته', optsOf('branch', branchOf), bf) : ''}
  </div>

  ${picked.size ? `<div class="card tight" style="border-color:#b91c1c">
    <div class="row between">
      <b>${fa(picked.size)} کاربر انتخاب شده</b>
      <span class="row" style="gap:8px">
        <button class="btn sm ghost" data-act="pick-clear">لغو انتخاب</button>
        <button class="btn sm" style="background:#b91c1c;color:#fff" data-act="users-bulk-delete">حذف انتخاب‌شده‌ها</button>
      </span>
    </div></div>` : ''}

  ${card(`<div class="small muted" style="margin-bottom:6px">کاربری و رمز هر نفر داخل دکمهٔ <b>«کاربری»</b> است — همان‌جا می‌بینید، عوض می‌کنید یا حساب را حذف می‌کنید. نام کاربری همان <b>شمارهٔ همراه</b> است (اگر شماره نبود، <b>کد ملی</b>) و رمز اولیه <b>کد ملی</b>. این جدول را فقط مدیر می‌بیند.</div>
  <div class="table-wrap"><table><thead><tr>
    <th style="width:34px"><input type="checkbox" data-pick="all" ${allPicked ? 'checked' : ''} title="انتخاب همه"></th>
    <th>نام و نام خانوادگی</th><th>نقش</th><th>پایه</th><th>رشته</th>${S.roleFilter === 'parent' ? '<th>ولیِ چه دانش‌آموزی</th>' : ''}<th>عملیات</th></tr></thead><tbody>
    ${users.map(u => {
      /* پایه و رشته از گروه ثبت‌نام (کلاس) خوانده می‌شود؛ برای ولی، از فرزندش */
      const link = u.role === 'parent' ? list('parent_links').find(l => Number(l.parent_id) === Number(u.id)) : null;
      const kids = u.role === 'parent' ? list('parent_links').filter(l => Number(l.parent_id) === Number(u.id)).map(l => byId('users', l.student_id)).filter(Boolean) : [];
      const subject = (u.role === 'parent' && kids.length) ? kids[0] : u;
      const grp = byId('classes', subject.class_id) || {};
      const gr = String(grp.grade || subject.grade || '');
      const br = String(grp.branch || subject.field || subject.branch || '');
      return `<tr${picked.has(Number(u.id)) ? ' style="background:#fef2f2"' : ''}>
      <td><input type="checkbox" data-pick="user" value="${u.id}" ${picked.has(Number(u.id)) ? 'checked' : ''}></td>
      <td>${esc(fullName(u))}</td>
      <td>${u.role === 'student' ? '<span class="muted">—</span>' : badge(ROLE_FA[u.role] || u.role, u.role === 'manager' ? 'purple' : '')}</td>
      <td class="small">${gr ? esc(gr) : '<span class="muted">—</span>'}</td>
      <td class="small">${br ? esc(br) : '<span class="muted">—</span>'}</td>
      ${S.roleFilter === 'parent' ? `<td class="small">${kids.length ? kids.map(k => esc(fullName(k))).join('، ') : '<span class="muted">—</span>'}</td>` : ''}
      <td class="nowrap">
        <button class="btn sm primary" data-act="user-full" data-id="${u.id}">مشخصات کامل</button>
        <button class="btn sm" data-act="user-creds" data-id="${u.id}">کاربری</button>
        <button class="btn sm" data-act="pair-code" data-id="${u.id}">کارت پیوند</button>
        <button class="btn sm ghost" data-act="user-edit" data-id="${u.id}">ویرایش</button>
        <button class="btn sm ghost" data-act="user-delete" data-id="${u.id}" style="color:#b91c1c">حذف</button>
      </td>
    </tr>`;
    }).join('')}
  </tbody></table></div>${users.length ? '' : empty('کاربری با این مشخصات پیدا نشد.')}`, 'wide')}`;
};

/* ══════════════ پیگیری ردیف‌های ناتمامِ ورود دسته‌ای ══════════════
   هر ردیفی که ساخته نشد یا مشخصاتش ناقص بود اینجا می‌ماند: دلیلش را
   می‌بینید، با یک دکمه فرم کاربر با همان اطلاعات باز می‌شود تا کاملش
   کنید، و بعد «حل شد» می‌زنید. */
function importIssuesTableHtml(all) {
  const rows = all.map(r => {
    const d = r.data || {};
    const existed = list('users').find(u =>
      (r.national_id && String(u.national_id || '') === String(r.national_id)) ||
      (r.phone && String(u.phone || '') === String(r.phone)) ||
      (!r.national_id && !r.phone && String(u.name || '') === String(r.name)));
    return `<tr>
      <td><b>${esc(r.name || '—')}</b>
        ${r.national_id ? `<div class="small muted ltr">${esc(r.national_id)}</div>` : ''}</td>
      <td class="small ltr">${esc(r.phone || '—')}</td>
      <td class="small">${(r.reasons || []).slice(0, 4).map(x => `<div>⚠️ ${esc(x)}</div>`).join('') || '—'}</td>
      <td class="small">${existed ? badge('در سامانه هست', 'green') : badge('ساخته نشده', 'red')}</td>
      <td class="nowrap">
        <button class="btn sm" data-act="issue-fix" data-id="${esc(r.id)}">${existed ? 'اصلاح' : 'ساختن کاربر'}</button>
        <button class="btn sm ghost" data-act="issue-done" data-id="${esc(r.id)}">حل شد</button>
      </td></tr>`;
  }).join('');
  return `<div class="table-wrap" style="max-height:52vh;overflow:auto"><table><thead><tr>
      <th>نام</th><th>شمارهٔ همراه</th><th>دلیل</th><th>وضعیت</th><th></th></tr></thead>
    <tbody>${rows}</tbody></table></div>`;
}

function importIssuesHtml() {
  const all = importIssueRows();
  return `<div class="small muted" style="margin-bottom:8px;line-height:2">
      این فهرست برای ردیف‌هایی است که در ورود دسته‌ای ساخته نشدند یا مشخصاتشان کامل نبود.
      با «ساختن/اصلاح» فرم کاربر با همان اطلاعات باز می‌شود؛ بعد از ذخیره، ردیف از این فهرست برداشته می‌شود.
    </div>
    ${all.length ? importIssuesTableHtml(all) + `<div class="row" style="margin-top:10px;gap:8px">
        <button class="btn ghost" data-act="modal-close">بستن</button>
        <button class="btn primary grow" data-act="issues-clear">همه را حل‌شده کن</button>
      </div>`
      : `<div class="center" style="padding:16px 0"><div style="font-size:32px">✅</div>
         <b>هیچ ردیفی برای پیگیری نمانده</b></div>
         <button class="btn primary block" data-act="modal-close" style="margin-top:10px">باشه</button>`}`;
}

function actImportIssues() {
  S.modalTitle = 'نیازمند پیگیری — ورود دسته‌ای';
  modal(importIssuesHtml());
}

/* ══════════════ «نیازمند پیگیری» — یک جای مشخص و همیشه در دسترس ══════
   دو دسته با هم نشان داده می‌شوند:
     ۱) ردیف‌های ورود دسته‌ای که ساخته نشدند یا مشخصاتشان کامل نبود
     ۲) دانش‌آموزانی که کلاسشان معتبر نیست — رشته/پایه‌شان حذف شده،
        در فایل نبود، یا کلاسشان پایه ندارد
   مورد دوم از خودِ داده حساب می‌شود، پس هر دانش‌آموزی که با حذف رشته
   بی‌کلاس شود بی‌درنگ همین‌جا ظاهر می‌شود.
   ═══════════════════════════════════════════════════════════════════ */
function importIssueRows() {
  return sortBy(list('import_issues').filter(r => r.status !== 'done'), 'name');
}

/** چرا این دانش‌آموز کلاس درست ندارد؟ رشتهٔ خالی برچسب نمی‌خورد. */
function followupStudentReason(u) {
  if (!u || u.role !== 'student') return '';
  if (u.followup_ack) return '';
  const c = u.class_id ? byId('classes', u.class_id) : null;
  if (!c) return u.followup_reason || 'پایه و رشته ندارد';
  const gradeNames = lookupList('grade').map(l => String(l.name));
  const branchNames = lookupList('branch').map(l => String(l.name));
  const g = String(c.grade || '').trim();
  const b = String(c.branch || '').trim();
  if (!g) return u.followup_reason || 'پایه‌اش در فایل نبود';
  if (gradeNames.length && gradeNames.indexOf(g) < 0) return 'پایه‌اش تعریف نشده («' + g + '»)';
  if (b && branchNames.length && branchNames.indexOf(b) < 0) return 'رشته‌اش تعریف نشده («' + b + '»)';
  /* کلاس سالم است: دلیلِ کهنه نباید او را در فهرست نگه دارد */
  return '';
}

function followupStudents() {
  const out = [];
  for (const u of list('users')) {
    if (u.role !== 'student') continue;
    const r = followupStudentReason(u);
    if (r) out.push({ user: u, reason: r });
  }
  out.sort((a, b) => alphaCompare(a.user.name, b.user.name));
  return out;
}

function followupCount() {
  return followupStudents().length + importIssueRows().length;
}

function classOptionList(selectedId) {
  const classes = sortBy(list('classes'), 'name');
  return classes.map(c => `<option value="${c.id}" ${Number(selectedId) === Number(c.id) ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
}

PAGES.followup = () => {
  if (S.role !== 'manager') return pageHead('نیازمند پیگیری') + empty('دسترسی ندارید.');
  const studs = followupStudents();
  const issues = importIssueRows();
  const total = studs.length + issues.length;

  const gradeNames = alphaSort(lookupList('grade').map(l => String(l.name)).filter(g => !(typeof impGradeLevel === 'function') || impGradeLevel(g)));
  const baseBranchNames = alphaSort(lookupList('branch').map(l => String(l.name)));
  const studRows = studs.map(({ user, reason }) => {
    /* رشته از متن دلیل («رشته: نقشه‌کشی») برداشته می‌شود تا مدیر فقط پایه را بزند */
    const m = String(reason || '').match(/رشته:\s*([^)\n]+)/);
    const brGuess = m ? String(m[1]).replace(/\(.*$/, '').trim() : '';
    const cur = byId('classes', user.class_id) || {};
    const gSel = String(cur.grade || '');
    const bSel = String(cur.branch || brGuess || '');
    /* رشتهٔ استخراج‌شده از اکسل حتی اگر هنوز «تعریف» نشده باشد در فهرست می‌آید */
    const fuBranches = bSel && baseBranchNames.indexOf(bSel) < 0 ? baseBranchNames.concat([bSel]) : baseBranchNames;
    const gradeNames2 = gSel && gradeNames.indexOf(gSel) < 0 ? gradeNames.concat([gSel]) : gradeNames;
    return `<tr>
      <td><b>${esc(user.name)}</b>
        <div class="small muted ltr">${esc(user.phone || user.national_id || '')}</div></td>
      <td class="small">⚠️ ${esc(reason)}</td>
      <td class="nowrap">
        <select class="input" id="fu-grade-${user.id}" style="min-width:104px">
          <option value="">— پایه —</option>${gradeNames2.map(g => `<option value="${esc(g)}" ${g === gSel ? 'selected' : ''}>${esc(g)}</option>`).join('')}</select>
        <select class="input" id="fu-branch-${user.id}" style="min-width:118px">
          <option value="">— رشته —</option>${fuBranches.map(b => `<option value="${esc(b)}" ${b === bSel ? 'selected' : ''}>${esc(b)}</option>`).join('')}</select>
      </td>
      <td class="nowrap">
        <button class="btn sm primary" data-act="followup-assign" data-id="${user.id}">ذخیره</button>
        <button class="btn sm ghost" data-act="followup-ack" data-id="${user.id}" title="بی‌کلاس بماند">حل شد</button>
      </td></tr>`;
  }).join('');

  const studentsCard = card(
    `<div class="row between" style="margin-bottom:8px"><b>دانش‌آموزانی که پایه/رشته‌شان کامل نیست</b>
       <span class="small muted">${fa(studs.length)} نفر</span></div>` +
    (studs.length
      ? `<div class="table-wrap"><table><thead><tr>
           <th>دانش‌آموز</th><th>دلیل</th><th style="min-width:190px">پایه و رشته</th><th></th>
         </tr></thead><tbody>${studRows}</tbody></table></div>`
      : `<div class="small muted">پایه و رشتهٔ همهٔ دانش‌آموزان کامل است. ✅</div>`),
    studs.length ? 'wide' : ''
  );

  const issuesCard = card(
    `<div class="row between" style="margin-bottom:8px"><b>ردیف‌های ورود دسته‌ای</b>
       <span class="small muted">${fa(issues.length)} ردیف</span></div>` +
    (issues.length
      ? importIssuesTableHtml(issues) +
        `<div class="row" style="margin-top:10px;gap:8px">
           <button class="btn primary" data-act="issues-clear">همه را حل‌شده کن</button></div>`
      : `<div class="small muted">ردیف ناتمامی از ورود دسته‌ای نمانده. ✅</div>`),
    issues.length ? 'wide' : ''
  );

  return `${pageHead('نیازمند پیگیری', fa(total) + ' مورد برای رسیدگی',
      `<button class="btn sm" data-act="import-open">📥 ورود دسته‌ای</button>`)}
  <div class="small muted" style="margin-bottom:10px;line-height:2">
    هر چیزی که کامل نیست اینجا جمع می‌شود: ردیف‌های ورود دسته‌ای که ساخته نشدند،
    و دانش‌آموزانی که پایه یا رشته‌شان کامل نیست (مثلاً رشته‌شان حذف شده یا پایه‌اش در فایل نبود).
    تا اینجا باشند جایی گم نمی‌شوند.
  </div>
  ${studentsCard}
  ${issuesCard}`;
};

/* ══════════════ تعریف‌ها (پایه، رشته) ══════════════ */
/* فقط تعریف‌های واقعیِ ثبت‌شده نمایش داده می‌شوند؛ هیچ فهرست پیش‌فرضی در کار
   نیست تا چیزی که حذف شده دیگر برنگردد. */
const LOOKUP_FA = { grade: 'پایه', branch: 'رشته' };

/* فقط چیزی که واقعاً تعریف شده برمی‌گردد. فهرست پیش‌فرضی در کار نیست،
   وگرنه رشته‌ای که مدیر حذف کرده دوباره پایین صفحه ظاهر می‌شد. */
function lookupList(kind) {
  return sortBy(list('lookups').filter(l => String(l.kind) === String(kind)), 'name');
}

/* ردیف ۲۰۴: یک قاعده برای همهٔ شمارها (همان برنامهٔ بومی): «پایه دهم»، «۱۰» و «دهم» یک پایه‌اند؛
   پایه/رشتهٔ دانش‌آموز اول از کلاس خودش، بعد از فیلد خودش؛ دانش‌آموزِ غیرفعال شمرده نمی‌شود. */
function defKey(v) { return (typeof impNorm === 'function' ? impNorm(v) : String(v || '').trim()).replace(/\s+/g, ''); }
function gradeKey(v) {
  const l = typeof impGradeLevel === 'function' ? impGradeLevel(v) : 0;
  return l ? 'L' + l : defKey(v);
}
function rosterStudent(u) { return u && u.role === 'student' && u.active !== false && u.active !== 0; }
function stuPlace(u) {
  const c = u.class_id ? byId('classes', u.class_id) : null;
  const inCls = c && String(c.kind || '') !== 'room';
  const g = inCls && c.grade ? String(c.grade) : String(u.grade || '');
  const b = inCls && c.branch ? String(c.branch) : String(u.field || u.branch || '');
  return { g, b };
}
function isFieldSchoolNow() {
  const lvl = String((S.server.school && S.server.school.level) || '');
  if (lvl) return /متوسطهٔ? ?دوم/.test(lvl);
  return list('classes').some(c => String(c.mode || '') === 'field' || (String(c.kind || '') !== 'room' && String(c.branch || '')));
}

/* یک ردیف تعریف با دکمه‌های ویرایش و حذف */
function lookupRowHtml(row, kind, field) {
  const grade = kind === 'grade';
  const key = v => (grade ? gradeKey(v) : defKey(v));
  const k = key(row.name);
  const used = list('classes').filter(c => String(c.kind || '') !== 'room' && key(grade ? c.grade : c.branch) === k).length;
  const others = new Set();
  let students = 0;
  for (const u of list('users')) {
    if (!rosterStudent(u)) continue;
    const p = stuPlace(u);
    if (key(grade ? p.g : p.b) !== k) continue;
    students++;
    const o = grade ? defKey(p.b) : gradeKey(p.g);
    if (o) others.add(o);
  }
  for (const c of list('classes')) {
    if (String(c.kind || '') === 'room' || key(grade ? c.grade : c.branch) !== k) continue;
    const o = grade ? defKey(c.branch) : gradeKey(c.grade);
    if (o) others.add(o);
  }
  /* ردیف ۲۰۴: مدرسهٔ رشته‌محور «کلاس» ندارد — رشته در چند پایه است، پایه چند رشته دارد */
  const sub = field
    ? (others.size ? (grade ? fa(others.size) + ' رشته' : 'در ' + fa(others.size) + ' پایه') : (students ? '' : 'بدون استفاده'))
    : (used ? fa(used) + ' کلاس از این مورد استفاده می‌کند' : 'بدون استفاده');
  const actions = `<button class="btn sm ghost" data-act="def-edit" data-id="${row.id}">ویرایش</button>
       <button class="btn sm ghost" style="color:#b91c1c" data-act="def-delete" data-id="${row.id}">حذف</button>`;
  return `<div class="item"><div class="grow"><div class="t">${esc(row.name)}${students ? ' ' + badge(fa(students) + ' دانش‌آموز', 'green') : ''}</div>
      <div class="s">${sub}</div></div>
    ${actions}</div>`;
}

/* ردیف ۲۰۴: دانش‌آموزانی که هیچ پایه/رشتهٔ تعریف‌شده‌ای شمرده نشده‌اند — تا جمع ستون‌ها درست باشد */
function unassignedHtml(kind) {
  const grade = kind === 'grade';
  const defs = new Set(lookupList(kind).map(l => (grade ? gradeKey(l.name) : defKey(l.name))).filter(Boolean));
  const n = list('users').filter(u => {
    if (!rosterStudent(u)) return false;
    const p = stuPlace(u);
    const v = grade ? gradeKey(p.g) : defKey(p.b);
    return !v || !defs.has(v);
  }).length;
  if (!n) return '';
  return `<div class="item"><div class="grow"><div class="t">بدون ${LOOKUP_FA[kind]} ${badge(fa(n) + ' دانش‌آموز', 'amber')}</div>
      <div class="s">${LOOKUP_FA[kind]} خالی یا ناشناخته — از «کاربران» یا «پیگیری» درست کنید</div></div></div>`;
}

/* ══════════════ مدیر: کلاس‌ها و تعریف‌ها ══════════════ */
PAGES.classes = () => {
  if (S.role !== 'manager') return pageHead('کلاس‌ها') + empty('دسترسی ندارید.');
  const all = sortBy(list('classes'), 'name');
  const subjects = sortBy(list('subjects'), 'name');
  const countOf = id => list('users').filter(u => u.role === 'student' && Number(u.class_id) === Number(id)).length;
  /* گروه‌های خودکارِ ورود دسته‌ایِ قدیمی (kind='group') دیگر کلاس نیستند؛
     کلاس فقط چیزی است که مدیر خودش ساخته است. */
  const rooms = sortBy(all.filter(c => String(c.kind || '') === 'room'), 'name');
  const isFieldSchool = isFieldSchoolNow();

  const roomsCard = card(
    `<div class="row between" style="margin-bottom:8px"><b>🏫 کلاس‌ها و کارگاه‌ها (محل برگزاری)</b>
       <span class="row" style="gap:6px">
         <span class="small muted">${fa(rooms.length)} مورد</span>
         <button class="btn sm primary" data-act="room-add">+ کلاس/کارگاه</button></span></div>
     <div class="small muted" style="margin-bottom:8px;line-height:2">فقط نام لازم است؛ همین نام در برنامهٔ هفتگی به هر زنگ داده می‌شود.</div>
     ${rooms.length ? `<div class="table-wrap"><table><thead><tr><th>نام</th><th>دانش‌آموز</th><th></th></tr></thead><tbody>
       ${rooms.map(c => `<tr><td><b>${esc(c.name)}</b></td><td>${fa(countOf(c.id))}</td>
         <td class="nowrap"><button class="btn sm ghost" data-act="room-edit" data-id="${esc(c.id)}">ویرایش</button>
         <button class="btn sm ghost" data-act="class-delete" data-id="${esc(c.id)}" style="color:#b91c1c">حذف</button></td></tr>`).join('')}
     </tbody></table></div>` : `<div class="small muted">${isFieldSchool ? 'هنوز محل برگزاری تعریف نشده است.' : 'هنوز کلاس یا کارگاهی تعریف نشده است.'}</div>`}`);

  const headerAction = isFieldSchool
    ? ''
    : `<button class="btn sm primary" data-act="class-add">+ کلاس جدید</button>`;
  /* ردیف ۱۸۵: سه ستون کنار هم — پایه‌ها راست، رشته‌ها وسط، کلاس و محل برگزاری چپ */
  /* ردیف ۲۰۴: در مدرسهٔ رشته‌محور «کلاس» فقط محل برگزاری است */
  return `${pageHead(isFieldSchool ? 'پایه‌ها، رشته‌ها و محل برگزاری' : 'کلاس‌ها و تعریف‌ها', '', headerAction)}

  ${card(`<div class="row between" style="margin-bottom:8px"><b>پایه‌ها</b>
      <button class="btn sm" data-act="def-add" data-kind="grade">+ پایه</button></div>
    <div class="list">${lookupList('grade').map(r => lookupRowHtml(r, 'grade', isFieldSchool)).join('')}${unassignedHtml('grade')}</div>`)}

  ${isFieldSchool ? card(`<div class="row between" style="margin-bottom:8px"><b>رشته‌ها</b>
      <button class="btn sm" data-act="def-add" data-kind="branch">+ رشته</button></div>
    <div class="list">${lookupList('branch').map(r => lookupRowHtml(r, 'branch', true)).join('')}${unassignedHtml('branch')}</div>`) : ''}

  ${roomsCard}

  ${card(`<div class="row between" style="margin-bottom:8px"><b>دروس</b>
      <button class="btn sm" data-act="subject-add">+ درس</button></div>
    ${subjects.length ? `<div class="list">${subjects.map(sub => `<div class="item">
        <div class="grow"><div class="t">${esc(sub.name)}${sub.workshop ? ' <span class="badge purple">کارگاهی</span>' : ''}</div>
        <div class="s">${fa(list('schedule').filter(x => Number(x.subject_id) === Number(sub.id)).length)} زنگ در برنامه</div></div>
        <button class="btn sm ghost" data-act="subject-edit" data-id="${sub.id}">ویرایش</button>
        <button class="btn sm ghost" style="color:#b91c1c" data-act="subject-delete" data-id="${sub.id}">حذف</button>
      </div>`).join('')}</div>` : empty('درسی تعریف نشده.')}`)}`;
};

/* ══════════════ برنامه و زنگ ══════════════ */
PAGES.schedule = () => (typeof window.schedPage === 'function' ? window.schedPage() : empty('برنامه در دسترس نیست.'));

/* ══════════════ گزارش‌ها ══════════════ */
PAGES.reports = () => {
  if (S.role !== 'manager') return pageHead('گزارش‌ها') + empty('دسترسی ندارید.');
  const today = todayISO();
  const classes = sortBy(list('classes'), 'name');
  const att = list('attendance');
  const week = [...Array(7)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - i); return d.toISOString().slice(0, 10); });
  const rows = classes.map(c => {
    const rowsC = att.filter(a => Number(a.class_id) === Number(c.id) && week.includes(a.date));
    const p = rowsC.filter(a => a.status === 'present').length;
    const ab = rowsC.filter(a => a.status === 'absent').length;
    const lt = rowsC.filter(a => a.status === 'late').length;
    const pct = rowsC.length ? Math.round(p / rowsC.length * 100) : 0;
    return { c, p, ab, lt, pct, n: rowsC.length };
  });
  return `${pageHead('گزارش‌ها', 'هفتهٔ اخیر', `<button class="btn sm" data-act="print">🖨️ چاپ</button>`)}
  ${card(`<b>حضور هفتگی به تفکیک ${isFieldSchoolNow() ? 'پایه و رشته' : 'کلاس'}</b>
    <div class="table-wrap"><table><thead><tr><th>${isFieldSchoolNow() ? 'پایه و رشته' : 'کلاس'}</th><th>ثبت</th><th>حاضر</th><th>غایب</th><th>تأخیر</th><th>درصد</th></tr></thead><tbody>
    ${rows.map(r => `<tr><td>${esc(r.c.name)}</td><td>${fa(r.n)}</td><td>${fa(r.p)}</td><td>${fa(r.ab)}</td><td>${fa(r.lt)}</td>
      <td>${badge(fa(r.pct) + '٪', r.pct >= 90 ? 'green' : r.pct >= 75 ? 'amber' : 'red')}</td></tr>`).join('')}
    </tbody></table></div>`)}
  ${card(`<div class="row between"><b>${isFieldSchoolNow() ? 'کارنامهٔ پایه و رشته' : 'کارنامهٔ کلاسی'}</b>
      <select class="input" style="max-width:240px" id="rc-class" data-set="repClass">
        ${classes.map(c => `<option value="${c.id}" ${Number(S.repClass) === Number(c.id) ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
      </select></div>
    <div class="table-wrap" style="margin-top:8px">${classReportTable(Number(S.repClass || (classes[0] && classes[0].id)))}</div>
    <div class="small muted" style="margin-top:8px">میانگین‌ها از نمرات ثبت‌شده محاسبه می‌شوند؛ برای چاپ، دکمهٔ «چاپ» بالا.</div>`)}`;
};

function classReportTable(classId) {
  const roster = sortBy(list('users').filter(u => u.role === 'student' && Number(u.class_id) === Number(classId)), 'name');
  const subs = [...new Set(list('grades').filter(g => Number(g.class_id) === Number(classId)).map(g => g.subject_id))]
    .sort((a, b) => alphaCompare((byId('subjects', a) || {}).name, (byId('subjects', b) || {}).name));
  const att = list('attendance').filter(a => Number(a.class_id) === Number(classId));
  if (!roster.length) return '<div class="muted small">دانش‌آموزی نیست.</div>';
  return `<table><thead><tr><th>دانش‌آموز</th>${subs.map(id => `<th>${esc((byId('subjects', id) || {}).name || '')}</th>`).join('')}<th>معدل</th><th>حضور</th></tr></thead><tbody>
    ${roster.map(s => {
      const gs = list('grades').filter(g => Number(g.student_id) === Number(s.id));
      const cells = subs.map(id => { const g = gs.find(x => Number(x.subject_id) === Number(id)); return `<td>${g ? fa(g.score) : '—'}</td>`; }).join('');
      const avg = gs.length ? gs.reduce((a, x) => a + Number(x.score || 0), 0) / gs.length : 0;
      const a = att.filter(x => Number(x.student_id) === Number(s.id));
      const pct = a.length ? Math.round(a.filter(x => x.status === 'present').length / a.length * 100) : 0;
      return `<tr><td>${esc(s.name)}</td>${cells}<td><b>${fa(avg.toFixed(2))}</b></td><td>${fa(pct)}٪</td></tr>`;
    }).join('')}
  </tbody></table>`;
}

/* ══════════════ حضور — نمای مدیر ══════════════ */
PAGES['attendance-report'] = () => {
  if (S.role !== 'manager') return pageHead('حضور') + empty('دسترسی ندارید.');
  const date = S.attDate || todayISO();
  const all = list('attendance').filter(a => a.date === date);
  const byClass = sortBy(list('classes'), 'name').map(c => ({ c, rows: all.filter(a => Number(a.class_id) === Number(c.id)) }));
  return `${pageHead('حضور و غیاب', jdate(date), jalaliDateControl('', date, { id: 'att-date', target: 'attDate', bindState: true, maxWidth: '180px', focusKey: 'att-date' }))}
  ${byClass.map(({ c, rows }) => card(`<div class="row between"><b>${esc(c.name)}</b>
      <span class="small muted">${rows.length ? fa(rows.filter(r => r.status === 'present').length) + ' حاضر از ' + fa(rows.length) : 'ثبت نشده'}</span></div>
    ${rows.length ? `<div class="row" style="margin-top:6px">${rows.filter(r => r.status !== 'present').map(r => `<span class="badge red">${esc((byId('users', r.student_id) || {}).name || '')} · ${ATT_LABEL[r.status] || r.status}</span>`).join(' ') || '<span class="small muted">همه حاضر</span>'}</div>` : ''}`)).join('')}`;
};

/* ══════════════ اطلاعیه‌ها ══════════════ */
PAGES.announcements = () => {
  const rows = sortBy(list('announcements'), 'date').reverse();
  const canWrite = S.role === 'manager';
  return `${pageHead('اطلاعیه‌ها', fa(rows.length) + ' مورد', canWrite ? `<button class="btn sm primary" data-act="ann-add">+ اطلاعیه</button>` : '')}
  ${rows.length ? rows.map(a => card(`<div class="row between"><b>${esc(a.title)}</b>${badge(jdate(a.date), a.severity === 'important' ? 'red' : a.severity === 'info' ? 'purple' : '')}</div>
    <div class="small" style="margin-top:6px;white-space:pre-wrap">${esc(a.body)}</div>
    ${canWrite ? `<div class="row" style="gap:8px;margin-top:8px">
      <button class="btn sm ghost" data-act="ann-edit" data-id="${a.id}">ویرایش</button>
      <button class="btn sm ghost" style="color:#b91c1c" data-act="ann-delete" data-id="${a.id}">حذف</button>
    </div>` : ''}`)).join('') : empty('اطلاعیه‌ای ثبت نشده.')}`;
};

/* ══════════════ ولی ══════════════ */
function myChildren() {
  const links = list('parent_links').filter(l => Number(l.parent_id) === Number(S.user.id));
  return links.map(l => byId('users', l.student_id)).filter(Boolean);
}

PAGES.home = (params) => {
  if (S.role === 'manager') return managerHome();
  if (S.role === 'teacher') return teacherHome();
  if (S.role === 'parent') return parentHome();
  if (S.role === 'student') return studentHome();
  return staffHome();
};

/* ردیف ۱۸۷: خانهٔ مشاور، نگهبان، کارمند و اجرایی (صفحه‌های عمومیِ p2) — تازه‌ترین اطلاعیه‌ها
   و برای مشاور شمارِ ارجاع‌های باز */
function staffHome() {
  const anns = list('announcements').slice()
    .sort((a, b) => String(b.created_at || b.date || '').localeCompare(String(a.created_at || a.date || ''))).slice(0, 3);
  const open = S.role === 'counselor' ? list('counselor_refs').filter(r => r.status === 'open').length : 0;
  return `${pageHead('خانه', esc(ROLE_FA[roleTitle()] || ''))}
  ${S.role === 'counselor' ? card(`<div class="row between"><b>📨 صف ارجاع</b>${badge(fa(open) + ' باز', open ? 'amber' : 'green')}</div>
    <a class="btn sm" href="#/cqueue" style="margin-top:8px">دیدن صف</a>`, 'tight') : ''}
  ${card(`<div class="row between"><b>📢 تازه‌ترین اطلاعیه‌ها</b><a class="small" href="#/announcements">همه</a></div>
    ${anns.length ? `<div class="list">${anns.map(a => `<div class="item"><div class="grow"><div class="t">${esc(a.title || '')}</div>
      <div class="s">${esc(String(a.body || '').slice(0, 120))}</div></div></div>`).join('')}</div>` : '<div class="small muted">اطلاعیه‌ای نیست.</div>'}`)}`;
}

function parentHome() {
  const params = S.params || [];
  /* ردیف ۱۸۰ — طرح ۲ «مینیمال حرفه‌ای» در گوشی، مو به مو: تاریخ کم‌رنگ بالای «سلام»، زنگوله؛
     تراشهٔ فرزندان (#/home/<id> انتخاب می‌کند)، دو کاشی فرزند انتخاب‌شده (حضور، معدل بنفش)،
     «برنامهٔ امروز» با زنگ جاری بنفش و «اکنون»، تازه‌ترین اطلاعیه، مرخصی / اطلاعیه‌ها. */
  const kids = myChildren();
  const pick = Number((params || [])[0] || 0);
  const k = kids.find(x => Number(x.id) === pick) || kids[0];
  const today = todayISO();
  const day = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه'][(new Date(today + 'T12:00:00').getDay() + 1) % 7];
  const notes = list('announcements').filter(n => !n.deleted).sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')) || Number(b.id) - Number(a.id));
  const head = `<div class="d2-top ph-top"><div class="hello"><p class="ph-date">${esc(day)} ${esc(fa(jdate(today)))}</p><h1>سلام، ${esc(S.user ? S.user.name : '')}</h1></div>
    <div class="row"><button class="icon-b" data-act="sync" title="همگام‌سازی" aria-label="همگام‌سازی">${d2Ico('sync')}</button>
    <a class="icon-b${notes.length ? ' dot' : ''}" href="#/announcements" title="اطلاعیه‌ها" aria-label="اطلاعیه‌ها">${d2Ico('bell')}</a></div></div>`;
  if (!kids.length) return head + empty('فرزندی به حساب شما متصل نیست — با دفتر مدرسه تماس بگیرید.') + cloudCard(kids)
    + `<div class="ph-acts"><a class="btn grow" href="#/leaves">درخواست مرخصی</a><a class="btn grow" href="#/announcements">اطلاعیه‌ها</a></div>`;
  const chips = `<div class="kid-chips">${kids.map(x => {
    const c = byId('classes', x.class_id) || {};
    const first = String(x.name || '').trim().split(/\s+/)[0] || '';
    return `<a class="kid-chip${Number(x.id) === Number(k.id) ? ' on' : ''}" href="#/home/${x.id}"><i>${esc(first.charAt(0) || '؟')}</i>${esc(String(x.name || '').trim())}${c.name ? ' · ' + esc(c.name) : ''}</a>`;
  }).join('')}</div>`;
  const cls = byId('classes', k.class_id) || {};
  const g = list('grades').filter(x => Number(x.student_id) === Number(k.id) && x.status === 'approved');
  const avg = g.length ? (g.reduce((a, x) => a + Number(x.score || 0), 0) / g.length) : 0;
  const att = list('attendance').filter(x => Number(x.student_id) === Number(k.id));
  const pct = att.length ? Math.round(att.filter(x => x.status === 'present').length / att.length * 100) : 0;
  const avgTone = avg >= 15 ? 'green' : avg >= 10 ? 'amber' : 'red';
  const pctTone = pct >= 90 ? 'green' : 'amber';
  const tiles = `<div class="ph-tiles">
    <a class="ph-tile" href="#/child/${k.id}" data-tone="${pctTone}"><span>حضور</span><b>${att.length ? fa(pct) + '٪' : '—'}</b><small>${!att.length ? 'هنوز ثبت نشده' : pct >= 100 ? 'بدون غیبت' : fa(att.length) + ' جلسهٔ ثبت‌شده'}</small></a>
    <a class="ph-tile v" href="#/child/${k.id}" data-tone="${avgTone}"><span>میانگین نمره</span><b>${g.length ? fa(avg.toFixed(1)) : '—'}</b><small>${g.length ? fa(g.length) + ' نمرهٔ تأییدشده' : 'نمرهٔ تأییدشده‌ای نیست'}</small></a></div>`;
  const wd = (new Date(today + 'T12:00:00').getDay() + 1) % 7;
  const bells = new Map(pageBellRows().filter(b => !b.is_break).map(b => [Number(b.order), b]));
  const cur = typeof currentBell === 'function' ? currentBell() : null;
  const slots = list('schedule').filter(x => Number(x.weekday) === wd && (Number(x.class_id) === Number(k.class_id)
      || (cls.grade && String(x.grade || '') === String(cls.grade) && String(x.branch || '') === String(cls.branch || ''))))
    .sort((a, b) => Number(a.bell_order) - Number(b.bell_order));
  const plan = card(`<div class="card-h"><h3>برنامهٔ امروز</h3>${slots.length ? `<span class="small muted" style="margin-inline-start:auto">${fa(slots.length)} زنگ</span>` : ''}</div>
    ${slots.length ? `<ul class="ph-plan">${slots.map(x => {
      const b = bells.get(Number(x.bell_order)) || {};
      const now = cur && Number(cur.order) === Number(x.bell_order);
      const sub = byId('subjects', x.subject_id) || {};
      const t = byId('users', x.teacher_id) || {};
      return `<li class="${now ? 'now' : ''}"><time>${esc(fa(b.start || '—'))}</time><i></i><div class="grow"><b>${esc(sub.name || '—')}</b>${t.name ? `<small>${esc(t.name)}</small>` : ''}</div>${now ? '<span class="now-pill">اکنون</span>' : ''}</li>`;
    }).join('')}</ul>` : '<div class="small muted" style="padding:10px 0">امروز زنگ درسی در برنامه نیست.</div>'}`, 'd2c');
  const n = notes[0];
  const note = n ? `<a class="card d2c ph-note" href="#/announcements"><span class="n-ic">${d2Ico('chat')}</span><div class="grow"><b>${esc(n.title || '')}</b><small>${esc(fa(jdate(n.date || '')))}${n.body ? ' · ' + esc(String(n.body).replace(/\n/g, ' ')) : ''}</small></div></a>` : '';
  return `${head}${chips}${tiles}${plan}${note}${cloudCard(kids)}
  <div class="ph-acts"><a class="btn grow" href="#/leaves">درخواست مرخصی</a><a class="btn grow" href="#/announcements">اطلاعیه‌ها</a></div>`;
}

/* ── وضعیت آفلاین و صندوقچهٔ ابری ──
   دادهٔ نمایش‌داده‌شده همان آخرین همگام‌سازی این دستگاه است؛ ثبت‌ها در صف
   می‌مانند و اولین سیستم/دستگاهی که روشن شود آن‌ها را اعمال می‌کند. */
function cloudCard(kids) {
  const q = (S.queue || []).length;
  const ob = S.outbox || {};
  if (!q && !ob.pending) return '';
  const rows = [];
  if (q) rows.push(`<div class="small" style="margin-top:6px">📤 <b>${fa(q)}</b> تغییر روی همین دستگاه ثبت شده و هنوز اعمال نشده.</div>`);
  if (ob.pending) rows.push(`<div class="small" style="margin-top:6px">📦 <b>${fa(ob.pending)}</b> ثبت از دستگاه‌های دیگر در صندوقچهٔ ابری منتظر است.</div>`);
  if (ob.last_drain) rows.push(`<div class="small muted" style="margin-top:4px">آخرین اعمال: ${esc(jdate(ob.last_drain))}</div>`);
  return card(`<div class="row between"><b>📥 صندوقچهٔ ابری</b>${badge('در انتظار اعمال', 'amber')}</div>
    ${rows.join('')}
    <div class="small muted" style="margin-top:6px">لازم نیست کاری کنید: اولین سیستمی که روشن شود (مدرسه، خانه یا گوشیِ کادر) خودش این‌ها را اعمال می‌کند.</div>`);
}

PAGES.child = (params) => {
  const kids = myChildren();
  const k = byId('users', Number(params[0])) || kids[0];
  if (!k) return pageHead('پرونده') + empty('برای حساب شما فرزندی ثبت نشده است.');
  const cls = byId('classes', k.class_id) || {};
  const grades = list('grades').filter(g => Number(g.student_id) === Number(k.id));
  const att = list('attendance').filter(a => Number(a.student_id) === Number(k.id)).sort((a, b) => String(b.date).localeCompare(String(a.date)));
  const pct = att.length ? Math.round(att.filter(a => a.status === 'present').length / att.length * 100) : 0;
  const avg = grades.length ? grades.reduce((a, g) => a + Number(g.score || 0), 0) / grades.length : 0;
  const internships = list('internships').filter(i => Number(i.student_id) === Number(k.id));
  return `${pageHead(k.name, cls.name || '', `<a class="btn sm" href="#/home">بازگشت</a>`)}
  <div class="grid">
    ${statCard('📊', fa(avg.toFixed(1)), 'معدل', avg >= 15 ? 'green' : avg >= 10 ? '' : 'red')}
    ${statCard('✅', fa(pct) + '٪', 'حضور', pct >= 90 ? 'green' : 'amber')}
    ${statCard('📝', fa(grades.length), 'نمره ثبت‌شده')}
  </div>
  ${card(`<b>نمرات</b><div class="table-wrap" style="margin-top:8px"><table><thead><tr><th>درس</th><th>نوبت</th><th>نمره</th><th>وضعیت</th></tr></thead><tbody>
    ${grades.map(g => `<tr><td>${esc((byId('subjects', g.subject_id) || {}).name || '—')}</td><td class="small">${esc(g.term || '')}</td>
      <td><b>${fa(g.score)}</b>${g.practical_score != null ? `<span class="small muted"> (عملی ${fa(g.practical_score)})</span>` : ''}</td>
      <td>${badge(g.status === 'approved' ? 'تأییدشده' : 'در انتظار', g.status === 'approved' ? 'green' : 'amber')}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">نمره‌ای ثبت نشده</td></tr>'}
  </tbody></table></div>`)}
  ${card(`<b>حضور و غیاب</b><div class="table-wrap" style="margin-top:8px"><table><thead><tr><th>تاریخ</th><th>وضعیت</th></tr></thead><tbody>
    ${att.slice(0, 12).map(a => `<tr><td>${esc(jdate(a.date))}</td><td>${badge(ATT_LABEL[a.status] || a.status, a.status === 'present' ? 'green' : a.status === 'absent' ? 'red' : 'amber')}</td></tr>`).join('') || '<tr><td colspan="2" class="muted">ثبت نشده</td></tr>'}
  </tbody></table></div>`)}
  ${internships.length ? card(`<b>کارآموزی</b><div class="table-wrap" style="margin-top:8px"><table><thead><tr><th>تاریخ</th><th>ساعت</th><th>محل</th><th>وضعیت</th></tr></thead><tbody>
    ${internships.map(i => `<tr><td>${esc(jdate(i.date))}</td><td>${fa(i.hours)}</td><td class="small">${esc(i.location || '')}</td>
      <td>${badge(i.status === 'approved' ? 'تأییدشده' : 'در انتظار', i.status === 'approved' ? 'green' : 'amber')}</td></tr>`).join('')}
  </tbody></table></div>`) : ''}`;
};

/* ══════════════ صف ارجاع مشاور (ردیف ۱۸۷ — تعریفِ p2) ══════════════
   مدیر/معاون دانش‌آموز را ارجاع می‌دهد؛ مشاور فقط همین صف را می‌بیند: نام، پایه/رشته،
   علت و الگوی حضورِ ۳۰ روز اخیر — نه نمره و نه پروندهٔ کامل. */
function crefPattern(studentId) {
  const since = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);
  const rows = list('attendance').filter(a => Number(a.student_id) === Number(studentId) && String(a.date || '') >= since);
  const n = st => rows.filter(a => a.status === st).length;
  return { absent: n('absent'), late: n('late'), exit: n('early_exit') };
}
PAGES.cqueue = () => {
  if (S.role !== 'manager' && S.role !== 'counselor') return pageHead('صف ارجاع') + empty('دسترسی ندارید.');
  const isMgr = S.role === 'manager';
  const refs = list('counselor_refs').slice().sort((a, b) =>
    (a.status === 'open' ? 0 : 1) - (b.status === 'open' ? 0 : 1) ||
    String(b.referred_at || '').localeCompare(String(a.referred_at || '')));
  const open = refs.filter(r => r.status === 'open').length;
  const rows = refs.map(r => {
    const st = byId('users', r.student_id) || {};
    const p = crefPattern(r.student_id);
    const who = [st.grade, st.branch].filter(Boolean).join(' · ');
    return card(`<div class="row between"><b>${esc(st.name || ('دانش‌آموز ' + fa(r.student_id)))}</b>
        ${badge(r.status === 'open' ? 'باز' : 'پیگیری شد', r.status === 'open' ? 'amber' : 'green')}</div>
      <div class="small muted">${esc(who)}${who ? ' · ' : ''}ارجاع: ${esc(jdate(String(r.referred_at || '').slice(0, 10)))}</div>
      <div class="small" style="margin-top:4px">${esc(r.reason || '')}</div>
      <div class="small muted" style="margin-top:4px">۳۰ روز اخیر: غیبت ${fa(p.absent)} · تأخیر ${fa(p.late)} · خروج زودهنگام ${fa(p.exit)}</div>
      ${r.note ? `<div class="small" style="margin-top:4px">📝 ${esc(r.note)}</div>` : ''}
      ${r.status === 'open' ? `<div class="row" style="margin-top:8px;gap:8px">
        <button class="btn sm primary" data-act="cref-done" data-id="${r.id}">پیگیری شد</button></div>` : ''}`, 'tight');
  }).join('');
  return `${pageHead('صف ارجاع', fa(open) + ' ارجاعِ باز', isMgr ? `<button class="btn sm primary" data-act="cref-add">+ ارجاع به مشاور</button>` : '')}
  ${rows || empty(isMgr ? 'هنوز دانش‌آموزی به مشاور ارجاع نشده است.' : 'دانش‌آموزی به شما ارجاع نشده است.')}`;
};

function actCrefAdd() {
  const studs = sortBy(list('users').filter(u => u.role === 'student' && u.active !== false), 'name');
  S.modalTitle = 'ارجاع به مشاور';
  modal(`<form data-form="cref">
    <label class="field"><span>دانش‌آموز</span><select class="input" name="student_id" required>
      <option value="">— انتخاب —</option>${studs.map(k => `<option value="${k.id}">${esc(k.name)}</option>`).join('')}
    </select></label>
    <label class="field"><span>علت ارجاع</span><textarea class="input" name="reason" required placeholder="مثلاً تأخیر مکرر در این ماه"></textarea></label>
    <button class="btn primary block">ثبت ارجاع</button>
  </form>`);
}

/* ردیف ۱۹۷ (Q02 / F25، F28): مرخصی کامل — روزانه (یک روز یا بازه) یا ساعتی (خروج زودهنگام /
   ورود دیرتر)، نوع، و پیوست گواهی. همان قواعد packages/payesh_sync/lib/src/leave_spec.dart و
   server/policy.js `leaveIssue`. */
const LEAVE_TYPES = [['sick', 'استعلاجی (بیماری)'], ['family', 'خانوادگی'], ['personal', 'شخصی / ضروری'], ['travel', 'سفر'], ['other', 'سایر']];
const LEAVE_MAX_DAYS = 31;
const LEAVE_ATTACH_MAX = 60000;
const LEAVE_ISSUE_FA = {
  bad_date: 'تاریخ را درست انتخاب کنید',
  bad_range: 'تاریخ پایان نباید پیش از تاریخ شروع باشد',
  range_too_long: 'هر درخواست حداکثر ۳۱ روز است',
  bad_kind: 'نوع مرخصی (روزانه/ساعتی) درست نیست',
  bad_time: 'ساعت شروع و پایان را درست بنویسید (مثلاً ۱۰:۰۰ تا ۱۲:۳۰)',
  bad_type: 'نوع مرخصی شناخته نشد',
  reason_too_long: 'علت بیش از ۵۰۰ نویسه است',
  bad_attachment: 'پیوست باید عکس (JPG/PNG) و کم‌حجم باشد',
  leave_decided: 'این درخواست بررسی شده و دیگر تغییر نمی‌کند',
  approval_denied: 'تأیید یا رد مرخصی فقط با مدیر/معاون است',
};
function leaveIsoOk(v) {
  const t = String(v || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t)) return null;
  const d = new Date(t + 'T00:00:00Z');
  return isNaN(d) || d.toISOString().slice(0, 10) !== t ? null : d;
}
function leaveIssue(d) {
  const from = leaveIsoOk(d.date);
  if (!from) return 'bad_date';
  const kind = String(d.kind || 'day');
  if (kind !== 'day' && kind !== 'hours') return 'bad_kind';
  const to = String(d.date_to || '');
  if (kind === 'day' && to) {
    const t = leaveIsoOk(to);
    if (!t) return 'bad_date';
    if (t < from) return 'bad_range';
    if (Math.round((t - from) / 86400000) + 1 > LEAVE_MAX_DAYS) return 'range_too_long';
  }
  if (kind === 'hours') {
    const hm = /^([01]\d|2[0-3]):[0-5]\d$/;
    const a = String(d.time_from || ''), b = String(d.time_to || '');
    if (!hm.test(a) || !hm.test(b) || a >= b) return 'bad_time';
    if (to && to !== String(d.date)) return 'bad_range';
  }
  if (d.type && !LEAVE_TYPES.some(([k]) => k === d.type)) return 'bad_type';
  if (String(d.reason || '').trim().length > 500) return 'reason_too_long';
  const att = String(d.attachment || '');
  if (att && (att.length > LEAVE_ATTACH_MAX || !/^data:image\/(jpeg|png);base64,[A-Za-z0-9+/=]+$/.test(att))) return 'bad_attachment';
  return null;
}
function leaveDays(l) {
  const a = leaveIsoOk(l.date), b = leaveIsoOk(l.date_to);
  return a && b && b >= a ? Math.round((b - a) / 86400000) + 1 : 1;
}
function leaveWhenFa(l) {
  if (l.kind === 'hours') return `${jdate(l.date)} · ساعت ${fa(l.time_from || '')} تا ${fa(l.time_to || '')}`;
  if (l.date_to && l.date_to !== l.date) return `${jdate(l.date)} تا ${jdate(l.date_to)} (${fa(leaveDays(l))} روز)`;
  return jdate(l.date);
}
function leaveTypeFa(t) { const x = LEAVE_TYPES.find(([k]) => k === t); return x ? x[1] : ''; }
function leaveCovers(l, iso) {
  if (!l || !l.date) return false;
  const to = (l.kind === 'hours' || !l.date_to) ? l.date : l.date_to;
  return iso >= l.date && iso <= to;
}
function leaveApprovedOn(sid, iso) {
  const ls = list('leaves').filter(l => Number(l.student_id) === Number(sid) && l.status === 'approved' && leaveCovers(l, iso));
  return ls.find(l => l.kind !== 'hours') || ls[0] || null;
}
function leaveTagFa(l) {
  if (l.kind === 'hours') return 'مرخصی ساعتی ' + fa(l.time_from || '') + ' تا ' + fa(l.time_to || '');
  return l.type ? 'مرخصی (' + leaveTypeFa(l.type).split(' ')[0] + ')' : 'مرخصی';
}
function attDefaultStatus(sid, iso) {
  const l = leaveApprovedOn(sid, iso);
  return l && l.kind !== 'hours' ? 'excused' : 'present';
}
function leavePendingCount() { return list('leaves').filter(l => !l.status || l.status === 'pending').length; }

PAGES.leaves = () => {
  /* ردیف ۱۸۷: تأیید/رد مرخصی فقط با مدیر/معاون (server/policy.js) */
  const canManage = S.role === 'manager';
  const mine = S.role === 'parent' ? myChildren().map(k => Number(k.id)) : [Number(S.user.id)];
  let rows = list('leaves');
  if (!canManage) rows = rows.filter(l => mine.includes(Number(l.student_id)));
  /* ردیف ۱۹۷: «در انتظار» همیشه بالا، بعد تازه‌ترین روز */
  const pend = l => (!l.status || l.status === 'pending') ? 0 : 1;
  rows = rows.sort((a, b) => pend(a) - pend(b) || String(b.date || '').localeCompare(String(a.date || '')) || String(b.created_at || '').localeCompare(String(a.created_at || '')));
  const waiting = rows.filter(l => pend(l) === 0).length;
  const sub = fa(rows.length) + ' درخواست' + (waiting ? ' · ' + fa(waiting) + ' در انتظار' : '');
  return `${pageHead('مرخصی و غیبت موجه', sub, `<button class="btn sm primary" data-act="leave-add" aria-label="${canManage ? 'ثبت مرخصی' : 'درخواست مرخصی'}">${canManage ? '+ ثبت مرخصی' : '+ درخواست'}</button>`)}
  ${rows.length ? rows.map(l => card(`<div class="row between"><b>${esc((byId('users', l.student_id) || {}).name || '')}</b>
      ${badge(l.status === 'approved' ? 'تأییدشده' : l.status === 'rejected' ? 'رد شده' : 'در انتظار', l.status === 'approved' ? 'green' : l.status === 'rejected' ? 'red' : 'amber')}</div>
    <div class="small muted" data-leave-when="${l.id}">${esc(leaveWhenFa(l))}${l.type ? ' · ' + esc(leaveTypeFa(l.type)) : ''}${l.reason ? ' · ' + esc(l.reason) : ''}</div>
    ${l.attachment ? `<div style="margin-top:6px"><button class="btn sm ghost" data-act="leave-att" data-id="${l.id}">📎 دیدن گواهی پیوست</button></div>` : ''}
    ${canManage ? `<div class="row" style="gap:8px;margin-top:8px">
      <button class="btn sm" data-act="leave-set" data-id="${l.id}" data-status="approved">تأیید</button>
      <button class="btn sm ghost" data-act="leave-set" data-id="${l.id}" data-status="rejected">رد</button>
      <button class="btn sm ghost" style="color:#b91c1c" data-act="leave-delete" data-id="${l.id}">حذف</button>
    </div>` : ''}`)).join('') : empty('درخواستی ثبت نشده.')}`;
};

/* مشخصات شناسنامه‌ای و خانوادگی — همان فیلدهایی که از اکسل (یا فرم
   کاربر) ذخیره می‌شوند؛ هر کدام پر بود، نمایش داده می‌شود. */
function userDetailRows(u) {
  const rows = [];
  const add = (label, v) => {
    const t = (v === undefined || v === null) ? '' : String(v).trim();
    if (t && t !== '—') rows.push([label, t]);
  };
  add('تاریخ تولد', u.birth_date ? (typeof impIsoToJalali === 'function' ? impIsoToJalali(u.birth_date) : u.birth_date) : '');
  add('جنسیت', u.gender);
  add('شمارهٔ شناسنامه', [u.shenasname_seri, u.shenasname_serial].filter(x => x && String(x).trim()).join(' — '));
  add('نام پدر', u.father_name);
  add('کد ملی پدر', u.father_nid);
  add('همراه پدر', u.father_phone);
  add('نام مادر', u.mother_name);
  add('کد ملی مادر', u.mother_nid);
  add('همراه مادر', u.mother_phone);
  add('سرپرست', u.guardian);
  add('معدل سال گذشته', u.last_gpa != null ? fa(u.last_gpa) : '');
  add('درس‌های تجدیدی', u.failed_count != null ? fa(u.failed_count) : '');
  add('حمایتی', u.covered);
  add('نوع حمایت', u.org_type);
  add('درصد حمایت', u.org_percent != null ? fa(u.org_percent) + '٪' : '');
  add('استعداد', u.talent);
  add('تلفن ثابت', u.landline);
  add('شمارهٔ همراه', u.phone);
  add('کد ملی', u.national_id);
  add('محل سکونت', [u.residence, u.village].filter(x => x && String(x).trim() && String(x).trim() !== '—').join(' — '));
  add('وضعیت سکونت', u.residence_status);
  add('نشانی', u.address);
  add('خواهر', u.sisters != null ? fa(u.sisters) : '');
  add('برادر', u.brothers != null ? fa(u.brothers) : '');
  add('پایه', u.grade);
  add('رشته', u.field);
  add('تحصیلات پدر', u.father_edu);
  add('شغل پدر', u.father_job);
  add('وضعیت حیات پدر', u.father_alive);
  add('تحصیلات مادر', u.mother_edu);
  add('شغل مادر', u.mother_job);
  add('وضعیت حیات مادر', u.mother_alive);
  add('همراه سرپرست', u.guardian_phone);
  add('وضعیت حیات سرپرست', u.guardian_alive);
  add('مدرک', u.degree);
  add('درس تخصصی', u.subject);
  return rows;
}

PAGES.record = () => {
  const k = S.user;
  const grades = list('grades').filter(g => Number(g.student_id) === Number(k.id));
  const att = list('attendance').filter(a => Number(a.student_id) === Number(k.id));
  const pct = att.length ? Math.round(att.filter(a => a.status === 'present').length / att.length * 100) : 0;
  const details = userDetailRows(k);
  return `${pageHead('پروندهٔ من', (byId('classes', k.class_id) || {}).name || '')}
  <div class="grid">${statCard('✅', fa(pct) + '٪', 'حضور', pct >= 90 ? 'green' : 'amber')}
    ${statCard('📝', fa(grades.length), 'نمره')}</div>
  ${details.length ? card(`<b>مشخصات</b><div class="table-wrap" style="margin-top:8px"><table><tbody>
    ${details.map(([l, v]) => `<tr><td class="small muted" style="width:40%">${esc(l)}</td><td class="small">${esc(fa(v))}</td></tr>`).join('')}
  </tbody></table></div>`) : ''}
  ${card(`<div class="table-wrap"><table><thead><tr><th>درس</th><th>نمره</th><th>وضعیت</th></tr></thead><tbody>
    ${grades.map(g => `<tr><td>${esc((byId('subjects', g.subject_id) || {}).name || '')}</td><td><b>${fa(g.score)}</b></td>
      <td>${badge(g.status === 'approved' ? 'تأییدشده' : 'در انتظار', g.status === 'approved' ? 'green' : 'amber')}</td></tr>`).join('') || '<tr><td colspan="3" class="muted">—</td></tr>'}
  </tbody></table></div>`)}`;
};

function studentHome() {
  return studentHomeCard() + PAGES.record();
}
function studentHomeCard() {
  const day = weekdayIndex();
  const cls = byId('classes', S.user.class_id) || {};
  const grade = String(S.user.grade || cls.grade || '').trim();
  const branch = String(S.user.branch || cls.branch || '').trim();
  const activeDays = typeof schedWorkDays === 'function' ? schedWorkDays() : [0, 1, 2, 3, 4, 5];
  const rows = list('schedule').filter(s => activeDays.includes(Number(day)) && Number(s.weekday) === day && (
    (Number(s.class_id) && Number(s.class_id) === Number(S.user.class_id)) ||
    (grade && String(s.grade || '').trim() === grade && String(s.branch || '').trim() === branch)
  ));
  const bells = new Map(pageBellRows().map(b => [Number(b.order), b]));
  const cur = currentBell();
  return `${pageHead('امروز', J_DAYS[day] + '، ' + jdate(todayISO()), `<button class="btn sm" data-act="sync">🔄</button>`)}
  ${cur ? card(`<div class="small muted">زنگ جاری</div><b>${esc(cur.start)} – ${esc(cur.end)}</b>`) : ''}
  ${card(`<b>برنامهٔ امروز</b><div class="list" style="margin-top:8px">
    ${rows.map(s => { const b = bells.get(Number(s.bell_order)) || {}; const subj = byId('subjects', s.subject_id) || {}; const t = byId('users', s.teacher_id) || {};
      return `<div class="item"><div style="width:56px" class="small"><b>${esc(b.start || '')}</b></div><div class="grow"><div class="t">${esc(subj.name || '')}</div><div class="s">${esc(t.name || '')}</div></div></div>`;
    }).join('') || '<div class="muted small">برنامه‌ای نیست.</div>'}
  </div>`)}`;
}

/* ══════════════ سیستم ══════════════ */
/* ══════════════ مدیر: شبکه و دسترسی ══════════════ */
/* ── کارت «دسترسی از هر اینترنتی» ──────────────────────────────────
   همهٔ کاربران اینترنت خودشان را دارند؛ پس مدرسه باید یک آدرس عمومی
   ثابت داشته باشد. تونل از خود سیستم مدرسه به بیرون باز می‌شود. */
function publicAccessCard(n) {
  const p = n.public || {};
  const ts = (p.tailscale || {});
  const on = !!p.public_url;
  const busy = S.tunnelBusy;
  let state;
  if (on) {
    state = badge('فعال — ' + (/ts\.net$/.test(p.public_url) ? 'Tailscale' : 'دستی'), 'green');
  } else if (ts.installed && !ts.logged_in) {
    state = badge('Tailscale نصب است، وارد نشده', 'amber');
  } else if (!ts.installed) {
    state = badge('ابزاری نصب نیست', 'red');
  } else {
    state = badge('خاموش', 'amber');
  }

  let body;
  if (on) {
    body = `<div class="small muted" style="margin-top:8px">آدرس شما، از هر اینترنتی (خانه، مسافرت، موبایل) کار می‌کند:</div>
      <div class="ltr" style="background:var(--soft);padding:10px;border-radius:8px;margin-top:6px;font-weight:700;word-break:break-all">${esc(p.public_url)}</div>
      <div class="row" style="margin-top:10px;flex-wrap:wrap;gap:6px">
        <button class="btn sm" data-act="copy-url" data-id="${esc(p.public_url)}">کپی آدرس</button>
        <button class="btn sm" data-act="tunnel-refresh">${busy ? '…' : 'بازبینی'}</button>
        <button class="btn sm ghost" data-act="tunnel-off">قطع دسترسی اینترنتی</button>
      </div>`;
  } else if (ts.installed && !ts.logged_in) {
    body = `<div class="small muted" style="margin-top:8px">Tailscale نصب است ولی وارد حساب نشده. یک‌بار وارد شوید (مرورگر باز می‌شود) و بعد دکمهٔ فعال‌سازی را بزنید.</div>
      <div class="row" style="margin-top:10px;flex-wrap:wrap;gap:6px">
        <button class="btn sm primary" data-act="tunnel-login">ورود به Tailscale</button>
        <button class="btn sm" data-act="tunnel-refresh">بازبینی وضعیت</button>
      </div>`;
  } else if (ts.installed) {
    body = `<div class="small muted" style="margin-top:8px">Tailscale نصب و آماده است. با یک کلیک آدرس ثابت عمومی ساخته می‌شود (همان آدرسی که بعد از این، همه از هر اینترنتی وارد می‌شوند).</div>
      <div class="row" style="margin-top:10px;flex-wrap:wrap;gap:6px">
        <button class="btn sm primary" data-act="tunnel-enable">${busy ? 'در حال فعال‌سازی…' : 'فعال‌سازی آدرس عمومی'}</button>
        <button class="btn sm ghost" data-act="tunnel-refresh">بازبینی</button>
      </div>`;
  } else {
    body = `<ol class="small" style="margin:8px 0 0;padding-inline-start:18px;line-height:2">
        <li><a href="${esc(ts.download || TAILSCALE_WIN_URL)}" target="_blank">Tailscale</a> را روی همین سیستم نصب کنید (رایگان، بدون کارت بانکی).</li>
        <li>با حساب رایگان وارد شوید و برگردید؛ بقیه‌اش یک کلیک است.</li>
      </ol>
      <div class="row" style="margin-top:10px;flex-wrap:wrap;gap:6px">
        <button class="btn sm primary" data-act="tunnel-login">ورود / نصب Tailscale</button>
        <button class="btn sm ghost" data-act="tunnel-refresh">بازبینی</button>
      </div>`;
  }

  return card(`<div class="row between"><b>🌍 دسترسی از هر اینترنتی (تونل)</b>${state}</div>
    <div class="small muted" style="margin-top:6px">هیچ کاربری لازم نیست روی مودم مدرسه باشد: سیستم مدرسه یک تونل خروجی می‌سازد و همه با یک آدرس HTTPS ثابت وصل می‌شوند.</div>
    ${body}
    <div class="small muted" style="margin-top:10px">🔒 با فعال شدن آدرس عمومی، سرور از اینترنت دیده می‌شود: رمز عبور همهٔ کاربران را جدی بگیرید و دستگاه‌های ناشناس را از «دستگاه‌ها» باطل کنید.</div>`);
}

PAGES.network = () => {
  if (S.role !== 'manager') return pageHead('شبکه') + empty('دسترسی ندارید.');
  const pub = S.server.publicUrl || '';
  const n = S.network || {};
  const tun = n.tunnel || {};
  const status = !pub
    ? badge('تنظیم نشده', 'amber')
    : (tun.reachable ? badge('در دسترس از اینترنت', 'green') : badge('در دسترس نیست', 'red'));
  return `${pageHead('شبکه و دسترسی', 'هر کاربر اینترنت خودش را دارد؛ همه باید از یک آدرس ثابت وارد شوند',
    `<button class="btn sm" data-act="net-refresh">بازبینی</button>`)}
  ${card(`<div class="row between"><b>آدرس رسمی (HTTPS)</b>${status}</div>
    <div class="small muted" style="margin-top:8px">این آدرس را روی همهٔ گوشی‌ها و رایانه‌ها باز کنید. بدون آن، برنامه فقط داخل Wi-Fi مدرسه کار می‌کند.</div>
    <form data-form="network" style="margin-top:10px">
      <input class="input ltr" name="public_url" value="${esc(pub)}" placeholder="https://payesh.school.ts.net" inputmode="url" autocomplete="off">
      <button class="btn primary block" style="margin-top:8px">ذخیرهٔ آدرس</button>
    </form>
    ${tun.reachable ? `<div class="small muted" style="margin-top:8px">آخرین بررسی: ${esc(tun.latency_ms != null ? fa(tun.latency_ms) + ' میلی‌ثانیه' : '—')}${tun.same_server === false ? ' · ⚠ پاسخ از سرور دیگری آمد' : ''}</div>`
      : (tun.configured ? `<div class="small muted" style="margin-top:8px;color:var(--red,#b91c1c)">تونل پاسخ نداد (${esc(tun.error || 'نامشخص')}) — Tailscale Funnel روی سیستم روشن است؟</div>` : '')}
  `)}
  ${pub ? card(`<div class="row between" style="align-items:flex-start">
      <div><b>کد QR برای نصب سریع</b>
        <div class="small muted" style="margin-top:6px">این کد را روی تخته بزنید یا در گروه بفرستید؛ با دوربین گوشی باز می‌شود.</div>
        <div class="row" style="margin-top:8px"><a class="btn sm" href="${esc(pub)}" target="_blank">باز کردن</a>
          <button class="btn sm" data-act="copy-url" data-id="${esc(pub)}">کپی آدرس</button></div>
      </div>
      <img alt="QR" src="/api/qr?text=${encodeURIComponent(pub)}&scale=6" style="width:150px;height:150px;border-radius:10px;background:#fff;padding:6px">
    </div>`) : ''}
  ${publicAccessCard(n)}
  ${card(`<div class="row between" style="align-items:flex-start">
      <div><b>آدرس‌های شبکهٔ محلی</b>
        <div class="small muted" style="margin-top:6px">
          ${(n.lan_urls || []).map(u => `<div class="ltr">${esc(u)}</div>`).join('') || '<div>—</div>'}
          <div style="margin-top:6px">این آدرس‌ها فقط وقتی گوشی به همان Wi-Fi مدرسه وصل است کار می‌کنند.</div>
          <div style="margin-top:4px">اگر گوشی با همین Wi-Fi هم وصل نشد، احتمالاً Wi-Fi مدرسه اجازهٔ ارتباط دستگاه‌ها با هم را نمی‌دهد (Client Isolation) — در این حالت فقط آدرس رسمی HTTPS بالا کار می‌کند.</div>
        </div>
        ${(n.lan_urls || []).length ? `<div class="row" style="margin-top:8px">
          <button class="btn sm" data-act="copy-url" data-id="${esc(n.lan_urls[0])}">کپی آدرس محلی</button>
          <a class="btn sm" href="${esc(n.lan_urls[0])}" target="_blank">باز کردن</a></div>` : ''}
      </div>
      ${(n.lan_urls || []).length ? `<img alt="QR" src="/api/qr?text=${encodeURIComponent(n.lan_urls[0])}&scale=6" style="width:150px;height:150px;border-radius:10px;background:#fff;padding:6px">` : ''}
    </div>
    ${(n.lan_urls || []).length ? `<div class="small muted" style="margin-top:6px">گوشی داخل مدرسه: این کد را با دوربین گوشی اسکن کنید — بدون تایپ هیچ آدرسی باز می‌شود.</div>` : ''}`)}
  ${card(`<div class="row between"><b>📥 صندوقچهٔ آفلاین</b>${(S.outbox && S.outbox.pending) ? badge('در انتظار اعمال', 'amber') : badge('خالی', 'green')}</div>
    <div class="small muted" style="margin-top:6px">وقتی بعضی دستگاه‌ها خاموش‌اند، ثبت‌هایشان این‌جا می‌ماند و اولین دستگاهی که روشن شود (مدرسه، خانه یا گوشیِ کادر) خودکار اعمالشان می‌کند — لازم نیست کسی کاری کند.</div>
    <div class="row" style="margin-top:8px"><button class="btn sm" data-act="outbox-sync">بررسی و اعمال اکنون</button></div>`)}

  `;
};

/* ── کارت به‌روزرسانی ──────────────────────────────────────────────── */
function updateCard() {
  const r = S.remote || {};
  const last = r.last || S.updateLast || null;
  const running = S.server && S.server.version;
  let line;
  if (!r.ok && r.error) {
    line = `<div class="small" style="color:var(--amber,#b45309);margin-top:6px">منبع آپدیت در دسترس نیست (${esc(r.error === 'source_unreachable' ? 'اینترنت یا آینه' : r.error)}). برنامه بدون آپدیت هم کار می‌کند.</div>`;
  } else if (r.available) {
    const kb = Math.max(1, Math.round((r.total_size || 0) / 1024));
    line = `<div class="small" style="margin-top:6px">نسخهٔ <b>${esc(r.remote_version)}</b> منتشر شده است — ${fa((r.changed || []).length)} فایل تغییر کرده، مجموع ${fa(kb)} کیلوبایت${r.needs_restart ? ' · پس از نصب، برنامه خودکار دوباره راه می‌افتد' : ''}.</div>`;
  } else if (r.ok) {
    line = `<div class="small muted" style="margin-top:6px">برنامه به‌روز است.${r.checked_at ? ' آخرین بررسی: ' + esc(jdate(r.checked_at)) : ''}</div>`;
  } else {
    line = `<div class="small muted" style="margin-top:6px">برای دیدن نسخهٔ تازه، «بررسی آپدیت» را بزنید.</div>`;
  }
  const st = S.upd || {};
  const stLine = st && st.status && st.status !== 'idle'
    ? `<div class="small" style="margin-top:6px">
        ${st.status === 'downloading' ? `⬇️ در حال دانلود ${fa(st.percent || 0)}٪ (${fa(st.receivedKb || 0)} از ${fa(st.totalKb || 0)} کیلوبایت)`
          : st.status === 'ready' ? '✅ دانلود شد و آمادهٔ نصب است'
          : st.status === 'installing' ? '⚙️ در حال نصب…'
          : st.status === 'error' ? `⚠️ ${esc(st.errorText || 'به‌روزرسانی انجام نشد')}`
          : st.status === 'latest' ? '✅ برنامه به‌روز است'
          : esc(st.status)}
      </div>`
    : '';
  const metaLine = (st && st.latest)
    ? `<div class="small muted" style="margin-top:4px">
        نسخهٔ منتشرشده: <b>${esc(st.latest)}</b>
        ${st.sizeKb ? ' · دانلود: ' + fa(st.sizeKb) + ' کیلوبایت' : ''}
        ${st.fullMb ? ' · نصب‌کنندهٔ کامل: ' + fa(st.fullMb) + ' مگابایت' : ''}
        ${st.mode === 'patch' && st.savedMb ? ' · صرفه‌جویی ' + fa(st.savedMb) + ' مگابایت' : ''}
        ${st.checkedAt ? ' · آخرین بررسی: ' + esc(jdate(st.checkedAt)) : ''}
      </div>`
    : '';
  const lastLine = last && last.applied !== false && last.version
    ? `<div class="small muted" style="margin-top:6px">آخرین به‌روزرسانی نصب‌شده: ${esc(last.version)}${last.at ? ' — ' + esc(jdate(last.at)) : ''}${last.files != null ? ' (' + fa(last.files) + ' فایل، ' + fa(Math.max(1, Math.round((last.bytes || 0) / 1024))) + ' کیلوبایت)' : ''}</div>`
    : '';
  return card(`<b>به‌روزرسانی برنامه</b>
    <div class="small muted" style="margin-top:4px">نسخهٔ در حال اجرا: <b>${esc(running || '—')}</b>${r.remote_version && r.remote_version !== running ? ' · منتشرشده: <b>' + esc(r.remote_version) + '</b>' : ''}</div>
    ${line}${metaLine}${stLine}${lastLine}
    <div class="row" style="margin-top:10px;flex-wrap:wrap;gap:6px">
      <button class="btn sm" data-act="update-recheck">${S.remoteBusy ? '…' : 'بررسی آپدیت'}</button>
      ${r.available && st.status !== 'ready' ? `<button class="btn sm primary" data-act="update-now">دانلود و نصب (یک کلیک)</button>` : ''}
      ${r.available && st.status !== 'ready' ? `<button class="btn sm ghost" data-act="update-download">فقط دانلود</button>` : ''}
      ${st.status === 'ready' ? `<button class="btn sm primary" data-act="update-install">نصب نسخهٔ ${esc(st.latest || '')}</button>` : ''}
      ${last && last.version ? `<button class="btn sm ghost" data-act="update-rollback">بازگشت به نسخهٔ قبل</button>` : ''}
    </div>
    <form data-form="update" class="row" style="margin-top:12px;flex-wrap:wrap;gap:8px;align-items:flex-end">
      <label class="field grow" style="min-width:220px"><span>منبع آپدیت (اختیاری)</span>
        <input class="input ltr" name="base" placeholder="https://…/payesh.local/main/" value="${esc(r.base || '')}"></label>
      <button class="btn sm" type="submit">ذخیره</button>
    </form>
    <div class="small muted" style="margin-top:6px">${r.bases && r.bases.length ? 'آینه‌ها: ' + r.bases.map(b => esc(b.replace(/^https?:\/\//, '').replace(/\/$/, ''))).join(' · ') : ''}</div>
    <label class="row" style="margin-top:10px;gap:8px;align-items:center">
      <input type="checkbox" data-act="update-auto" ${r.auto ? 'checked' : ''}> <span class="small">بررسی خودکار نسخهٔ تازه (پیشنهاد می‌شود)</span>
    </label>
    <label class="row" style="margin-top:6px;gap:8px;align-items:center">
      <input type="checkbox" data-act="update-autoapply" ${r.auto_apply ? 'checked' : ''}> <span class="small">نصب خودکار بدون پرسش (شب‌ها، فقط فایل‌های تغییرکرده)</span>
    </label>
    <div class="small muted" style="margin-top:8px">هیچ‌وقت داده‌های مدرسه (پوشهٔ data) دست نمی‌خورد؛ نسخهٔ قبلی برای بازگشت نگه داشته می‌شود.</div>`);
}

function clientUpdateCard() {
  return card(`<b>به‌روزرسانی برنامه</b>
    <div class="small muted" style="margin-top:6px">${S.update ? `نسخهٔ ${esc(S.update.version)} آماده است؛ فقط فایل‌های تغییرکرده دانلود می‌شود.` : 'برنامه به‌روز است.'}</div>
    <div class="row" style="margin-top:8px">
      <button class="btn sm" data-act="update-check">بررسی به‌روزرسانی</button>
      ${S.update ? `<button class="btn sm primary" data-act="update-apply">اعمال (${Math.round((S.update.total_size || 0) / 1024)}KB)</button>` : ''}
    </div>
    <div class="small muted" style="margin-top:8px">به‌روزرسانی خود سیستم را مدیر انجام می‌دهد؛ دستگاه شما خودکار تازه می‌شود.</div>`);
}

PAGES.system = () => {
  const isManager = S.role === 'manager';
  const dev = S.boot && S.boot.counts;
  return `${pageHead('سیستم', 'نسخه ' + esc(S.server.version || '') , '')}
  ${card(`<div class="row between"><b>وضعیت</b>${S.online ? badge('متصل', 'green') : badge('آفلاین', 'amber')}</div>
    <div class="small muted" style="margin-top:6px">
      کاربر: ${esc(S.user.name)} · نقش: ${esc(ROLE_FA[roleTitle()] || roleTitle())}<br>
      آخرین همگام‌سازی: ${S.lastSync ? esc(jdate(S.lastSync) + ' ' + time24(new Date(S.lastSync))) : '—'}<br>
      تغییرات در صف: ${fa(S.queue.length)}
    </div>
    <div class="row" style="margin-top:10px">
      <button class="btn sm" data-act="sync">همگام‌سازی</button>
      <button class="btn sm" data-act="lock">🔒 خروج</button>
      <button class="btn sm ghost" data-act="whats-new-all">✦ همهٔ تغییرات نسخه‌ها</button>
      ${themeButtonHtml()}
    </div>`)}
  ${liveCard()}
  ${isManager ? phoneAccessCard() : ''}
  ${accountCard()}
  ${!isManager && BACKUP_ROLES_FA.indexOf(S.role) >= 0 ? mirrorCard() : ''}
  ${isManager ? updateCard() : clientUpdateCard()}
  ${isManager ? managerSystemSections() : ''}
  ${card(`<b>راهنمای دستگاه‌ها</b><div class="small muted" style="margin-top:6px">
    ${S.server.publicUrl
      ? `آدرس رسمی را روی گوشی باز کنید و «افزودن به صفحهٔ اصلی» را بزنید:<br><span class="ltr" style="font-weight:700">${esc(S.server.publicUrl)}</span>`
      : `همهٔ دستگاه‌ها از طریق حافظهٔ مشترک ابری به همین اطلاعات می‌رسند؛ آدرس زیر فقط آدرس همین دستگاه است:<br><span class="ltr" style="font-weight:700">http://${esc(location.host)}</span>`}
    <br><a href="/install" target="_blank">صفحهٔ نصب و راهنما</a>
  </div>`)}`;
};

/* ── آینهٔ داده و پشتیبان روزانه ─────────────────────────────────────
   داده‌ها هم در دیتابیس‌اند و هم روی خودِ سیستم در یک فایل خوانا؛ هر
   دقیقه با دیتابیس مقایسه می‌شود و هر روز یک فایل پشتیبان ساخته و
   به‌روز می‌شود. همان فایل را می‌شود در نصب تازه بازیابی کرد. */
function mbSize(n) {
  const b = Number(n || 0);
  if (b > 1024 * 1024) return fa(Math.round(b / 1048576)) + ' مگابایت';
  if (b > 1024) return fa(Math.round(b / 1024)) + ' کیلوبایت';
  return fa(b) + ' بایت';
}
/* نقش‌هایی که پشتیبان و بازیابی را می‌بینند: مدیر و عوامل اجرایی */
/* F‑01: کارت پشتیبان/فایل کامل داده فقط برای مدیر — بقیهٔ نقش‌ها کل پایگاه را نمی‌گیرند */
const BACKUP_ROLES_FA = ['manager'];

function mirrorCard() {
  const m = S.mirror;
  const state = !m ? badge('بررسی نشده', 'amber')
    : (m.mirror && m.mirror.ok ? badge('آینه با دیتابیس یکی است', 'green') : badge('آینه عقب است', 'amber'));
  const diffs = (m && m.mirror && m.mirror.diffs) || [];
  const files = (m && m.daily) || [];
  return card(`<div class="row between" style="margin-bottom:6px"><b>🗄️ آینهٔ داده و پشتیبان روزانه</b>${state}</div>
    <div class="small muted" style="line-height:2">
      اطلاعات فقط در دیتابیس نیست: یک نسخهٔ خوانا هم روی خودِ این سیستم نگه داشته می‌شود و هر دقیقه با دیتابیس مقایسه می‌شود.
      هر روز یک فایل پشتیبان ساخته می‌شود و اگر همان روز داده عوض شود، همان فایل به‌روز می‌شود.
      اگر روزی دیتابیس از دست رفت یا عوض شد، همین فایل را اینجا آپلود کنید.
    </div>
    ${m ? `<div class="small" style="margin-top:8px;line-height:2">
      ${m.mirror && m.mirror.at ? 'آخرین آینه: ' + esc(m.mirror.at.slice(0, 16).replace('T', ' ')) + ' · ' + fa(m.mirror.total || 0) + ' رکورد<br>' : ''}
      ${diffs.length ? '⚠️ اختلاف با دیتابیس: ' + esc(diffs.slice(0, 4).map(d => d.collection + ' (' + fa(d.db) + '/' + fa(d.mirror) + ')').join('، ')) + '<br>' : ''}
      ${files.length ? 'روزهای پشتیبان: ' + fa(files.length) + ' فایل' : 'هنوز فایل روزانه ساخته نشده'}
    </div>` : '<div class="small muted" style="margin-top:8px">برای دیدن وضعیت، دکمهٔ «به‌روزرسانی و مقایسه» را بزنید.</div>'}
    <div class="row" style="margin-top:10px;gap:8px">
      <button class="btn sm primary" data-act="mirror-refresh">🔄 به‌روزرسانی و مقایسه</button>
      <a class="btn sm ghost" href="/api/admin/mirror/download">⬇️ دانلود آینه</a>
    </div>
    ${files.length ? `<div class="table-wrap" style="margin-top:10px;max-height:190px;overflow:auto"><table><thead><tr><th>روز</th><th>رکورد</th><th>حجم</th><th></th></tr></thead><tbody>
      ${files.slice(0, 60).map(f => `<tr><td class="small ltr">${esc(f.file.replace(/^payesh-|\.json$/g, ''))}</td>
        <td class="small">${fa(f.total || 0)}</td><td class="small">${mbSize(f.size)}</td>
        <td class="nowrap"><a class="btn sm ghost" href="/api/admin/backups/daily/${encodeURIComponent(f.file)}">دانلود</a></td></tr>`).join('')}
    </tbody></table></div>` : ''}
    <div class="small muted" style="margin-top:12px;padding-top:10px;border-top:1px dashed var(--line)">بازیابی از فایل پشتیبان (روی همین سیستم یا سیستم تازه):</div>
    <div class="row" style="margin-top:8px;gap:8px;align-items:center">
      <input class="input grow" type="file" id="restore-file" accept=".json,application/json">
      <button class="btn sm" data-act="mirror-restore">بازیابی</button>
    </div>`);
}

/* وضعیت دسترسی گوشی‌ها — یک نگاه، یک دکمه */
/* وضعیت همگام‌سازی زنده — برای اینکه همه ببینند هر ثانیه به‌روز می‌شود */
function liveCard() {
  const last = (typeof S !== 'undefined' && S.lastSync) ? S.lastSync : '';
  const stamp = last
    ? time24(new Date(last), true)
    : '—';
  return card(`<div class="row between" style="margin-bottom:6px">
      <b>⚡ همگام‌سازی زنده</b>${badge('هر ۱ ثانیه', 'green')}</div>
    <div class="small muted" style="line-height:1.9">
      هر تغییری که هر کاربر بدهد، همان لحظه در حافظهٔ مشترک نوشته می‌شود و در همان ثانیه به
      دستگاه‌های دیگر می‌رسد. اگر دستگاهِ مقصد خاموش باشد، داده در حافظه می‌ماند و
      اولین ثانیه‌ای که آنلاین شود تحویلش می‌گیرد.
    </div>
    <div class="small" style="margin-top:8px">آخرین به‌روزرسانی روی این دستگاه: <b class="ltr">${esc(stamp)}</b></div>`);
}

function phoneAccessCard() {
  const r = S.phoneCheck;
  const state = !S.server.cloudReady
    ? badge('حافظهٔ مشترک آماده نشده', 'amber')
    : (r ? (r.ok ? badge('گوشی‌ها وصل‌اند', 'green') : badge('گوشی‌ها وصل نیستند', 'red')) : badge('بررسی نشده', 'amber'));
  return card(`<div class="row between"><b>📱 گوشی‌ها به حافظهٔ مدرسه وصل‌اند؟</b>${state}</div>
    <div class="small muted" style="margin-top:6px">اگر گوشی پیام «به حافظه نرسیدیم» می‌دهد، این دکمه را بزنید؛ خودش بررسی و درست می‌کند.</div>
    <div class="row" style="margin-top:10px"><button class="btn sm primary" data-act="cloud-phone-check">بررسی و درست‌کردن</button></div>
    <div id="cloud-phone-out" class="small" style="margin-top:8px">${r ? phoneCheckHtml(r) : ''}</div>`);
}

/* کارت حساب: نام کاربری + تغییر رمز عبور (هر نقشی) */
function accountCard() {
  const u = S.user || {};
  const phone = u.phone || (S.boot && S.boot.user && S.boot.user.phone) || '';
  return card(`<div class="row between"><b>👤 حساب من</b>${badge(ROLE_FA[roleTitle()] || roleTitle(), '')}</div>
    <div class="small muted" style="margin-top:6px">نام: <b>${esc(u.name || '')}</b></div>
    <div class="small muted" style="margin-top:2px">نام کاربری (شمارهٔ همراه): <span class="ltr">${esc(phone || '—')}</span></div>
    ${u.password ? `<div class="small muted" style="margin-top:2px">رمز عبور فعلی: <span class="ltr"><b>${esc(u.password)}</b></span></div>` : ''}
    <form data-form="own-password" style="margin-top:10px">
      <label class="field"><span>رمز فعلی</span><input class="input ltr" type="password" name="current" autocomplete="current-password"></label>
      <label class="field"><span>رمز تازه</span><input class="input ltr" type="password" name="next" autocomplete="new-password"></label>
      <label class="field"><span>تکرار رمز تازه</span><input class="input ltr" type="password" name="again" autocomplete="new-password"></label>
      <button class="btn primary block">تغییر رمز عبور</button>
    </form>
    <div class="small muted" style="margin-top:6px">اگر رمز فعلی را نمی‌دانید، از مدیر بخواهید رمز تازه بگذارد.</div>`);
}

function managerSystemSections() {
  const stats = S.boot && S.boot.counts || {};
  return `
  ${mirrorCard()}
  ${card(`<b>پشتیبان‌گیری</b>
    <div class="small muted" style="margin-top:6px">هر ساعت خودکار گرفته می‌شود و ۴۸ نسخه نگه داشته می‌شود.</div>
    <div class="row" style="margin-top:8px"><button class="btn sm" data-act="backup-now">پشتیبان همین حالا</button>
      <button class="btn sm ghost" data-act="backup-list">فهرست نسخه‌ها</button></div>`)}
  ${card(`<b>حافظهٔ ابری</b>
    <div class="small muted" style="margin-top:6px">جایی که وقتی هیچ سیستمی روشن نیست، پیام‌ها و تکالیف نگه داشته می‌شوند تا اولین دستگاه همه را بردارد.</div>
    <button class="btn sm" style="margin-top:8px" data-act="goto" data-route="cloud">تنظیم صندوقچه</button>`)}
  ${card(`<b>دستگاه‌های متصل</b><div id="devices-box" class="small muted" style="margin-top:6px">برای دیدن فهرست، دکمه را بزنید.</div>
    <button class="btn sm" style="margin-top:8px" data-act="devices-list">نمایش دستگاه‌ها</button>`)}
  ${card(`<b>تنظیمات مدرسه</b>
    <label class="field" style="margin-top:8px"><span>نام مدرسه</span><input class="input" id="set-name" value="${esc((S.server.school && S.server.school.name) || '')}"></label>
    <div class="row"><button class="btn sm" data-act="settings-save">ذخیره</button></div>
    <div class="small muted" style="margin-top:8px">قابلیت‌ها: ${Object.entries((S.server.school && S.server.school.capabilities) || {}).filter(([, v]) => v).map(([k]) => esc(k)).join(' · ')}</div>`)}
  ${card(`<b>آمار پایگاه داده</b><div class="small muted" style="margin-top:6px">
    ${isFieldSchoolNow()
      ? (() => {
        /* ردیف ۲۰۴: مدرسهٔ رشته‌محور «کلاس» ندارد — دانش‌آموز فعال، محل برگزاری و گروه‌های پایه و رشته */
        const rooms = list('classes').filter(c => String(c.kind || '') === 'room').length;
        const groups = list('classes').length - rooms;
        return `کاربران: ${fa(stats.users || 0)} (دانش‌آموز فعال: ${fa(list('users').filter(rosterStudent).length)}) · محل برگزاری: ${fa(rooms)} · پایه و رشته: ${fa(groups)} · حضور: ${fa(stats.attendance || 0)} · نمره: ${fa(stats.grades || 0)}`;
      })()
      : `کاربران: ${fa(stats.users || 0)} · کلاس‌ها: ${fa(stats.classes || 0)} · حضور: ${fa(stats.attendance || 0)} · نمره: ${fa(stats.grades || 0)}`}
  </div><button class="btn sm" style="margin-top:8px" data-act="audit-list">سابقهٔ تغییرات</button>`)}
  `;
}

/* ══════════════════ حافظهٔ ابری ══════════════════ */
PAGES.cloud = () => {
  const c = S.cloud || null;
  const busy = S._cloudBusy;
  const edit = !!S.cloudEdit;
  const row = (id, label, val, ph, type) => `<label class="field" style="margin-top:8px"><span>${label}</span>
    <input class="input" id="${id}" ${type === 'password' ? 'type="password"' : ''} placeholder="${esc(ph || '')}" value="${esc(val || '')}"></label>`;
  /* D‑23/F‑04: کلید بازخوانی نمی‌شود؛ آمادگی را سرور با «هست/نیست» می‌گوید */
  const ready = !!(c && c.configured);
  return `${pageHead('حافظهٔ ابری', 'جایی در اینترنت که همهٔ دستگاه‌ها رویش می‌نویسند', '')}
  ${card(`<div class="small muted" style="line-height:1.9">
    وقتی هیچ سیستمی در مدرسه روشن نیست، پیام‌ها و تکالیف باید جایی بمانند تا اولین دستگاهِ روشن‌شده همه را بردارد.
    اینجا همان «صندوقچه» است.
  </div>`)}
  ${c === null ? card(`<div class="muted small">در حال خواندن تنظیمات…</div>`) : card(`
    <div class="row between"><b>وضعیت صندوقچه</b>${ready ? badge('آماده', 'green') : (c.has_access_key ? badge('در حال آماده‌سازی', 'amber') : badge('تنظیم نشده', 'amber'))}</div>
    ${c.built_in
      ? `<div class="small muted" style="margin-top:8px;line-height:1.9">✅ <b>از قبل داخل برنامه تنظیم شده است</b> — لازم نیست چیزی وارد کنید.
          ${c.bucket ? `<br>صندوقچه: <span class="ltr">${esc(c.bucket)}</span>` : '<br>نام صندوقچه به‌زودی خودکار پیدا می‌شود (به اینترنت نیاز دارد).'}
          <br>سرور: <span class="ltr">${esc(c.endpoint || '')}</span></div>`
      : `<div class="small muted" style="margin-top:8px">تنظیمات دستی روی این دستگاه فعال است (بر پیش‌فرضِ داخل برنامه مقدم است).</div>`}
    <div class="row" style="margin-top:12px;flex-wrap:wrap;gap:6px">
      <button class="btn sm" data-act="cloud-test" ${busy || !ready ? 'disabled' : ''}>آزمایش اتصال</button>
      <button class="btn sm ghost" data-act="cloud-cors" ${busy || !ready ? 'disabled' : ''}>تنظیم خودکار CORS</button>
      <button class="btn sm ghost" data-act="cloud-edit">${edit ? 'بستن کادر تغییر' : 'تغییر تنظیمات'}</button>
      ${c.built_in ? '' : `<button class="btn sm ghost" data-act="cloud-reset">بازگشت به پیش‌فرض برنامه</button>`}
    </div>
    <div id="cloud-out" class="small" style="margin-top:10px"></div>`)}

  ${c && edit ? card(`
    <div class="row between"><b>تنظیمات صندوقچه (تغییر)</b></div>
    <div class="small muted" style="margin-top:4px">فقط وقتی لازم است که صندوقچه عوض شود. مقدار خالی = همان مقدار فعلی می‌ماند.</div>
    ${row('cl-endpoint', 'آدرس سرویس (Endpoint)', c.endpoint, 'https://s3.ir-central1.arvanstorage.ir')}
    ${row('cl-bucket', 'نام صندوقچه (اختیاری — خودکار پیدا می‌شود)', c.bucket, '')}
    ${row('cl-region', 'منطقه (اختیاری)', c.region, 'ir-central1')}
    ${row('cl-access', 'کلید عمومی (Access Key)', c.accessKey, '')}
    ${row('cl-secret', 'کلید خصوصی (Secret Key)', '', 'کلید خصوصی فعلی می‌ماند', 'password')}
    <div class="small muted" style="margin-top:6px">کلید فقط روی سرور می‌ماند و هرگز به مرورگر/گوشی برنمی‌گردد؛ برای تغییر، مقدار تازه بگذارید. تست اتصال هم فقط از سرور انجام می‌شود.</div>
    <div class="row" style="margin-top:10px;flex-wrap:wrap;gap:6px">
      <button class="btn sm" data-act="cloud-save" ${busy ? 'disabled' : ''}>ذخیرهٔ تنظیمات تازه</button>
    </div>`) : ''}

  ${card(`<b>📱 دسترسی گوشی‌ها</b>
    <div class="small muted" style="margin-top:6px;line-height:1.9">
      گوشی و رایانهٔ خانه با همین حافظهٔ مشترک کار می‌کنند. این دکمه همه‌چیز را خودش بررسی و درست می‌کند:
      صندوقچه پیدا می‌شود، اجازهٔ خواندن برای گوشی گذاشته می‌شود، و نتیجه را همین‌جا می‌بینید.
    </div>
    <div class="row" style="margin-top:10px;flex-wrap:wrap;gap:6px">
      <button class="btn sm primary" data-act="cloud-phone-check" ${busy ? 'disabled' : ''}>بررسی و درست‌کردن دسترسی گوشی</button>
    </div>
    <div id="cloud-phone-out" class="small" style="margin-top:10px">${S.phoneCheck ? phoneCheckHtml(S.phoneCheck) : ''}</div>`)}

  ${card(`<b>CORS — اجازهٔ مرورگر</b>
    <div class="small muted" style="margin-top:6px;line-height:1.9">
      گوشی‌ها مستقیم با صندوقچه حرف می‌زنند، پس صندوقچه باید به مرورگر اجازه بدهد.
      دکمهٔ <b>«تنظیم خودکار CORS»</b> همین کار را از داخل برنامه انجام می‌دهد؛ لازم نیست در پنل دنبالش بگردید.
      اگر کلید اجازهٔ مدیریت صندوقچه را نداشت، باید در پنل
      (فضای ابری ← صندوقچه ← عملیات ← تنظیمات CORS) دستی یک قانون با
      <span class="ltr">*</span> و متدهای <span class="ltr">GET, PUT, DELETE, HEAD</span> بسازید.
    </div>`)}`;
};

/* نتیجهٔ «بررسی دسترسی گوشی» به زبان ساده */
function phoneCheckHtml(r) {
  if (!r) return '';
  const ok = !!r.ok;
  const steps = (r.steps || []).map(st => {
    const label = {
      bucket: 'پیدا کردن صندوقچه',
      cors: 'اجازهٔ خواندن برای گوشی',
      set_cors: 'گذاشتن اجازهٔ خواندن',
      cors_after: 'آزمایش دوباره بعد از تنظیم',
    }[st.step] || st.step;
    const good = st.ok !== false;
    return `<div>${good ? '✅' : '❌'} ${esc(label)}${st.status ? ' — کد ' + fa(st.status) : ''}${st.error ? ' — ' + esc(st.error) : ''}</div>`;
  }).join('');
  return `${ok ? badge('گوشی می‌تواند بخواند و بنویسد', 'green') : badge('هنوز نشده', 'amber')}
    <div style="margin-top:6px;line-height:1.9">${steps}</div>
    ${ok ? '' : '<div class="muted" style="margin-top:6px">اگر «گذاشتن اجازه» خطا داد، کلیدِ صندوقچه اجازهٔ مدیریت ندارد؛ در پنل ابری یک قانون CORS با <span class="ltr">*</span> و متدهای GET/PUT/DELETE/HEAD بسازید.</div>'}`;
}

/* ══════════════ کنش‌ها ══════════════ */
/* هر پنجره و پیامی که باز می‌شود باید جایی برای نشستن داشته باشد؛
   اگر صفحهٔ میزبان آن را نداشته باشد، خودمان می‌سازیم تا هیچ دکمه‌ای
   بی‌اثر نماند. */
function layerRoot(id) {
  let el = document.getElementById(id);
  if (!el) { el = document.createElement('div'); el.id = id; document.body.appendChild(el); }
  return el;
}

/* ── پنجرهٔ بازشو ─────────────────────────────────────────────────────
   هیچ «هندلر درون‌خطی» (onclick) نداریم؛ همه از یک‌جا مدیریت می‌شوند.
   دلیلش پیدا شدن همین ایراد بود: `onclick="event.stopPropagation()"` روی
   خودِ پنجره، کلیک دکمهٔ ✕ را هم می‌بلعید و دکمه هیچ‌جا کار نمی‌کرد.
   حالا:
     • دکمهٔ ✕ → data-act="modal-close" → بستن
     • کلیک روی پس‌زمینه یا کلید Esc → هیچ اثری ندارد
   ─────────────────────────────────────────────────────────────────── */
/* فرم‌های بزرگ (کاربر جدید، مشخصات کامل، ویرایش کاربر): پنجرهٔ بزرگ‌تر و
  «قفل» — کلیکِ بیرونِ کادر نباید داده‌های نیمه‌کاره را پاک کند. */
const FORM_MODAL_OPTS = { wide: true, lock: true };

function modal(html, opts) {
  const o = opts || {};
  const root = layerRoot('modal-root');
  /* بازسازی محتوای یک دیالوگ نباید موقع حذف/ویرایش، پیمایش آن را به بالا ببرد. */
  const previous = root.querySelector('.modal');
  const previousTitle = previous && previous.querySelector('.row b');
  const sameDialog = previous && previousTitle && previousTitle.textContent === String(S.modalTitle || '');
  const scrollTop = previous && (o.preserveScroll || sameDialog) ? previous.scrollTop : 0;
  S.modal = html;
  S.modalOpts = o;
  root.innerHTML = `<div class="modal-bg${o.lock ? ' locked' : ''}" data-act="modal-bg"${o.lock ? ' data-lock="1"' : ''}><div class="modal${o.wide ? ' wide' : ''}${o.cls ? ' ' + esc(o.cls) : ''}" role="dialog" aria-modal="true"${o.title ? ' data-title="' + esc(o.title) + '"' : ''}>
    <div class="row between" style="margin-bottom:8px">
      <b>${esc(S.modalTitle || '')}</b>
      <button type="button" class="btn sm ghost" data-act="modal-close" aria-label="بستن" title="بستن">✕</button>
    </div>
    ${html}</div></div>`;
  const current = root.querySelector('.modal');
  if (current && scrollTop) current.scrollTop = scrollTop;
}
function closeModal() { S.modal = null; S.modalOpts = null; layerRoot('modal-root').innerHTML = ''; }

function pairCardHtml(r) {
  const plain = String(r.code || r.display || '').replace(/[^0-9A-Za-z]/g, '');
  const host = (typeof location !== 'undefined' ? location.origin : '');
  /* یک QR، همه‌کاره: با اسکن، اگر برنامه نصب باشد مستقیم وارد می‌شود؛
     اگر نصب نباشد همان QR صفحهٔ نصب را باز می‌کند و بعد از نصب هم
     خودکار وارد حساب می‌شود. */
  const web = host + '/#/pair=' + encodeURIComponent(plain);
  const apk = NATIVE_APK_URL; /* row 161: direct file, never the release page */
  return `<div class="paircard">
    <div class="who">${esc(r.user.name)}</div>
    <div class="small muted">${esc(ROLE_FA[r.user.role] || r.user.role)}</div>
    <div class="code">${esc(r.display)}</div>
    <div class="small muted">این کد تا وقتی خودتان «کد تازه» نسازید کار می‌کند.</div>
    <div style="text-align:center;margin-top:12px">
      <img alt="QR" src="/api/qr?text=${encodeURIComponent(web)}&scale=6" style="width:210px;height:210px;border-radius:14px;background:#fff;padding:8px">
      <div class="small" style="margin-top:6px;line-height:1.9">📷 <b>با دوربین گوشی اسکن کنید</b><br>
        برنامه نصب است؟ بی‌درنگ وارد حساب خودتان می‌شوید.<br>
        نصب نیست؟ همین اسکن، برنامه را نصب می‌کند و بعد از نصب هم خودکار وارد می‌شوید.</div>
    </div>
    <div class="small muted ltr" style="margin-top:8px;font-size:10px;word-break:break-all">${esc(web)}</div>
    <div class="row" style="gap:10px;justify-content:center;align-items:center;margin-top:10px">
      <img alt="QR" src="/api/qr?text=${encodeURIComponent(apk)}&scale=4" style="width:84px;height:84px;border-radius:10px;background:#fff;padding:4px">
      <div class="small muted" style="text-align:right">نصب برنامهٔ بومی<br><span class="ltr">native-continuous</span></div>
    </div>
  </div>
  <div class="small row" style="margin-top:6px;gap:8px;flex-wrap:wrap">
    <span class="small muted grow">کاربر یا کد را در صفحهٔ ورود می‌زند، یا QR را اسکن می‌کند. این کد چندبار و برای چند دستگاه کار می‌کند — تا وقتی خودتان کد تازه نسازید.</span>
  </div>
  <div class="row" style="margin-top:10px;gap:8px">
    <button class="btn block grow" data-act="print">🖨️ چاپ کارت</button>
    <button class="btn block grow" data-act="pair-refresh" data-id="${esc(r.user.id)}">🔄 کد تازه</button>
  </div>
  <div class="small muted" style="margin-top:6px">«کد تازه» همین کارت را باطل می‌کند و کد تازه می‌سازد — بعد از آن، کد و QR قبلی دیگر کار نمی‌کند.</div>`;
}

async function actPairCode(id, refresh) {
  try {
    const r = await api('/api/admin/pair-code', { method: 'POST', body: { user_id: Number(id), refresh: !!refresh } });
    S.modalTitle = 'کارت پیوند';
    modal(pairCardHtml(r));
    if (refresh && r.ok) toast('کد تازه ساخته شد — کد قبلی باطل شد', 'ok');
  } catch (e) { toast('ساخت کد ناموفق: ' + friendlyError(e), 'err'); }
}

async function actAttendanceSave(classId, bell) {
  const draft = S.attDraft;
  if (!draft || !draft.map.size) {
    /* اگر چیزی دستی تغییر نکرده، همه «حاضر» فرض می‌شوند */
  }
  const date = todayISO();
  const roster = list('users').filter(u => u.role === 'student' && Number(u.class_id) === Number(classId));
  const existing = new Map(attendanceFor(classId, date).map(a => [Number(a.student_id), a]));
  let n = 0;
  for (const s of roster) {
    const status = draft && draft.map.has(s.id) ? draft.map.get(s.id) : (existing.has(s.id) ? existing.get(s.id).status : attDefaultStatus(s.id, date));
    const ex = existing.get(s.id);
    if (ex && ex.status === status) continue;
    putLocal('attendance', {
      id: ex ? ex.id : undefined, student_id: s.id, class_id: Number(classId), date, status,
      note: '', source: 'teacher', school_id: 1, _version: ex ? ex._version : 0,
    });
    n++;
  }
  if (draft) draft.map.clear();
  toast(n ? fa(n) + ' رکورد ذخیره شد' : 'تغییری نبود', 'ok');
  saveCache();
  await flushQueue();
  go('home');
}

async function actGradeSave() {
  const inputs = [...document.querySelectorAll('[data-grade]')];
  const sel = S.gradeSel || {};
  const subject = byId('subjects', sel.subject) || {};
  const existing = new Map(list('grades')
    .filter(g => Number(g.class_id) === Number(sel.class) && Number(g.subject_id) === Number(sel.subject) && String(g.term) === String(sel.term))
    .map(g => [Number(g.student_id), g]));
  let n = 0;
  for (const inp of inputs) {
    const sid = Number(inp.getAttribute('data-grade'));
    const raw = norm(inp.value).trim();
    if (!raw) continue;
    const score = Number(raw);
    if (isNaN(score) || score < 0 || score > 20) { toast('نمرهٔ نامعتبر برای یکی از دانش‌آموزان', 'err'); continue; }
    const ex = existing.get(sid);
    if (ex && Number(ex.score) === score) continue;
    const row = {
      id: ex ? ex.id : undefined, student_id: sid, class_id: Number(sel.class), subject_id: Number(sel.subject),
      term: sel.term, kind: subject.workshop ? 'practical' : 'midterm',
      score, status: S.role === 'manager' ? 'approved' : 'pending', school_id: 1, _version: ex ? ex._version : 0,
    };
    if (subject.workshop) row.practical_score = score;
    putLocal('grades', row);
    n++;
  }
  toast(n ? fa(n) + ' نمره ذخیره شد' : 'تغییری نبود', 'ok');
  saveCache();
  await flushQueue();
  render();
}

function actLeaveAdd() {
  /* ردیف ۱۹۷: مدیر برای هر دانش‌آموز ثبت می‌کند (تماس تلفنی ولی)؛ ولی فقط برای فرزند خودش */
  const manager = S.role === 'manager';
  const kids = S.role === 'parent' ? myChildren()
    : manager ? sortBy(list('users').filter(u => u.role === 'student' && u.active !== false), 'name') : [S.user];
  S.modalTitle = manager ? 'ثبت مرخصی دانش‌آموز' : 'درخواست مرخصی';
  modal(`<form data-form="leave">
    <label class="field"><span>دانش‌آموز</span><select class="input" name="student_id">
      ${kids.map(k => `<option value="${k.id}">${esc(k.name)}${manager && byId('classes', k.class_id) ? ' — ' + esc(byId('classes', k.class_id).name) : ''}</option>`).join('')}
    </select></label>
    <label class="field"><span>نوع مرخصی</span><select class="input" name="kind" data-leave-kind>
      <option value="day">روزانه</option><option value="hours">ساعتی (خروج زودهنگام / ورود دیرتر)</option></select></label>
    <label class="field"><span>از تاریخ</span>${jalaliDateControl('date', todayISO(), { required: true })}</label>
    <label class="field" data-leave-days><span>تا تاریخ (برای چند روز؛ خالی = همان روز)</span>${jalaliDateControl('date_to', '')}</label>
    <div class="row" data-leave-hours style="gap:8px;display:none">
      <label class="field grow"><span>از ساعت</span><input class="input ltr" type="time" name="time_from" value="10:00"></label>
      <label class="field grow"><span>تا ساعت</span><input class="input ltr" type="time" name="time_to" value="12:00"></label>
    </div>
    <label class="field"><span>علت مرخصی</span><select class="input" name="type"><option value="">— انتخاب —</option>
      ${LEAVE_TYPES.map(([k, t]) => `<option value="${k}">${esc(t)}</option>`).join('')}</select></label>
    <label class="field"><span>توضیح</span><textarea class="input" name="reason" maxlength="500" placeholder="مثلاً مراجعه به پزشک"></textarea></label>
    <label class="field"><span>پیوست گواهی (عکس، اختیاری)</span><input class="input" type="file" name="attachment" accept="image/jpeg,image/png,image/*"></label>
    ${manager ? `<label class="row" style="gap:6px"><input type="checkbox" name="approve" checked> همین حالا تأیید شود</label>` : ''}
    <button class="btn primary block">${manager ? 'ثبت مرخصی' : 'ثبت درخواست'}</button>
  </form>`);
  const form = document.querySelector('form[data-form="leave"]');
  const sel = form && form.querySelector('[data-leave-kind]');
  if (sel) sel.addEventListener('change', () => {
    const hours = sel.value === 'hours';
    form.querySelector('[data-leave-days]').style.display = hours ? 'none' : '';
    form.querySelector('[data-leave-hours]').style.display = hours ? '' : 'none';
  });
}

/* ردیف ۱۹۷: عکس گواهی → JPEG کوچک (حداکثر ۶۰٬۰۰۰ نویسه) تا در یک عملیات همگام‌سازی جا شود */
function leaveShrinkImage(file) {
  return new Promise((resolve) => {
    if (!file) return resolve('');
    const fr = new FileReader();
    fr.onerror = () => resolve(null);
    fr.onload = () => {
      const src = String(fr.result || '');
      if (src.length <= LEAVE_ATTACH_MAX && /^data:image\/(jpeg|png);base64,/.test(src)) return resolve(src);
      const img = new Image();
      img.onerror = () => resolve(null);
      img.onload = () => {
        try {
          for (const side of [1280, 1024, 800, 640, 480, 360]) {
            const k = Math.min(1, side / Math.max(img.width, img.height));
            const c = document.createElement('canvas');
            c.width = Math.max(1, Math.round(img.width * k)); c.height = Math.max(1, Math.round(img.height * k));
            c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
            for (const q of [0.8, 0.65, 0.5, 0.4]) {
              const out = c.toDataURL('image/jpeg', q);
              if (out.length <= LEAVE_ATTACH_MAX) return resolve(out);
            }
          }
        } catch (e) { /* بوم در دسترس نیست */ }
        resolve(null);
      };
      img.src = src;
    };
    fr.readAsDataURL(file);
  });
}

function actLeaveAttachment(id) {
  const l = byId('leaves', Number(id));
  if (!l || !l.attachment) return;
  S.modalTitle = 'گواهی پیوست مرخصی';
  modal(`<div style="text-align:center"><img src="${esc(l.attachment)}" alt="گواهی پیوست" style="max-width:100%;max-height:70vh;border-radius:8px"></div>
    <div class="small muted" style="margin-top:8px">${esc((byId('users', l.student_id) || {}).name || '')} · ${esc(leaveWhenFa(l))}</div>`);
}

function actAnnAdd(row) {
  const editing = row && row.id;
  S.modalTitle = editing ? 'ویرایش اطلاعیه' : 'اطلاعیهٔ جدید';
  const sev = editing ? String(row.severity || 'normal') : 'normal';
  modal(`<form data-form="ann">
    ${editing ? `<input type="hidden" name="id" value="${esc(row.id)}">` : ''}
    <label class="field"><span>عنوان</span><input class="input" name="title" required value="${esc(editing ? row.title : '')}"></label>
    <label class="field"><span>متن</span><textarea class="input" name="body" required>${esc(editing ? row.body : '')}</textarea></label>
    <label class="field"><span>اهمیت</span><select class="input" name="severity">
      <option value="normal" ${sev === 'normal' ? 'selected' : ''}>عادی</option>
      <option value="info" ${sev === 'info' ? 'selected' : ''}>اطلاع‌رسانی</option>
      <option value="important" ${sev === 'important' ? 'selected' : ''}>مهم</option></select></label>
    <button class="btn primary block">${editing ? 'ذخیرهٔ تغییرات' : 'انتشار'}</button>
  </form>`);
}

/* ── «مشخصات کامل»: همهٔ فیلدهای واردشده از اکسل، در همان‌جا قابل ویرایش ── */
function actUserFull(id) {
  const u = byId('users', Number(id));
  if (!u) return toast('این کاربر پیدا نشد — صفحه را تازه کنید', 'err');
  const lbl = {};
  if (typeof IMP_FIELDS !== 'undefined' && IMP_FIELDS.students) IMP_FIELDS.students.forEach(fd => { lbl[fd[0]] = fd[1]; });
  const inp = (k, title, val, extra) => `<label class="field"><span>${esc(title)}</span>
    <input class="input" name="${esc(k)}" value="${esc(val == null ? '' : val)}" ${extra || ''}></label>`;
  const nm = splitName(u);
  const core = [
    inp('first_name', 'نام', nm.first, 'required'),
    inp('last_name', 'نام خانوادگی', nm.last),
    inp('national_id', 'کد ملی', u.national_id || '', 'inputmode="numeric" maxlength="10" class="input ltr"'),
    `<label class="field"><span>تاریخ تولد (شمسی)</span>${jalaliDateControl('birth_date', u.birth_date || '')}</label>`,
    inp('gender', 'جنسیت', u.gender || ''),
    u.role === 'student' ? inp('grade', 'پایه', u.grade || '') : '',
  ].join('');
  /* شمارهٔ همراه‌ها — همان ستون‌های اکسل، همگی اینجا و همه قابل ویرایش.
     اگر در اکسل بوده و اینجا خالی است، یعنی آن ستون در مرحلهٔ نگاشت به
     «موبایل» وصل نشده بود؛ از این پس خودکار تشخیص داده می‌شود. */
  const numInp = (k, title, val) => `<label class="field grow" style="min-width:160px"><span>${esc(title)}</span>
    <input class="input ltr" name="${esc(k)}" inputmode="numeric" maxlength="14" value="${esc(val || '')}" placeholder="09xxxxxxxxx"></label>`;
  const phones = [
    numInp('phone', '📱 موبایل دانش‌آموز (نام کاربری)', u.phone),
    numInp('father_phone', '📱 موبایل پدر', u.father_phone),
    numInp('mother_phone', '📱 موبایل مادر', u.mother_phone),
    numInp('guardian_phone', '📱 موبایل سرپرست', u.guardian_phone),
  ].join('');
  const phoneKeys = ['phone', 'father_phone', 'mother_phone', 'guardian_phone'];
  const extras = (typeof IMP_EXTRA_FIELDS !== 'undefined' ? IMP_EXTRA_FIELDS : [])
    .filter(k => phoneKeys.indexOf(k) < 0 && ['first_name', 'last_name', 'gender'].indexOf(k) < 0)
    .map(k => inp(k, lbl[k] || k, u[k] || ''))
    .join('');
  /* فیلدهای دلخواهی که مدیر در ورود اکسل خودش تعریف کرده است */
  const customLabels = (typeof impCustomLabels === 'function' ? impCustomLabels() : {}) || {};
  const custom = Object.keys(u)
    .filter(k => /^x_/.test(k))
    .map(k => inp(k, customLabels[k] || 'مورد دلخواه', u[k] || ''))
    .join('');
  const grp = byId('classes', u.class_id) || {};
  S.modalTitle = 'مشخصات کامل — ' + u.name;
  modal(`<form data-form="user-full">
    <input type="hidden" name="id" value="${esc(u.id)}">
    <div class="small muted" style="margin-bottom:10px;line-height:2">
      نقش: <b>${esc(ROLE_FA[u.role] || u.role)}</b>
      ${grp.grade ? ' · پایه: <b>' + esc(grp.grade) + '</b>' : ''}
      ${grp.branch ? ' · رشته: <b>' + esc(grp.branch) + '</b>' : ''}
      <br>هر تغییری اینجا بدهید، همان لحظه در همهٔ بخش‌های برنامه (فهرست کاربران، حساب خودِ ولی، کارت پیوند و پروندهٔ دانش‌آموز) اعمال می‌شود.
    </div>
    <div class="row" style="flex-wrap:wrap;gap:0 10px">${core}</div>
    <div style="margin-top:8px;padding-top:8px;border-top:1px dashed var(--line)">
      <b class="small">شماره‌های همراه (از اکسل — قابل ویرایش)</b>
      <div class="row" style="flex-wrap:wrap;gap:0 10px;margin-top:6px">${phones}</div>
    </div>
    ${extras ? `<div style="margin-top:8px;padding-top:8px;border-top:1px dashed var(--line)">
      <b class="small">اطلاعات خانواده و تحصیلی (همان ستون‌های اکسل)</b>
      <div class="row" style="flex-wrap:wrap;gap:0 10px;margin-top:6px">${extras}</div></div>` : ''}
    ${custom ? `<div style="margin-top:8px;padding-top:8px;border-top:1px dashed var(--line)">
      <b class="small">ستون‌های دلخواه شما (از اکسل)</b>
      <div class="row" style="flex-wrap:wrap;gap:0 10px;margin-top:6px">${custom}</div></div>` : ''}
    <button class="btn primary block" style="margin-top:12px">ذخیرهٔ همهٔ مشخصات</button>
  </form>`, FORM_MODAL_OPTS)
}

/* ── پنجرهٔ «کاربری»: نام کاربری و رمز، در یک جا، قابل ویرایش و حذف ── */
function actUserCreds(id) {
  const u = byId('users', Number(id));
  if (!u) return toast('این کاربر پیدا نشد — صفحه را تازه کنید', 'err');
  const c = (S.creds && S.creds[u.id]) || null;
  const username = String((c && c.phone) || u.phone || u.national_id || '');
  /* F‑01: رمز فقط از پاسخ مدیر (رمزنگاری‌شده در سرور) می‌آید، نه از دادهٔ محلی */
  const password = (c && c.password) || '';
  S.modalTitle = 'کاربری — ' + fullName(u);
  modal(`<form data-form="user-creds">
    <input type="hidden" name="id" value="${esc(u.id)}">
    <div class="small muted" style="line-height:2;margin-bottom:10px">
      نقش: <b>${esc(ROLE_FA[u.role] || u.role)}</b>
      ${u.national_id ? ' · کد ملی: <span class="ltr">' + esc(u.national_id) + '</span>' : ''}
      <br>با همین دو چیز وارد برنامه می‌شود؛ روی هر گوشی و رایانه‌ای.
    </div>
    <label class="field"><span>نام کاربری (شمارهٔ همراه)</span>
      <input class="input ltr" name="phone" inputmode="numeric" maxlength="11" value="${esc(username)}" placeholder="09xxxxxxxxx"></label>
    <label class="field"><span>رمز عبور</span>
      <input class="input ltr" name="password" value="${esc(password)}" placeholder="رمز عبور" autocomplete="off"></label>
    <div class="row" style="gap:8px;margin-top:4px">
      <button class="btn sm ghost" type="button" data-act="user-auto-pw" data-id="${esc(u.id)}">رمز = کد ملی</button>
      <button class="btn sm ghost" type="button" data-act="user-pick-pw" data-id="${esc(u.id)}">رمز تصادفی</button>
    </div>
    <button class="btn primary block" style="margin-top:12px">ذخیرهٔ نام کاربری و رمز</button>
  </form>
  <div class="row" style="margin-top:10px;gap:8px;justify-content:flex-end">
    <button class="btn sm" type="button" data-act="creds-delete" data-id="${esc(u.id)}" style="background:#b91c1c;color:#fff">حذف این حساب</button>
  </div>
  <div class="small muted" style="margin-top:8px;line-height:1.9">
    اگر رمز را خالی بگذارید، همان رمز فعلی می‌ماند. هر تغییری اینجا بدهید، همان لحظه روی همهٔ دستگاه‌ها اعمال می‌شود و کاربر لازم نیست دوباره نصب کند.
  </div>`);
}

function actUserEdit(id) {
  const u = byId('users', Number(id));
  if (!u) return;
  S.modalTitle = 'ویرایش کاربر — ' + u.name;
  modal(`<form data-form="user-edit">
    <input type="hidden" name="id" value="${esc(u.id)}">
    <label class="field"><span>نام و نام خانوادگی</span><input class="input" name="name" value="${esc(u.name)}" required></label>
    <label class="field"><span>نام کاربری (شمارهٔ همراه)</span>
      <input class="input ltr" name="phone" inputmode="numeric" maxlength="11" value="${esc(u.phone || '')}" placeholder="09xxxxxxxxx"></label>
    <div class="row">
      <label class="field grow"><span>تاریخ تولد (شمسی)</span>${jalaliDateControl('birth_date', u.birth_date || '')}</label>
      <label class="field grow"><span>جنسیت</span>
        <select class="input" name="gender">
          <option value="">—</option>
          <option value="پسر" ${u.gender === 'پسر' ? 'selected' : ''}>پسر</option>
          <option value="دختر" ${u.gender === 'دختر' ? 'selected' : ''}>دختر</option>
        </select></label>
    </div>
    ${userRoleEditHtml(u)}
    ${u.role === 'student' ? userExtraFieldsHtml(u) : ''}
    <label class="field"><span>رمز عبور تازه (خالی بگذارید تا عوض نشود)</span>
      <input class="input ltr" name="password" placeholder="رمز تازه"></label>
    <div class="row" style="margin-top:6px">
      <label class="row small" style="gap:6px;align-items:center">
        <input type="checkbox" name="active" ${u.active !== false ? 'checked' : ''}> حساب فعال باشد
      </label>
    </div>
    <div class="small muted" style="margin-top:8px">اگر رمز را خالی بگذارید، همان رمز فعلی می‌ماند. رمز اولیهٔ هر کاربر برابر کد ملی اوست.</div>
    <button class="btn primary block" style="margin-top:10px">ذخیره</button>
  </form>`, FORM_MODAL_OPTS)
}

/* ── کلاس: ایجاد و ویرایش (پایه و رشته از فهرست تعریف‌ها می‌آید) ── */
function classFormHtml(c) {
  const opts = (arr, val) => arr.map(r =>
    `<option value="${esc(r.name)}" ${String(r.name) === String(val || '') ? 'selected' : ''}>${esc(r.name)}</option>`).join('');
  const grades = lookupList('grade');
  const branches = lookupList('branch');
  const editing = c && c.id;
  const pick = (kind, listArr, val) => {
    if (!listArr.length) {
      return `<input class="input" name="${kind}" value="${esc(val || '')}" placeholder="در بخش ${LOOKUP_FA[kind]}ها تعریف کنید"${kind === 'grade' ? ' required aria-required="true"' : ''}>`;
    }
    /* مقدار فعلی اگر در فهرست تعریف‌ها نباشد هم نمایش داده شود، وگرنه
       ویرایشِ یک کلاس قدیمی بی‌خبر، پایه‌اش را عوض می‌کند. */
    const known = val && listArr.some(r => String(r.name) === String(val));
    const extra = val && !known ? `<option value="${esc(val)}" selected>${esc(val)} (تعریف نشده)</option>` : '';
    return `<select class="input" name="${kind}"${kind === 'grade' ? ' required aria-required="true"' : ''}>${extra}${opts(listArr, val)}</select>`;
  };
  const lvlOf = t => (typeof impGradeLevel === 'function' ? impGradeLevel(t) : 0);
  const gl = editing ? (Number(c.grade_level) || lvlOf(c.grade || c.name) || 0) : 0;
  const mode = editing ? (c.mode || (gl >= 10 ? 'field' : 'class')) : '';
  return `<form data-form="class">
    ${editing ? `<input type="hidden" name="id" value="${esc(c.id)}">` : ''}
    <label class="field"><span>نوع چیدمان</span>
      <select class="input" name="mode">
        <option value="" ${mode ? '' : 'selected'}>— خودکار از روی پایه —</option>
        <option value="class" ${mode === 'class' ? 'selected' : ''}>کلاس‌محور (ابتدایی و متوسطه اول)</option>
        <option value="field" ${mode === 'field' ? 'selected' : ''}>رشته‌محور (متوسطه دوم)</option>
      </select></label>
    <div class="small muted" style="margin:-4px 0 8px;line-height:2">
      کلاس‌محور: یک گروه ثابت مثل «دوم ب» که تا آخر سال عوض نمی‌شود و رشته ندارد.<br>
      رشته‌محور: فقط پایه + رشته (مثل «دهم الکترونیک»). محل برگزاری هر زنگ جداگانه در برنامهٔ هفتگی تعیین می‌شود.
    </div>
    <label class="field"><span>نام کلاس</span>
      <input class="input" name="name" value="${esc(editing ? c.name : '')}" placeholder="خالی بگذارید تا از پایه و رشته ساخته شود"></label>
    <div class="row">
      <label class="field grow"><span>پایه (الزامی)</span>${pick('grade', grades, editing ? c.grade : '')}</label>
      <label class="field grow"><span>رشته (فقط رشته‌محور)</span>${pick('branch', branches, editing ? c.branch : '')}</label>
    </div>
    <input type="hidden" name="kind" value="group">
    <div class="small muted">اگر پایه یا رشتهٔ دلخواه در فهرست نیست، در همین صفحه از بخش «پایه‌ها» یا «رشته‌ها» اضافه کنید.</div>
    <button class="btn primary block" style="margin-top:10px">${editing ? 'ذخیرهٔ تغییرات' : 'ایجاد کلاس'}</button>
  </form>`;
}
/* در رشته‌محور، «کلاس/کارگاه» فقط یک نام است (محل برگزاری). */
function roomFormHtml(c) {
  const editing = c && c.id;
  return `<form data-form="class">
    <input type="hidden" name="kind" value="room">
    ${editing ? `<input type="hidden" name="id" value="${esc(c.id)}">` : ''}
    <label class="field"><span>نام کلاس / کارگاه</span>
      <input class="input" name="name" value="${esc(editing ? c.name : '')}" placeholder="کلاس ۱۰۱ یا کارگاه الکترونیک" required></label>
    <div class="small muted" style="margin-top:6px">همین نام در برنامهٔ هفتگی به هر زنگ داده می‌شود. چیز دیگری لازم نیست.</div>
    <button class="btn primary block" style="margin-top:10px">${editing ? 'ذخیرهٔ تغییرات' : 'افزودن'}</button>
  </form>`;
}
function actClassAdd() { S.modalTitle = 'کلاس جدید'; modal(classFormHtml(null)); }
function actRoomAdd() { S.modalTitle = 'کلاس / کارگاه جدید'; modal(roomFormHtml(null)); }
function actRoomEdit(id) {
  const c = byId('classes', Number(id));
  if (!c) return toast('پیدا نشد', 'err');
  S.modalTitle = 'ویرایش — ' + c.name;
  modal(roomFormHtml(c));
}
function actClassEdit(id) {
  const c = byId('classes', Number(id));
  if (!c) return toast('این کلاس پیدا نشد — صفحه را دوباره باز کنید', 'err');
  S.modalTitle = 'ویرایش کلاس — ' + c.name;
  modal(classFormHtml(c));
}

/* ── پایه و رشته: افزودن و ویرایش ── */
function defFormHtml(kind, row) {
  const editing = row && row.id;
  return `<form data-form="def">
    <input type="hidden" name="kind" value="${esc(kind)}">
    ${editing ? `<input type="hidden" name="id" value="${esc(row.id)}">` : ''}
    <label class="field"><span>نام ${LOOKUP_FA[kind] || ''}</span>
      <input class="input" name="name" required value="${esc(editing ? row.name : (row && row.name) || '')}"></label>
    <label class="field"><span>ترتیب نمایش (اختیاری)</span>
      <input class="input ltr" name="order" inputmode="numeric" value="${esc(editing ? (row.order || '') : '')}" placeholder="۱، ۲، ۳ …"></label>
    <button class="btn primary block">${editing ? 'ذخیرهٔ تغییرات' : 'ثبت'}</button>
  </form>`;
}
function actDefAdd(kind, name) {
  kind = kind === 'branch' ? 'branch' : 'grade';
  S.modalTitle = 'افزودن ' + (LOOKUP_FA[kind] || 'مورد');
  modal(defFormHtml(kind, { name: name || '' }));
}
function actDefEdit(id) {
  const r = byId('lookups', Number(id));
  if (!r) return toast('این مورد پیدا نشد — صفحه را دوباره باز کنید', 'err');
  S.modalTitle = 'ویرایش ' + (LOOKUP_FA[r.kind] || 'مورد') + ' — ' + r.name;
  modal(defFormHtml(r.kind, r));
}

/* ── درس: افزودن و ویرایش ── */
function subjectFormHtml(sb) {
  const editing = sb && sb.id;
  return `<form data-form="subject">
    ${editing ? `<input type="hidden" name="id" value="${esc(sb.id)}">` : ''}
    <label class="field"><span>نام درس</span>
      <input class="input" name="name" required value="${esc(editing ? sb.name : '')}" placeholder="مثلاً ریاضی ۱"></label>
    <label class="field"><span>نوع درس</span>
      <select class="input" name="workshop">
        <option value="" ${editing && sb.workshop ? '' : 'selected'}>نظری — نمره از ۲۰</option>
        <option value="1" ${editing && sb.workshop ? 'selected' : ''}>کارگاهی — نمرهٔ عملی</option>
      </select></label>
    <button class="btn primary block">${editing ? 'ذخیرهٔ تغییرات' : 'ثبت درس'}</button>
  </form>`;
}
function actSubjectAdd() { S.modalTitle = 'درس جدید'; modal(subjectFormHtml(null)); }
function actSubjectEdit(id) {
  const sb = byId('subjects', Number(id));
  if (!sb) return toast('این درس پیدا نشد — صفحه را دوباره باز کنید', 'err');
  S.modalTitle = 'ویرایش درس — ' + sb.name;
  modal(subjectFormHtml(sb));
}

/* فیلدهای تکمیلیِ فرم کاربر — همان کلیدهایی که از اکسل هم می‌آیند،
   تا کاربر دستی هم بتواند همه‌چیز را ثبت کند. */
const USER_EXTRA_FORM = [
  ['father_name', 'نام پدر', ''], ['father_nid', 'کد ملی پدر', 'num'],
  ['father_phone', 'همراه پدر', 'num'], ['mother_name', 'نام مادر', ''],
  ['mother_nid', 'کد ملی مادر', 'num'], ['mother_phone', 'همراه مادر', 'num'],
  ['guardian_phone', 'همراه سرپرست', 'num'],
  ['landline', 'تلفن ثابت', 'num'], ['residence', 'محل سکونت', ''],
  ['address', 'نشانی', ''], ['last_gpa', 'معدل سال گذشته', 'num'],
  ['covered', 'حمایتی (بله/خیر)', ''], ['talent', 'استعداد', ''],
];
/* ردیف ۱۹۷ (F45/F47): بخش مخصوص نقش در «ویرایش کاربر» — همان کلیدهای server/policy.js
   STAFF_ACCESS و staff_access.dart. پیش از این ویرایش برای همه فیلدهای خانوادهٔ دانش‌آموز بود و
   تیک دسترسی، سمت، درس‌های دبیر، پایه/رشته/کلاس و نسبت ولی پس از ساخت عوض نمی‌شد. */
const EDIT_EXEC_ROLES = [['vice', 'معاون'], ['counselor', 'مشاور'], ['staff', 'کارمند'], ['office', 'اجرایی'], ['guard', 'نگهبان'], ['manager', 'مدیر']];
const EDIT_GRANTABLE = ['counselor', 'staff', 'office', 'guard'];
const EDIT_STAFF_ACCESS = [['attendance', 'حضور و غیاب دانش‌آموزان'], ['leaves', 'مرخصی‌ها'], ['notices', 'اطلاعیه‌ها'],
  ['schedule', 'برنامهٔ هفتگی'], ['classes', 'ساختار مدرسه و دروس'], ['grades', 'نمرات'],
  ['reports', 'گزارش‌ها (فقط دیدن)'], ['counsel', 'ارجاع به مشاور'], ['gate', 'درِ مدرسه (مراجعین و خروج زودهنگام)']];
/* ردیف ۱۹۷ (Q06): پیش‌فرض واقعی هر سمت — همان policy.ROLE_DEFAULT_ACCESS؛ access خالی = پیش‌فرض،
   ['none'] = «هیچ» (آگاهانه). فرم تیک‌های مؤثر را نشان می‌دهد و «هیچ‌کدام» را ['none'] ذخیره می‌کند. */
const EDIT_ROLE_DEFAULT_ACCESS = { staff: ['attendance', 'leaves', 'notices'],
  office: ['attendance', 'leaves', 'notices', 'classes', 'grades', 'reports'], guard: ['gate'], counselor: [] };
function editAccessOf(u) {
  const raw = (Array.isArray(u.access) ? u.access : String(u.access || '').split(',')).map(x => String(x).trim()).filter(Boolean);
  if (raw.includes('none')) return new Set();
  return new Set(raw.length ? raw : (EDIT_ROLE_DEFAULT_ACCESS[u.role] || []));
}
function userRoleEditHtml(u) {
  const sel = (name, pairs, val) => `<select class="input" name="${name}">${pairs.map(([v, t]) =>
    `<option value="${esc(v)}" ${String(v) === String(val == null ? '' : val) ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select>`;
  const text = (name, label, val) => `<label class="field grow" style="min-width:150px"><span>${label}</span><input class="input" name="${name}" value="${esc(val || '')}"></label>`;
  if (EDIT_EXEC_ROLES.some(([r]) => r === u.role)) {
    const have = editAccessOf(u);
    const isDefault = EDIT_GRANTABLE.includes(u.role) && !(Array.isArray(u.access) ? u.access.length : String(u.access || '').trim());
    return `<div class="row" style="flex-wrap:wrap">
      <label class="field grow"><span>سمت در مدرسه</span>${sel('role', EDIT_EXEC_ROLES, u.role)}</label>
      ${text('position', 'سمت / عنوان کار', u.position)}
    </div>
    <fieldset class="field" data-edit-access style="border:1px solid var(--line);border-radius:10px;padding:8px 10px">
      <legend class="small">سطح دسترسی (فقط مشاور، کارمند، اجرایی و نگهبان؛ معاون و مدیر همه‌چیز را دارند)</legend>
      ${isDefault ? `<div class="small muted" data-access-default>هنوز تیکی ذخیره نشده؛ پیش‌فرض سمت باز است (همین تیک‌ها).</div>` : ''}
      <div class="small muted">اگر هیچ تیکی نزنید، این شخص پس از ورود فقط راهنمای «دسترسی ندارید» را می‌بیند.</div>
      ${EDIT_STAFF_ACCESS.map(([k, t]) => `<label class="row small" style="gap:6px;align-items:center">
        <input type="checkbox" name="access_${k}" ${have.has(k) ? 'checked' : ''}> ${esc(t)}</label>`).join('')}
    </fieldset>`;
  }
  if (u.role === 'student') {
    const g = lookupList('grade').map(x => [x.name, x.name]);
    const b = lookupList('branch').map(x => [x.name, x.name]);
    const cls = sortBy(list('classes'), 'name').map(c => [c.id, c.name]);
    return `<div class="row" style="flex-wrap:wrap">
      <label class="field grow"><span>پایه</span>${sel('grade', [['', '—'], ...g], u.grade)}</label>
      <label class="field grow"><span>رشته</span>${sel('field', [['', '—'], ...b], u.field)}</label>
      ${isFieldSchoolNow() ? '' : `<label class="field grow"><span>کلاس</span>${sel('class_id', [['', '—'], ...cls], u.class_id)}</label>`}
    </div>`;
  }
  if (u.role === 'parent') {
    return `<div class="row" style="flex-wrap:wrap">
      <label class="field grow"><span>نسبت با دانش‌آموز</span>${sel('relation', [['', '—'], ['پدر', 'پدر'], ['مادر', 'مادر'], ['سرپرست', 'سرپرست']], u.relation)}</label>
      ${text('job', 'شغل', u.job)}
    </div>`;
  }
  if (u.role === 'teacher') {
    const cur = Array.isArray(u.teaches) ? u.teaches : [];
    const curIds = new Set(cur.map(t => Number(t.subject_id)));
    return `<fieldset class="field" data-edit-teaches style="border:1px solid var(--line);border-radius:10px;padding:8px 10px">
      <legend class="small">دروسی که تدریس می‌کند</legend>
      ${sortBy(list('subjects'), 'name').map(sb => {
        const t = cur.find(x => Number(x.subject_id) === Number(sb.id));
        return `<label class="row small" style="gap:6px;align-items:center">
          <input type="checkbox" name="teach_${esc(sb.id)}" data-subject="${esc(sb.name)}" data-grade="${esc((t && t.grade) || '')}" data-branch="${esc((t && t.branch) || '')}" ${curIds.has(Number(sb.id)) ? 'checked' : ''}> ${esc(sb.name)}${t && t.grade ? ' — ' + esc(t.grade) : ''}</label>`;
      }).join('') || '<div class="small muted">هنوز درسی تعریف نشده.</div>'}
    </fieldset>
    <div class="row" style="flex-wrap:wrap">${text('position', 'سمت / عنوان کار', u.position)}</div>`;
  }
  return '';
}

function userExtraFieldsHtml(u) {
  const src = u || {};
  return `<div class="row" style="flex-wrap:wrap">
    ${USER_EXTRA_FORM.map(([k, label, mode]) => `<label class="field grow" style="min-width:150px">
      <span>${esc(label)}</span>
      <input class="input${mode === 'num' ? ' ltr' : ''}" name="${k}"
        ${mode === 'num' ? 'inputmode="numeric"' : ''}
        value="${esc(src[k] == null ? '' : src[k])}"></label>`).join('')}
  </div>`;
}

function actUserAdd(prefill, issueId) {
  S.modalTitle = 'کاربر جدید';
  const P = prefill || {};
  const pv = k => esc(P[k] == null ? '' : P[k]);
  S.fixIssueId = issueId || null;
  const roles = [['student', 'دانش‌آموز'], ['teacher', 'دبیر'], ['parent', 'ولی'], ['vice', 'معاون'],
    ['staff', 'کارمند'], ['office', 'اجرایی'], ['counselor', 'مشاور'], ['guard', 'نگهبان'], ['manager', 'مدیر']];
  modal(`<form data-form="user">
    <label class="field"><span>نام و نام خانوادگی</span><input class="input" name="name" required value="${pv('name')}"></label>
    <div class="row">
      <label class="field grow"><span>نقش</span><select class="input" name="role">
        ${roles.map(([v, t]) => `<option value="${v}" ${(P.role || 'student') === v ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
      ${isFieldSchoolNow() ? '' : `<label class="field grow"><span>کلاس (دانش‌آموز)</span><select class="input" name="class_id">
        <option value="">—</option>${sortBy(list('classes'), 'name').map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label>`}
    </div>
    <div class="row">
      <label class="field grow"><span>کد ملی</span><input class="input ltr" name="national_id" inputmode="numeric" maxlength="10" value="${pv('national_id')}"></label>
      <label class="field grow"><span>شمارهٔ همراه (نام کاربری)</span><input class="input ltr" name="phone" inputmode="numeric" maxlength="11" placeholder="09…" value="${pv('phone')}"></label>
    </div>
    <div class="row">
      <label class="field grow"><span>نام ولی (اختیاری)</span><input class="input" name="parent_name" value="${pv('father_name')}"></label>
      <label class="field grow"><span>همراه ولی (اختیاری)</span><input class="input ltr" name="parent_phone" inputmode="numeric" maxlength="11" placeholder="09…" value="${pv('father_phone')}"></label>
    </div>
    <div class="row">
      <label class="field grow"><span>تاریخ تولد (شمسی)</span>${jalaliDateControl('birth_date', P.birth_date || '')}</label>
      <label class="field grow"><span>جنسیت</span>
        <select class="input" name="gender">
          <option value="">—</option>
          <option value="پسر">پسر</option>
          <option value="دختر">دختر</option>
        </select></label>
    </div>
    ${userExtraFieldsHtml(null)}
    <label class="field"><span>رمز عبور (اختیاری — پیش‌فرض: کد ملی)</span>
      <input class="input ltr" name="password" placeholder="اگر خالی بماند، کد ملی می‌شود"></label>
    <div class="small muted" style="margin-top:6px">نام کاربری هر کاربر همان <b>شمارهٔ همراه</b> است و رمزش <b>کد ملی</b>؛ هر دو بعداً از «ویرایش» قابل تغییرند.</div>
    <button class="btn primary block" style="margin-top:10px">ایجاد کاربر</button>
  </form>`, FORM_MODAL_OPTS)
}

/* ══════════════════════════════════════════════════════════════════
   ورود دسته‌ای از اکسل → client/import.js
   جادوگر چهار مرحله‌ای (انتخاب فایل، نگاشت، بررسی، ثبت) با چهار نوع
   فایل: دانش‌آموزان (۳۹ فیلد + ولی و کلاس)، دبیران، نمرات و حضور.
   ══════════════════════════════════════════════════════════════════ */

async function actBackupNow() {
  try { const r = await api('/api/admin/backup', { method: 'POST' }); toast('پشتیبان ساخته شد: ' + r.file, 'ok'); }
  catch (e) { toast('خطا: ' + e.message, 'err'); }
}

async function actDevices() {
  try {
    const r = await api('/api/admin/devices');
    const box = $('#devices-box');
    if (box) box.innerHTML = r.devices.length ? r.devices.map(d => `<div class="item" style="margin-top:6px">
      <div class="grow"><div class="t">${esc(d.user_name)} <span class="badge">${esc(ROLE_FA[d.role] || d.role)}</span></div>
      <div class="s">${esc(d.name || '')} · ${esc(d.platform)} · ${d.revoked ? 'باطل' : 'فعال'}</div></div>
      ${d.revoked ? '' : `<button class="btn sm danger" data-act="revoke-device" data-id="${d.id}">ابطال</button>`}
    </div>`).join('') : '<div class="muted small">دستگاهی ثبت نشده.</div>';
  } catch (e) { toast(e.message, 'err'); }
}

async function actBackups() {
  try {
    const r = await api('/api/admin/backups');
    S.modalTitle = 'نسخه‌های پشتیبان';
    modal(r.files.length ? `<div class="list">${r.files.map(f => `<div class="item"><div class="grow small ltr">${esc(f)}</div>
      <a class="btn sm" href="/api/admin/backups/${encodeURIComponent(f)}">دانلود</a></div>`).join('')}</div>`
      : '<div class="muted">نسخه‌ای نیست.</div>');
  } catch (e) { toast(e.message, 'err'); }
}

async function actAudit() {
  try {
    const r = await api('/api/admin/audit?limit=60');
    S.modalTitle = 'سابقهٔ تغییرات';
    modal(`<div class="table-wrap"><table><thead><tr><th>زمان</th><th>کاربر</th><th>عملیات</th><th>مجموعه</th></tr></thead><tbody>
      ${r.rows.map(a => `<tr><td class="small">${esc(jdate(a.at) + ' ' + time24(new Date(a.at)))}</td>
      <td class="small">${esc(a.user_id || '—')}</td><td class="small">${esc(a.action || '')}</td><td class="small">${esc(a.collection || '')}</td></tr>`).join('')}
    </tbody></table></div>`);
  } catch (e) { toast(e.message, 'err'); }
}
