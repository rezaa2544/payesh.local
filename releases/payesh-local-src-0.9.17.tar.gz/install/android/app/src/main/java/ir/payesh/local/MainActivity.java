package ir.payesh.local;

import android.app.Activity;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.MediaStore;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * اپلیکیشن کامل اندرویدِ پایش — «همه‌چیز داخل خود گوشی».
 *
 * برخلاف نسخهٔ قدیمی (پوستهٔ مرورگر که آدرس سرور را باز می‌کرد)، این‌جا تمام
 * فایل‌های برنامه (HTML/JS/CSS/آیکون‌ها + موتور همگام‌سازی و کش آفلاین) داخل
 * خودِ APK است و از یک مبدأ امن محلی سرو می‌شود:
 *
 *      https://appassets.androidplatform.net/assets/www/index.html
 *
 * چرا این مبدأ؟ چون سرویس‌ورکر، localStorage و IndexedDB فقط روی https کار
 * می‌کنند و file:// این‌ها را نمی‌دهد. (Service Worker در حالت بسته‌بندی لازم
 * نیست و کلاینت خودش غیرفعالش می‌کند.)
 *
 * اتصال به سرور:
 *   - آدرس سرور (مدرسه یا آدرس عمومی) یک‌بار پیدا می‌شود:
 *       ۱) آدرسی که قبلاً ذخیره شده  ۲) آدرس پخته‌شده در APK
 *       ۳) android-config.json مخزن  ۴) جست‌وجوی خودکار در شبکهٔ محلی
 *   - سپس به صفحهٔ محلی تزریق می‌شود:  window.PAYESH_API_BASE = "https://…"
 *   - اگر هیچ سروری پیدا نشد، برنامه باز هم بالا می‌آید و آخرین دادهٔ ذخیره‌شده
 *     را نشان می‌دهد (هیچ صفحهٔ بن‌بستی وجود ندارد).
 */
public class MainActivity extends Activity {

    private static final String PREFS = "payesh";
    private static final String KEY_URL = "server_url";       /* آدرس انتخاب‌شده */
    private static final String KEY_REMOTE = "config_url";    /* آخرین آدرسِ گرفته‌شده از پیکربندی مرکزی */
    private static final String KEY_LAST = "last_url";        /* آخرین نشانی‌ای که واقعاً باز شد */
    private static final String KEY_PUBLIC = "public_url";    /* آدرس عمومی که خود سرور اعلام کرده */
    private static final String KEY_PAIR = "pair_code";       /* کدی که با اسکن QR آمده است */

    /* میزبان محلیِ دارایی‌های برنامه (فقط داخل خود برنامه) */
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_ORIGIN = "https://" + APP_HOST;
    private static final String APP_URL = APP_ORIGIN + "/assets/www/index.html";

    /* پیکربندی مرکزی: تغییر آدرس بدون نیاز به ساخت دوبارهٔ برنامه */
    private static final String[] CONFIG_URLS = {
        "https://raw.githubusercontent.com/rezaa2544/payesh.local/main/android-config.json",
        "https://cdn.jsdelivr.net/gh/rezaa2544/payesh.local@main/android-config.json",
    };

    private static final int FILE_PICK = 1001;
    private static final int QR_SCAN = 1002;      /* دوربینِ زنده (ZXing) */
    private static final int QR_GALLERY = 1003;   /* عکس از گالری */

    private WebView web;
    private ProgressBar bar;
    private TextView errorView;
    private Button errorButton;
    private LinearLayout splash;
    private TextView splashText;
    private ValueCallback<Uri[]> filePathCallback;

    private SharedPreferences prefs;
    private boolean staleBundle = false;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean scanning = false;
    /* چند بار بارگذاری خودکار دوباره انجام شد (برای اینکه هیچ‌وقت صفحهٔ خطای
       موتور نمایش به کاربر نشان داده نشود) */
    private int retryLoad = 0;
    private static final String TAG = "Payesh";
    private java.util.List<String> queue = new java.util.ArrayList<>();
    private int queueIndex = 0;

    /** آدرس سرور مدرسه — به صفحهٔ محلی تزریق می‌شود */
    private String apiBase = "";
    /** آدرسی که همین حالا در حال بررسی است (برای تلاش دوباره) */
    private String loadedBase = "";
    /** کش دارایی‌ها در حافظه تا هر بار از دیسک خوانده نشود */
    private final Map<String, byte[]> assetCache = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        /* نسخهٔ تازه نصب شده؟ کش قدیمی پاک شود تا فایل‌های تازه دیده شوند */
        try {
            String stamp = BuildConfig.VERSION_NAME + "-" + BuildConfig.VERSION_CODE;
            if (!stamp.equals(prefs.getString("bundle.stamp", ""))) {
                prefs.edit().putString("bundle.stamp", stamp).apply();
                staleBundle = true;
            }
        } catch (Exception ignored) { }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0B1B33);

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setVisibility(View.GONE);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)));

        FrameLayout frame = new FrameLayout(this);
        root.addView(frame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        web = new WebView(this);
        web.setBackgroundColor(0xFF0B1B33);
        web.setVisibility(View.INVISIBLE);
        frame.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        /* صفحهٔ «در حال اتصال» — کاربر فقط همین را می‌بیند */
        splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(android.view.Gravity.CENTER);
        splash.setPadding(dp(28), dp(28), dp(28), dp(28));
        TextView logo = new TextView(this);
        logo.setText("پایش");
        logo.setTextSize(30);
        logo.setTextColor(0xFFFFFFFF);
        logo.setGravity(android.view.Gravity.CENTER);
        splash.addView(logo);
        splashText = new TextView(this);
        splashText.setText(R.string.connecting);
        splashText.setTextSize(15);
        splashText.setTextColor(0xFFB9C6DA);
        splashText.setGravity(android.view.Gravity.CENTER);
        splashText.setPadding(0, dp(12), 0, 0);
        splash.addView(splashText);
        frame.addView(splash, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        /* صفحهٔ خطا — فقط برای حالت‌های بعید (دارایی‌ها خراب نصب شده باشند) */
        LinearLayout errBox = new LinearLayout(this);
        errBox.setOrientation(LinearLayout.VERTICAL);
        errBox.setGravity(android.view.Gravity.CENTER);
        errBox.setPadding(dp(24), dp(24), dp(24), dp(24));
        errBox.setVisibility(View.GONE);
        errorView = new TextView(this);
        errorView.setText(R.string.conn_error);
        errorView.setTextSize(15);
        errorView.setTextColor(0xFFE7EDF6);
        errorView.setGravity(android.view.Gravity.CENTER);
        errBox.addView(errorView);
        errorButton = new Button(this);
        errorButton.setText(R.string.retry);
        errorButton.setOnClickListener(v -> boot());
        errBox.addView(errorButton);
        Button findButton = new Button(this);
        findButton.setText(R.string.find_lan);
        findButton.setOnClickListener(v -> scanLan());
        errBox.addView(findButton);
        Button setButton = new Button(this);
        setButton.setText(R.string.set_manual);
        setButton.setOnClickListener(v -> askServer());
        errBox.addView(setButton);
        frame.addView(errBox, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        errorView.setTag(errBox);

        setContentView(root);
        setupWebView();
        if (staleBundle) {
            /* فقط کش فایل‌ها؛ حافظهٔ محلی (ورود کاربر و صف ثبت‌ها) دست‌نخورده می‌ماند */
            try { web.clearCache(true); } catch (Exception ignored) { }
            staleBundle = false;
        }

        capturePairIntent(getIntent());
        boot();
    }

    /* ═══════════════════════════════════════════════════════════════
       پیوند کارت پیوند (QR):  payesh://pair?c=CODE&h=https://…
       کد را نگه می‌داریم و به صفحهٔ محلی تزریق می‌کنیم؛ صفحه خودش
       کد را می‌سوزاند و کاربر بی‌درنگ داخل حساب خودش می‌شود.
       ═══════════════════════════════════════════════════════════════ */
    private void capturePairIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) return;
        Uri uri = intent.getData();
        if (uri == null || !"payesh".equalsIgnoreCase(uri.getScheme())) return;
        String code = uri.getQueryParameter("c");
        if (code == null || code.isEmpty()) code = uri.getQueryParameter("code");
        if (code == null) return;
        code = code.replaceAll("[^0-9A-Za-z]", "").toUpperCase();
        if (code.length() < 4) return;
        prefs.edit().putString(KEY_PAIR, code).apply();
        /* آدرسی که در QR آمده، اگر هنوز سروری نداریم، همان می‌شود سرور */
        String h = uri.getQueryParameter("h");
        String host = normalize(h);
        if (!host.isEmpty() && prefs.getString(KEY_URL, "").isEmpty()) {
            prefs.edit().putString(KEY_URL, host).apply();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        capturePairIntent(intent);
        if (web != null) {
            final String code = prefs.getString(KEY_PAIR, "");
            if (!code.isEmpty()) {
                /* برنامه از قبل باز بود: همان کد به صفحه داده می‌شود */
                web.loadUrl(APP_URL + "#/pair=" + code);
            }
        }
    }


    /* ═══════════════════════════════════════════════════════════════
       پل بومی برای حافظهٔ مشترک (Arvan S3).

       چرا لازم است؟ مرورگرِ داخل برنامه، پیش از خواندن پاسخ از یک دامنهٔ
       دیگر، «اجازهٔ خواندن» (CORS) می‌خواهد؛ اگر صندوقچهٔ ابری آن را
       نداشته باشد، درخواست بی‌صدا رد می‌شود و کاربر پیام «به حافظه
       نرسیدیم» می‌بیند — درست همان چیزی که اتفاق افتاد.

       این‌جا همان درخواست از خودِ اندروید فرستاده می‌شود: نه CORS، نه
       پیش‌پرواز، نه محدودیت مرورگر. امضای SigV4 در جاوااسکریپت ساخته
       می‌شود و همین‌جا فقط ارسال می‌شود.
       ═══════════════════════════════════════════════════════════════ */
    private class NativeBridge {
        private final AtomicLong seq = new AtomicLong(1);
        private final ExecutorService pool = Executors.newCachedThreadPool();

        /* صفحه کد پیوند را مصرف کرد؛ دیگر به‌کار نمی‌آید */
        @JavascriptInterface
        public void pairCodeUsed() {
            prefs.edit().remove(KEY_PAIR).apply();
        }

        /* ══ اسکن QR با دوربینِ زنده ══════════════════════════════════
           کارت پیوند یک QR دارد؛ دوربین باز می‌شود، کاربر کد را در کادر
           می‌گیرد و برنامه خودش وارد حساب می‌شود. */
        @JavascriptInterface
        public void scanQr() {
            runOnUiThread(() -> {
                try {
                    IntentIntegrator it = new IntentIntegrator(MainActivity.this);
                    it.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
                    it.setPrompt("QR کارت پیوند را داخل کادر بگیرید");
                    it.setBeepEnabled(false);
                    it.setBarcodeImageEnabled(false);
                    it.setOrientationLocked(false);
                    it.setRequestCode(QR_SCAN);
                    it.initiateScan();
                } catch (Exception e) {
                    sendQrError("no_camera");
                }
            });
        }

        /* ══ انتخاب عکسِ QR از گالری ══════════════════════════════════ */
        @JavascriptInterface
        public void pickQr() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.setType("image/*");
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(Intent.createChooser(i, "عکس کارت پیوند را انتخاب کنید"), QR_GALLERY);
                } catch (Exception e) {
                    sendQrError("no_code");
                }
            });
        }

        @JavascriptInterface
        public String s3(final String method, final String url, final String headersJson, final String body) {
            final String id = "r" + seq.getAndIncrement();
            pool.submit(() -> {
                int status = 0;
                String text = "";
                String error = null;
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod(method == null || method.isEmpty() ? "GET" : method);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(40000);
                    c.setInstanceFollowRedirects(false);
                    c.setUseCaches(false);
                    JSONObject h = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                    Iterator<String> keys = h.keys();
                    while (keys.hasNext()) {
                        String k = keys.next();
                        c.setRequestProperty(k, h.optString(k));
                    }
                    if (body != null && !body.isEmpty()) {
                        c.setDoOutput(true);
                        c.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8));
                        c.getOutputStream().flush();
                        c.getOutputStream().close();
                    } else {
                        c.setDoOutput(false);
                    }
                    status = c.getResponseCode();
                    InputStream is = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    text = readStream(is);
                } catch (Exception e) {
                    error = String.valueOf(e.getMessage());
                } finally {
                    if (c != null) c.disconnect();
                }
                final int st = status;
                final String tx = text;
                final String er = error;
                ui.post(() -> {
                    String js = "window.__payeshNativeDone(" + JSONObject.quote(id) + "," + st + ","
                        + JSONObject.quote(tx == null ? "" : tx) + "," + JSONObject.quote(er == null ? "" : er) + ")";
                    try { web.evaluateJavascript(js, null); } catch (Exception ignored) { }
                });
            });
            return id;
        }
    }

    private String readStream(InputStream is) {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
        } catch (Exception ignored) { }
        return sb.toString();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    /* ── راه‌اندازی: پیدا کردن سرور، سپس باز کردنِ برنامهٔ محلی ─────────── */

    private void boot() {
        showSplash(R.string.connecting);
        queue = candidates();
        queueIndex = 0;
        if (!queue.isEmpty()) { verifyThenOpen(queue.get(0)); return; }
        fetchRemoteConfig(url -> {
            if (url != null && !url.isEmpty()) {
                prefs.edit().putString(KEY_REMOTE, url).apply();
                queue = candidates();
                queueIndex = 0;
                if (!queue.isEmpty()) { verifyThenOpen(queue.get(0)); return; }
            }
            showSplash(R.string.searching);
            scanLan();
        });
    }

    /** آدرس را سریع بررسی می‌کند؛ اگر جواب نداد، سراغ بعدی می‌رود؛ در پایان برنامه را آفلاین باز می‌کند */
    private void verifyThenOpen(String base) {
        if (base == null || base.isEmpty()) { openApp(""); return; }
        showSplash(R.string.connecting);
        new Thread(() -> {
            String body = httpGet(base + "/api/health", 2500);
            boolean ok = body != null && body.contains("payesh-local");
            ui.post(() -> {
                if (ok) {
                    prefs.edit().putString(KEY_URL, base).putString(KEY_LAST, base).apply();
                    learnPublicUrl(base);
                    openApp(base);
                } else if (queueIndex + 1 < queue.size()) {
                    queueIndex++;
                    verifyThenOpen(queue.get(queueIndex));
                } else {
                    /* هیچ آدرس ذخیره‌شده‌ای جواب نداد (مثلاً IP سرور عوض شده) →
                       پیش از حالت آفلاین، Wi-Fi همین شبکه جست‌وجو شود؛ scanLan خودش
                       در صورت نیافتن، برنامه را آفلاین باز می‌کند. */
                    showSplash(R.string.searching);
                    scanLan();
                }
            });
        }).start();
    }

    /** همهٔ آدرس‌های ممکن، به‌ترتیب اولویت و بدون تکرار */
    private java.util.List<String> candidates() {
        java.util.List<String> out = new java.util.ArrayList<>();
        for (String raw : new String[]{
                prefs.getString(KEY_URL, ""),
                BuildConfig.PAYESH_URL == null ? "" : BuildConfig.PAYESH_URL,
                prefs.getString(KEY_PUBLIC, "")}) {
            String u = normalize(raw);
            if (!u.isEmpty() && !out.contains(u)) out.add(u);
        }
        for (String raw : prefs.getString(KEY_REMOTE, "").split("\n")) {
            String u = normalize(raw);
            if (!u.isEmpty() && !out.contains(u)) out.add(u);
        }
        return out;
    }

    private interface UrlCallback { void onUrl(String url); }

    /** خواندن پیکربندی مرکزی از مخزن (اگر اینترنت بود) */
    private void fetchRemoteConfig(UrlCallback cb) {
        new Thread(() -> {
            String found = null;
            for (String cfg : CONFIG_URLS) {
                try {
                    String body = httpGet(cfg, 4000);
                    if (body == null) continue;
                    JSONObject j = new JSONObject(body);
                    StringBuilder list = new StringBuilder();
                    String single = normalize(j.optString("url", "").trim());
                    if (!single.isEmpty()) list.append(single);
                    org.json.JSONArray arr = j.optJSONArray("urls");
                    if (arr != null) {
                        for (int i = 0; i < arr.length(); i++) {
                            String u = normalize(arr.optString(i, "").trim());
                            if (u.isEmpty()) continue;
                            if (list.length() > 0) list.append("\n");
                            list.append(u);
                        }
                    }
                    if (list.length() > 0) { found = list.toString(); break; }
                } catch (Exception ignored) { }
            }
            final String result = found;
            ui.post(() -> cb.onUrl(result));
        }).start();
    }

    private String httpGet(String target, int timeoutMs) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(target).openConnection();
            c.setConnectTimeout(timeoutMs);
            c.setReadTimeout(timeoutMs);
            c.setRequestProperty("Accept", "application/json");
            if (c.getResponseCode() != 200) return null;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** باز کردن برنامهٔ کاملِ داخل گوشی، با آدرس سروری که پیدا شد (یا خالی = آفلاین) */
    private void openApp(String base) {
        apiBase = base == null ? "" : base;
        retryLoad = 0;
        splash.setVisibility(View.GONE);
        errorBox().setVisibility(View.GONE);
        bar.setVisibility(View.VISIBLE);
        web.setVisibility(View.VISIBLE);
        web.loadUrl(APP_URL);
    }

    /** تلاش برای پیدا کردن سرویس پایش در همان شبکهٔ Wi-Fi */
    private void scanLan() {
        if (scanning) return;
        scanning = true;
        showSplash(R.string.searching);
        new Thread(() -> {
            String local = localIpv4();
            String found = null;
            if (local != null) {
                String prefix = local.substring(0, local.lastIndexOf('.') + 1);
                ExecutorService pool = Executors.newFixedThreadPool(64);
                final AtomicBoolean hit = new AtomicBoolean(false);
                for (int i = 1; i <= 254 && !hit.get(); i++) {
                    final String host = prefix + i;
                    pool.submit(() -> {
                        if (hit.get()) return;
                        String base = "http://" + host + ":8080";
                        String body = httpGet(base + "/api/health", 450);
                        if (body != null && body.contains("payesh-local")) {
                            hit.set(true);
                            prefs.edit().putString(KEY_URL, base).putString(KEY_LAST, base).apply();
                            ui.post(() -> { learnPublicUrl(base); openApp(base); });
                        }
                    });
                }
                pool.shutdown();
                try { pool.awaitTermination(5, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
                if (hit.get()) { scanning = false; return; }
                found = null;
            }
            scanning = false;
            final String last = prefs.getString(KEY_URL, "");
            ui.post(() -> {
                if (!last.isEmpty()) { openApp(last); return; }
                openApp("");   /* آفلاین، ولی برنامه بالا می‌آید */
            });
        }).start();
    }

    private String localIpv4() {
        try {
            java.util.Enumeration<java.net.NetworkInterface> ifs = java.net.NetworkInterface.getNetworkInterfaces();
            while (ifs.hasMoreElements()) {
                java.net.NetworkInterface ni = ifs.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                java.util.Enumeration<java.net.InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    java.net.InetAddress a = addrs.nextElement();
                    if (a instanceof java.net.Inet4Address && !a.isLoopbackAddress()) {
                        String ip = a.getHostAddress();
                        if (ip == null) continue;
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) return ip;
                    }
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    /* ── نمایش‌ها ──────────────────────────────────────────────────── */

    private void showSplash(int textRes) {
        splashText.setText(textRes);
        splash.setVisibility(View.VISIBLE);
        errorBox().setVisibility(View.GONE);
        bar.setVisibility(View.GONE);
        web.setVisibility(View.INVISIBLE);
    }

    private View errorBox() { return (View) errorView.getTag(); }

    private void showError() {
        splash.setVisibility(View.GONE);
        errorBox().setVisibility(View.VISIBLE);
        web.setVisibility(View.INVISIBLE);
        bar.setVisibility(View.GONE);
    }

    /* ── سرو دارایی‌های برنامه از داخل APK ───────────────────────────── */

    private byte[] asset(String path) {
        if (assetCache.containsKey(path)) return assetCache.get(path);
        try (InputStream in = getAssets().open("www/" + path)) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            byte[] data = out.toByteArray();
            assetCache.put(path, data);
            return data;
        } catch (IOException e) {
            return null;
        }
    }

    private static String mimeOf(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json") || p.endsWith(".webmanifest")) return "application/json";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".ico")) return "image/x-icon";
        if (p.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }

    /** پاسخی که WebView برای درخواست‌های میزبانِ محلی می‌گیرد */
    private WebResourceResponse serveAsset(String path) {
        if (path == null || path.isEmpty() || path.equals("/")) path = "index.html";
        path = path.replaceFirst("^/+", "");
        if (path.startsWith("api/")) {
            /* برنامه داخل گوشی است؛ آدرس‌های API فقط از سرور می‌آیند */
            return new WebResourceResponse("application/json", "utf-8",
                new ByteArrayInputStream("{\"ok\":false,\"error\":\"offline\"}".getBytes(StandardCharsets.UTF_8)));
        }
        byte[] body = asset(path);
        if (body == null && !path.contains(".")) body = asset("index.html");   /* مسیرهای SPA */
        if (body == null) {
            /* هرگز null برنمی‌گردانیم: null یعنی «خودت از اینترنت بگیر» و
               نتیجه‌اش صفحهٔ خطای موتور نمایش بود. */
            Log.w(TAG, "asset missing in APK: " + path);
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<String, String>(),
                new ByteArrayInputStream("فایل در بستهٔ برنامه نیست".getBytes(StandardCharsets.UTF_8)));
        }
        if (path.endsWith("index.html")) {
            /* آدرس سرور و حالت «بسته‌بندی‌شده» را به برنامه تزریق می‌کنیم */
            String html = new String(body, StandardCharsets.UTF_8);
            String bucket = BuildConfig.PAYESH_CLOUD_BUCKET == null ? "" : BuildConfig.PAYESH_CLOUD_BUCKET.trim();
            String pairCode = prefs.getString(KEY_PAIR, "");
            String inject = "<script>window.PAYESH_API_BASE=" + JSONObject.quote(apiBase)
                + (pairCode == null || pairCode.isEmpty() ? "" : ";window.PAYESH_PAIR_CODE=" + JSONObject.quote(pairCode) + ";")
                + ";window.PAYESH_BUILD=" + JSONObject.quote(BuildConfig.VERSION_NAME + " (" + BuildConfig.VERSION_CODE + ")")
                + ";window.PAYESH_BUNDLED=true;"
                + (bucket.isEmpty() ? "" : "window.PAYESH_CLOUD_BUCKET=" + JSONObject.quote(bucket) + ";")
                + "</script>";
            html = html.contains("<head>") ? html.replace("<head>", "<head>" + inject) : inject + html;
            body = html.getBytes(StandardCharsets.UTF_8);
        }
        Map<String, String> headers = new HashMap<>();
        /* هیچ‌چیزِ این برنامه کش نشود: اگر کش شود، بعد از نصب نسخهٔ تازه،
           گوشی همان فایل‌های قدیمی را نشان می‌دهد (صفحهٔ ورودِ کهنه، نسخهٔ
           ۰.۰.۰ و خطاهایی که در نسخهٔ تازه رفع شده‌اند). */
        headers.put("Cache-Control", "no-store, no-cache, must-revalidate");
        headers.put("Pragma", "no-cache");
        headers.put("Expires", "0");
        WebResourceResponse res = new WebResourceResponse(mimeOf(path), "utf-8", new ByteArrayInputStream(body));
        res.setResponseHeaders(headers);
        return res;
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        /* پیشنهادهای خودکارِ کیبورد (autofill) روی کادر نام کاربری/رمز،
           پنجرهٔ پیشنهاد باز می‌کرد و تمرکز کادر را می‌گرفت؛ خاموشش می‌کنیم. */
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            web.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        }
        web.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        web.addJavascriptInterface(new NativeBridge(), "PayeshNative");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (u != null && APP_HOST.equalsIgnoreCase(u.getHost())) {
                    String p = u.getPath();
                    if (p != null && p.startsWith("/assets/www")) p = p.substring("/assets/www".length());
                    return serveAsset(p);
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                /* داخل خودِ برنامه: هر آدرسی که مال برنامه است */
                if (url.startsWith(APP_ORIGIN)) return false;
                /* هر آدرس اینترنتیِ دیگر (سامانهٔ مدرسه، گیت‌هاب، هر جای دیگر) با
                   برنامهٔ بیرونی باز می‌شود؛ هرگز داخل قاب برنامه بارگذاری نمی‌شود
                   تا صفحهٔ خطای انگلیسیِ «Hmmm… can't reach this page» دیده نشود. */
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
                    return true;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return shouldOverrideUrlLoading(view, request == null || request.getUrl() == null ? null : request.getUrl().toString());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                bar.setVisibility(View.GONE);
                /* «about:blank» یعنی عمداً خالی کردیم تا صفحهٔ خطا دیده نشود؛
                   در آن حالت صفحهٔ فارسیِ خودمان باید بماند. */
                if (url != null && url.startsWith("about:")) return;
                retryLoad = 0;
                splash.setVisibility(View.GONE);
                errorBox().setVisibility(View.GONE);
                web.setVisibility(View.VISIBLE);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request == null || !request.isForMainFrame()) return;
                /* دارایی‌های برنامه از داخل خود APK خوانده می‌شوند و باید همیشه باز
                   شوند؛ اگر یک بار نشد، بی‌صدا دوباره تلاش می‌کنیم و در نهایت صفحهٔ
                   فارسیِ خودمان را نشان می‌دهیم — هرگز صفحهٔ خطای موتور نمایش. */
                bar.setVisibility(View.GONE);
                String why = "";
                try { why = String.valueOf(error.getDescription()); } catch (Exception ignored) { }
                Log.w(TAG, "main frame error: " + why + " url=" + (request.getUrl() == null ? "" : request.getUrl()));
                retryLoad++;
                if (retryLoad <= 3) {
                    ui.postDelayed(() -> {
                        if (web != null) { web.loadUrl(APP_URL); }
                    }, 500L * retryLoad);
                } else {
                    ui.post(() -> {
                        try { web.loadUrl("about:blank"); } catch (Exception ignored) { }
                        showError();
                    });
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (request == null || !request.isForMainFrame()) return;
                Log.w(TAG, "main frame http " + (response == null ? "?" : response.getStatusCode()));
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                bar.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                bar.setProgress(p);
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                filePathCallback = cb;
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(Intent.createChooser(i, "انتخاب فایل"), FILE_PICK);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                request.deny();
            }
        });
    }

    /** سرور خودش آدرس عمومی را اعلام می‌کند؛ همان را نگه می‌داریم تا در خانه هم وصل شود */
    private void learnPublicUrl(String base) {
        if (base == null || base.isEmpty()) return;
        new Thread(() -> {
            String body = httpGet(base + "/api/health", 3500);
            if (body == null) return;
            try {
                JSONObject j = new JSONObject(body);
                String pub = normalize(j.optString("public_url", ""));
                if (!pub.isEmpty() && !pub.equals(base)) prefs.edit().putString(KEY_PUBLIC, pub).apply();
            } catch (Exception ignored) { }
        }).start();
    }

    /** سیستم مدرسه خاموش است؟ برنامه با آخرین دادهٔ ذخیره‌شده باز می‌شود. */
    private void showOffline() {
        String last = prefs.getString(KEY_LAST, "");
        if (last.isEmpty()) last = prefs.getString(KEY_URL, "");
        if (last.isEmpty()) last = prefs.getString(KEY_PUBLIC, "");
        /* آفلاین هم همان برنامهٔ داخل گوشی باز می‌شود (نه نسخهٔ کش‌شدهٔ قدیمی) */
        web.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        openApp("");
    }

    private String normalize(String raw) {
        String u = raw == null ? "" : raw.trim();
        if (u.isEmpty()) return "";
        String low = u.toLowerCase();
        if (low.contains("xxxx") || low.contains("tail1234") || low.contains("example") || low.contains("<") || low.contains(">") || low.contains("myschool")) return "";
        if (!u.startsWith("http://") && !u.startsWith("https://")) {
            boolean local = u.matches("^(localhost|[0-9.]+)(:.*)?$") || u.startsWith("192.168.") || u.startsWith("10.");
            u = (local ? "http://" : "https://") + u;
        }
        if (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }

    /** فقط برای حالت اضطراری: پرسیدن آدرس از کاربر */
    private void askServer() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint(R.string.server_hint);
        input.setText(prefs.getString(KEY_URL, BuildConfig.PAYESH_URL == null ? "" : BuildConfig.PAYESH_URL));
        input.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        int pad = dp(16);
        input.setPadding(pad, pad, pad, pad);

        new AlertDialog.Builder(this)
            .setTitle(R.string.server_title)
            .setMessage(R.string.server_help_short)
            .setView(input)
            .setPositiveButton(R.string.save, (d, w) -> {
                String u = normalize(input.getText().toString());
                if (u.isEmpty()) { Toast.makeText(this, R.string.server_hint, Toast.LENGTH_LONG).show(); return; }
                prefs.edit().putString(KEY_URL, u).apply();
                queue = candidates();
                queueIndex = 0;
                verifyThenOpen(u);
            })
            .setNeutralButton(R.string.clear, (d, w) -> {
                prefs.edit().remove(KEY_URL).remove(KEY_REMOTE).remove(KEY_PUBLIC).apply();
                boot();
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    /* نتیجهٔ اسکن را به صفحه بده (همان تابعی که صفحهٔ اسکن دارد) */
    private void sendQr(final String text) {
        runOnUiThread(() -> {
            if (web == null) return;
            try {
                String js = "window.payeshOnQr && window.payeshOnQr(" + JSONObject.quote(text == null ? "" : text) + ")";
                web.evaluateJavascript(js, null);
            } catch (Exception e) { /* بی‌صدا */ }
        });
    }

    private void sendQrError(final String reason) {
        runOnUiThread(() -> {
            if (web == null) return;
            try {
                web.evaluateJavascript("window.payeshOnQrError && window.payeshOnQrError(" + JSONObject.quote(reason) + ")", null);
            } catch (Exception e) { /* بی‌صدا */ }
        });
    }

    /* خواندن QR از یک عکس؛ اگر عکس کج یا کم‌نور بود، چند حالت را امتحان می‌کند */
    private void decodeQrImage(final Uri uri) {
        new Thread(() -> {
            Bitmap bmp = null;
            try (InputStream is = getContentResolver().openInputStream(uri)) {
                bmp = BitmapFactory.decodeStream(is);
            } catch (Exception e) {
                sendQrError("no_code");
                return;
            }
            if (bmp == null) { sendQrError("no_code"); return; }
            Map<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);
            hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
            List<BarcodeFormat> formats = new ArrayList<>();
            formats.add(BarcodeFormat.QR_CODE);
            hints.put(DecodeHintType.POSSIBLE_FORMATS, formats);
            MultiFormatReader reader = new MultiFormatReader();
            reader.setHints(hints);
            int[] variants = {0, 90, 180, 270};
            for (int deg : variants) {
                Bitmap b = deg == 0 ? bmp : rotateBitmap(bmp, deg);
                String found = decodeBitmap(reader, b);
                if (found != null) { sendQr(found); return; }
            }
            sendQrError("no_code");
        }).start();
    }

    private String decodeBitmap(MultiFormatReader reader, Bitmap bmp) {
        if (bmp == null) return null;
        try {
            int w = bmp.getWidth(), h = bmp.getHeight();
            int[] px = new int[w * h];
            bmp.getPixels(px, 0, w, 0, 0, w, h);
            BinaryBitmap bb = new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(w, h, px)));
            Result r = reader.decodeWithState(bb);
            return r == null ? null : r.getText();
        } catch (Exception e) {
            return null;
        } finally {
            try { reader.reset(); } catch (Exception e) { /* بی‌صدا */ }
        }
    }

    private Bitmap rotateBitmap(Bitmap src, int degrees) {
        try {
            android.graphics.Matrix m = new android.graphics.Matrix();
            m.postRotate(degrees);
            return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
        } catch (Exception e) { return null; }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 2, 0, R.string.reload);
        menu.add(0, 1, 1, R.string.change_server);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) { askServer(); return true; }
        if (item.getItemId() == 2) { boot(); return true; }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_PICK && filePathCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
            return;
        }
        if (requestCode == QR_SCAN) {
            IntentResult res = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
            if (res != null && res.getContents() != null) sendQr(res.getContents());
            else sendQrError("cancel");
            return;
        }
        if (requestCode == QR_GALLERY) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) decodeQrImage(data.getData());
            else sendQrError("cancel");
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() { super.onPause(); web.onPause(); }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        if (web.getUrl() == null && !scanning) boot();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
