#!/usr/bin/env bash
# آزمون منفی دروازهٔ CC‑16B — «شاهد ناقص/جعلی/کهنه نباید PASS بگیرد»
#
# اجرا: bash docs/cloud/reports/evidence/verify-cc16b-negative.sh
# خروجی: docs/cloud/reports/evidence/cc16b-negative.txt ⇒ NEGATIVE-OK (pass=N fail=0)
set -u
cd "$(dirname "$0")/../../../.." || { echo "FATAL: repo root not found" >&2; exit 2; }

D=docs/cloud/reports/evidence
GATE=$D/gen-cc16b-evidence.sh
MAN=$D/cc16b-required-labels.txt
DOC=docs/cloud/16b-tenant-provisioning-migration.md
EV=$D/mission-16b-tenant-probe.txt
OUT=$D/cc16b-negative.txt

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
LOG=$TMP/result.txt
: > "$LOG"
PASS=0
FAIL=0

node --experimental-sqlite --disable-warning=ExperimentalWarning "$D/drill-16b-provision-migrate.cjs" > "$TMP/drill.real" 2>&1 || true
cp "$DOC" "$TMP/doc.bak"
cp "$EV" "$TMP/ev.bak"

reject_ok() { # $1=id $2=desc $3=expected-reason-substr, then env pairs
  local id="$1" desc="$2" want="$3"; shift 3
  local err rc
  err=$(env "$@" CC16B_OUT=/dev/null CC16B_RAW_DIR="$TMP" CC16B_MANIFEST="$MAN" CC16B_FAILDIR="$TMP" bash "$GATE" 2>&1 >/dev/null)
  rc=$?
  if [ "$rc" -ne 0 ] && printf '%s' "$err" | grep -q 'CC16B-FAIL' && printf '%s' "$err" | grep -q "$want"; then
    PASS=$((PASS+1)); echo "PASS  $id  gate rejected: $desc  → $(printf '%s' "$err" | head -1 | cut -c1-88)" | tee -a "$LOG"
  else
    FAIL=$((FAIL+1)); echo "FAIL  $id  gate ACCEPTED/mis-reason: $desc  → exit=$rc want=$want got=$(printf '%s' "$err" | head -1)" | tee -a "$LOG"
  fi
  cp "$TMP/doc.bak" "$DOC"; cp "$TMP/ev.bak" "$EV"
}

expect_ok() {
  local id="$1" desc="$2" rc
  CC16B_OUT="$TMP/pos.txt" CC16B_RAW_DIR="$TMP" CC16B_MANIFEST="$MAN" CC16B_FAILDIR="$TMP" bash "$GATE" >/dev/null 2>&1
  rc=$?
  if [ "$rc" -eq 0 ] && grep -qF 'CC16B-OK' "$TMP/pos.txt"; then
    PASS=$((PASS+1)); echo "PASS  $id  gate accepted clean evidence (control positive): $desc" | tee -a "$LOG"
  else
    FAIL=$((FAIL+1)); echo "FAIL  $id  gate rejected CLEAN evidence — gate is broken: $desc → exit=$rc" | tee -a "$LOG"
  fi
}

fake() { printf 'cat %s\n' "$1"; }

expect_ok P0 "اجرای سالم: تمرین ۳۸/۳۸ + شاهد رفتار امروز تازه + Manifest کامل"

# ---------- N1: حذف یک برچسب لازم ----------
LABEL=$(head -1 "$MAN")
python3 - "$TMP/drill.real" "$TMP/n1.txt" "$LABEL" <<'PYEOF'
import sys
src, dst, label = sys.argv[1], sys.argv[2], sys.argv[3]
lines = open(src, encoding='utf-8').read().splitlines()
kept = [l for l in lines if not l.startswith('✓ ' + label)]
kept = [l.replace('SUMMARY pass=38 fail=0 total=38', 'SUMMARY pass=37 fail=0 total=38') for l in kept]
assert len(kept) < len(lines), 'label not found'
open(dst, 'w', encoding='utf-8').write('\n'.join(kept) + '\n')
PYEOF
reject_ok N1 "یک برچسب لازم از بدنهٔ تمرین حذف شد" "LABEL-MISSING" CC16B_DRILL_CMD="$(fake "$TMP/n1.txt")"

# ---------- N2: برچسب با ✗ ----------
sed "s/^✓ $LABEL /✗ $LABEL /" "$TMP/drill.real" > "$TMP/n2.txt"
reject_ok N2 "برچسب با علامت شکست (✗)" "DRILL-CROSS" CC16B_DRILL_CMD="$(fake "$TMP/n2.txt")"

# ---------- N3: SUMMARY جعلی ----------
sed 's/^SUMMARY pass=38 fail=0 total=38$/SUMMARY pass=37 fail=0 total=38/' "$TMP/drill.real" > "$TMP/n3.txt"
reject_ok N3 "SUMMARY ادعایی با شمارش بدنه نمی‌خواند" "SUMMARY-MISMATCH" CC16B_DRILL_CMD="$(fake "$TMP/n3.txt")"

# ---------- N4: گزارش مهاجرت با صفر رکورد ----------
sed -E 's/(^MIGRATION_RUN .*records=)[0-9]+/\10/' "$TMP/drill.real" > "$TMP/n4.txt"
reject_ok N4 "گزارش مهاجرت با تعداد رکورد صفر" "MIGRATION-RECORDS" CC16B_DRILL_CMD="$(fake "$TMP/n4.txt")"

# ---------- N5: دو مستأجر با یک شناسه ----------
TA=$(sed -n 's/.*TENANT_A=\([a-z0-9]*\).*/\1/p' "$TMP/drill.real" | head -1)
sed -E "s/TENANT_A=$TA TENANT_B=[a-z0-9]+/TENANT_A=$TA TENANT_B=$TA/" "$TMP/drill.real" > "$TMP/n5.txt"
reject_ok N5 "دو مستأجر با شناسهٔ یکسان" "TENANT-COLLISION" CC16B_DRILL_CMD="$(fake "$TMP/n5.txt")"

# ---------- N6: زمان ثبت‌نشده ----------
sed -E 's/(^MIGRATION_RUN duration_ms=)[0-9]+/\1undefined/' "$TMP/drill.real" > "$TMP/n6.txt"
reject_ok N6 "گزارش مهاجرت بدون زمان اندازه‌گیری‌شده" "MIGRATION-DURATION" CC16B_DRILL_CMD="$(fake "$TMP/n6.txt")"

# ---------- N7: پایهٔ ممیزی ناموجود ----------
reject_ok N7 "پایهٔ ممیزی ناموجود ⇒ «۰ فایل تغییر» جعلی نباید PASS بگیرد" "BASE-MISSING" CC16B_BASE=0000000

# ---------- N8: شاهد رفتار امروز کهنه ----------
mkdir -p "$TMP/rt"
REPO=$(pwd)
{
  echo '#!/usr/bin/env bash'
  echo "cat > \"$REPO/$EV\" <<'EOF'"
  echo "head: deadbeefdeadbeefdeadbeefdeadbeefdeadbeef"
  echo "EXPECTATIONS=ALL-MET"
  echo "exit=0"
  echo "PRODUCT-DIFF=0"
  echo "EOF"
} > "$TMP/rt/gen-stale.sh"
reject_ok N8 "شاهد رفتار امروز کهنه (head=deadbeef)" "RUNTIME-STALE" CC16B_RUNTIME_CMD="bash $TMP/rt/gen-stale.sh"

# ---------- N9: حذف یک ردیف AC از سند ----------
python3 - "$DOC" <<'PYEOF'
import sys, re
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
s2 = re.sub(r'^\| \*\*AC\u201112\*\* .*\n', '', s, flags=re.M)
assert s2 != s, 'AC-12 row not found'
open(p, 'w', encoding='utf-8').write(s2)
PYEOF
reject_ok N9 "یک ردیف معیار از ماتریس سند حذف شد (۱۲ ← ۱۱)" "AC-COUNT"

# ---------- حکم ----------
{
  echo "# آزمون منفی دروازهٔ CC‑16B — شاهد ناقص/جعلی/کهنه"
  echo "generated_by: docs/cloud/reports/evidence/verify-cc16b-negative.sh"
  echo "head: $(git rev-parse HEAD)"
  echo "generated_at_utc: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo
  cat "$LOG"
  echo
  echo "SUMMARY pass=$PASS fail=$FAIL"
  [ "$FAIL" -eq 0 ] && echo "NEGATIVE-OK" || echo "NEGATIVE-FAILED"
} > "$OUT"
echo "→ $OUT"
tail -3 "$OUT"
[ "$FAIL" -eq 0 ] || exit 1
