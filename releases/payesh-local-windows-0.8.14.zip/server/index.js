#!/usr/bin/env node
'use strict';
/* ═══════════════════════════════════════════════════════════════════
   payesh-local — سرور مدرسه
   Node 22 + SQLite (node:sqlite). بدون وابستگی خارجی.
   ex: node --experimental-sqlite server/index.js
   ═══════════════════════════════════════════════════════════════════ */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const zlib = require('zlib');
const crypto = require('crypto');

const { openStore } = require('./db');
const auth = require('./auth');
const sync = require('./sync');
const policy = require('./policy');
const cfg = require('./config');
const qr = require('./qr');
const s3mem = require('./s3mem');
const outbox = require('./outbox');
const live = require('./live');

function normDigitsLocal(v) {
  return String(v == null ? '' : v)
    .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .replace(/[^\d]/g, '');
}
const update = require('./update');
const tunnel = require('./tunnel');
const { nowISO, json, normDigits, validNationalId, sha256 } = require('./util');

/* ریشهٔ برنامه — آزمون‌ها می‌توانند با PAYESH_APP_ROOT روی یک کپی کار کنند */
const ROOT = process.env.PAYESH_APP_ROOT || path.resolve(__dirname, '..');
const CLIENT_DIR = path.join(ROOT, 'client');
/* اگر پوشهٔ نصب فقط‌خواندنی باشد (Program Files)، به‌روزرسانی فایل‌های رابط
   را این‌جا می‌نویسد و سرور از همین لایه سرو می‌کند. */
const OVERLAY_DIR = path.join(process.env.PAYESH_DATA || path.join(ROOT, 'data'), 'app');
const RELEASES_DIR = path.join(ROOT, 'releases');
const PORT = Number(process.env.PORT || process.env.SERVER_PORT || 8080);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = process.env.PAYESH_DATA || path.join(ROOT, 'data');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');

const store = openStore(path.join(DATA_DIR, 'payesh.sqlite'));

/* ── تعریف‌های پایه (پایه‌ها و رشته‌ها) ───────────────────────────────
   اگر مدرسه هنوز چیزی تعریف نکرده باشد، فهرست‌های رایج یک‌بار ساخته
   می‌شوند تا فرم کلاس از همان اول پر باشد. مدیر می‌تواند هر کدام را
   ویرایش یا حذف کند و مورد تازه اضافه کند. */
(function ensureLookups() {
  try {
    if ((store.all('lookups') || []).length) return;
    const seed = [
      ['grade', 'دهم'], ['grade', 'یازدهم'], ['grade', 'دوازدهم'],
      ['branch', 'شبکه و نرم‌افزار'], ['branch', 'ریاضی و فیزیک'],
      ['branch', 'علوم تجربی'], ['branch', 'علوم انسانی'],
    ];
    const counters = { grade: 0, branch: 0 };
    for (const [kind, name] of seed) {
      counters[kind] += 1;
      store.insert('lookups', { kind, name, order: counters[kind], school_id: 1, created_at: new Date().toISOString() });
    }
  } catch (e) { /* بی‌صدا: نداشتن این فهرست نباید بالا آمدن سرور را بشکند */ }
})();

/* ── تعمیر خودکار حساب‌های بی‌رمز ────────────────────────────────────
   هر کاربری که شمارهٔ همراه دارد ولی رمز ندارد (مثلاً ولی‌ای که هنگام ثبت
   دانش‌آموز ساخته شد و کد ملی نداشت) تا امروز نمی‌توانست وارد شود و پیام
   «نام کاربری یا رمز اشتباه است» می‌گرفت. این‌جا یک‌بار برای همیشه رمز
   ساخته می‌شود (کد ملی، و اگر نبود رمز تصادفی) و در فهرست کاربران برای
   مدیر نمایش داده می‌شود. پس از تعمیر، فایل ورودِ گوشی هم دوباره منتشر
   می‌شود تا همان لحظه روی گوشی کار کند. */
(function repairCredentials() {
  try {
    let fixed = 0;
    for (const u of (store.all('users') || [])) {
      if (u.active === false) continue;
      if (!auth.credentialsFor(u)) continue;              /* شماره ندارد؛ نام کاربری ممکن نیست */
      if (u.password_hash && u.phone_hash) continue;       /* سالم است */
      const patched = auth.applyDefaultCredentials(u);
      if (patched.password_hash) {
        store.update('users', u.id, {
          password_hash: patched.password_hash,
          phone_hash: patched.phone_hash || patched.password_hash,
          password_plain: patched.password_plain || u.password_plain || '',
        });
        fixed += 1;
      }
    }
    if (fixed) {
      process.env.PAYESH_LOG !== '0' && console.log('🔑 ' + fixed + ' حساب بی‌رمز تعمیر شد (رمز ساخته شد)');
      outbox.publishAll(store).catch(() => null);
    }
  } catch (e) { /* بی‌صدا */ }
})();

/* نسخه‌ای که همین پروسه با آن بالا آمده — برای تشخیص «راه‌اندازی مجدد لازم است» */
const RUNNING_VERSION = (() => {
  try { return JSON.parse(fs.readFileSync(path.join(RELEASES_DIR, 'manifest.json'), 'utf8')).version || '0.0.0'; }
  catch (e) { return '0.0.0'; }
})();

/* ── نسخه و آپدیت ─────────────────────────────────────────────────── */
function readManifest() {
  try {
    return JSON.parse(fs.readFileSync(path.join(RELEASES_DIR, 'manifest.json'), 'utf8'));
  } catch (e) {
    return { version: '0.0.0', built_at: null, files: [] };
  }
}
function readHistory(version) {
  try {
    return JSON.parse(fs.readFileSync(path.join(RELEASES_DIR, 'history', version + '.json'), 'utf8'));
  } catch (e) { return null; }
}
function updateCheck(current) {
  const latest = readManifest();
  const cur = readHistory(current);
  /* مقایسه همیشه بر اساس هش است، نه فقط شمارهٔ نسخه:
     اگر همان نسخه دوباره ساخته شده باشد هم تفاوت فایل‌ها دیده می‌شود. */
  const known = new Map((cur ? cur.files : []).map(f => [f.path, f.sha256]));
  const changed = (latest.files || []).filter(f => known.get(f.path) !== f.sha256);
  const removed = [...known.keys()].filter(p => !(latest.files || []).some(f => f.path === p));
  if (cur && !changed.length && !removed.length) {
    return { ok: true, up_to_date: true, version: latest.version, built_at: latest.built_at, server_time: nowISO() };
  }
  /* کلاینت فقط فایل‌های client/ را می‌تواند در کش خودش بنشاند */
  const client = changed
    .filter(f => String(f.path).startsWith('client/') || !String(f.path).includes('/'))
    .map(f => ({ path: String(f.path).replace(/^client\//, ''), sha256: f.sha256, size: f.size }));
  return {
    ok: true,
    up_to_date: false,
    version: latest.version,
    running_version: RUNNING_VERSION,
    restart_pending: latest.version !== RUNNING_VERSION,
    built_at: latest.built_at,
    changed,
    client,
    removed,
    total_size: changed.reduce((a, f) => a + (f.size || 0), 0),
    client_size: client.reduce((a, f) => a + (f.size || 0), 0),
    full_size: (latest.files || []).reduce((a, f) => a + (f.size || 0), 0),
    server_time: nowISO(),
  };
}

/* ── نشست ─────────────────────────────────────────────────────────── */
function actorFrom(req) {
  const h = String(req.headers.authorization || '');
  const token = h.startsWith('Bearer ') ? h.slice(7).trim() : '';
  const s = auth.verifySession(store, token);
  if (!s) return null;
  return { user: s.user, role: s.user.role, device: s.device, session: s.session };
}

/* ── محدودیت ساده نرخ (در حافظه) ───────────────────────────────────── */
const buckets = new Map();
function rateLimit(key, max, windowMs) {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || now - b.start > windowMs) { b = { start: now, n: 0 }; buckets.set(key, b); }
  b.n++;
  return b.n <= max;
}

/* ── بدنهٔ درخواست ────────────────────────────────────────────────── */
function readBody(req, limit = 4 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > limit) { reject(new Error('body_too_large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (e) { reject(new Error('bad_json')); }
    });
    req.on('error', reject);
  });
}

/* ── فایل‌های استاتیک ─────────────────────────────────────────────── */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.apk': 'application/vnd.android.package-archive', '.zip': 'application/zip',
  '.txt': 'text/plain; charset=utf-8', '.woff2': 'font/woff2',
};

function safeJoin(base, target) {
  const p = path.normalize(path.join(base, target));
  return p.startsWith(path.normalize(base)) ? p : null;
}

function sendFile(req, res, filePath, opts = {}) {
  let st;
  try { st = fs.statSync(filePath); } catch (e) { return false; }
  if (!st.isFile()) return false;
  const ext = path.extname(filePath).toLowerCase();
  const etag = '"' + crypto.createHash('sha1')
    .update(String(st.size) + ':' + String(st.mtimeMs)).digest('hex').slice(0, 20) + '"';
  const noStore = opts.noStore || false;

  const headers = {
    'content-type': MIME[ext] || 'application/octet-stream',
    'etag': etag,
    'cache-control': noStore ? 'no-store' : 'no-cache',
    'x-content-type-options': 'nosniff',
  };
  if (opts.download) headers['content-disposition'] = `attachment; filename="${path.basename(filePath)}"`;

  if (req.headers['if-none-match'] === etag) { res.writeHead(304, headers); res.end(); return true; }

  const isText = /^(text\/|application\/(json|manifest))/.test(headers['content-type']);
  const accept = String(req.headers['accept-encoding'] || '');
  let body = fs.readFileSync(filePath);
  if (isText && body.length > 500) {
    if (/\bbr\b/.test(accept)) { body = zlib.brotliCompressSync(body); headers['content-encoding'] = 'br'; }
    else if (/\bgzip\b/.test(accept)) { body = zlib.gzipSync(body); headers['content-encoding'] = 'gzip'; }
  }
  headers['content-length'] = body.length;
  res.writeHead(200, headers);
  res.end(req.method === 'HEAD' ? undefined : body);
  return true;
}

/* ── تبدیل رکورد کاربر برای کلاینت ─────────────────────────────────── */
function userRow(u) {
  return {
    id: u.id, name: u.name, role: u.role, phone: u.phone, national_id: u.national_id || '',
    class_id: u.class_id || null, subject: u.subject || '', active: u.active !== false,
    position: u.position || '', created_at: u.created_at || null,
  };
}
/* ── مسیرهای API ──────────────────────────────────────────────────── */
async function api(req, res, url, ip) {
  const p = url.pathname;
  const q = url.searchParams;
  const m = req.method;

  /* سلامت — کلاینت با همین حالت سروری را تشخیص می‌دهد */
  if (p === '/api/health' && m === 'GET') {
    return json({
      ok: true, name: 'payesh-local', version: RUNNING_VERSION,
      installed_version: readManifest().version,
      restart_pending: readManifest().version !== RUNNING_VERSION,
      time: nowISO(), server_time: nowISO(), uptime_s: Math.round(process.uptime()),
      setup_done: !auth.needsSetup(store), school: (store.get('schools', 1) || {}).name || null,
      data_dir: DATA_DIR, db_file: path.join(DATA_DIR, 'payesh.sqlite'),
      public_url: cfg.publicUrl(store) || null,
      instance: cfg.instanceId(store),
      cloud_ready: (() => {
        try { const v = s3mem.usingMeta(store).get(); return !!(v.endpoint && v.bucket && v.accessKey && v.secret); }
        catch (e) { return false; }
      })(),
    });
  }

  if (p === '/api/version' && m === 'GET') {
    const mf = readManifest();
    return json({ ok: true, version: mf.version, built_at: mf.built_at, shell: mf.shell || null });
  }

  if (p === '/api/update/check' && m === 'GET') {
    return json(updateCheck(String(q.get('current') || '0.0.0')));
  }

  /* اطلاعات شبکه برای صفحهٔ نصب و کلاینت (بدون احراز هویت) */
  if (p === '/api/network' && m === 'GET') {
    return json({
      ok: true,
      public_url: cfg.publicUrl(store) || null,
      lan_urls: cfg.lanUrls(PORT),
      port: PORT,
      instance: cfg.instanceId(store),
    });
  }

  /* QR برای آدرس نصب/پیوند — بدون وابستگی خارجی */
  if (p === '/api/qr' && m === 'GET') {
    const text = String(q.get('text') || cfg.publicUrl(store) || (cfg.lanUrls(PORT)[0] || '')).slice(0, 300);
    if (!text) return json({ ok: false, error: 'empty_text' }, 400);
    const scale = Math.max(2, Math.min(16, Number(q.get('scale') || 8)));
    try {
      const png = qr.toPNG(qr.encode(text), scale, 4);
      return { body: png, headers: { 'content-type': 'image/png', 'cache-control': 'public, max-age=300' } };
    } catch (e) {
      return json({ ok: false, error: 'qr_failed' }, 400);
    }
  }

  if (p === '/api/setup/state' && m === 'GET') {
    return json({ ok: true, needs_setup: auth.needsSetup(store), version: readManifest().version,
      data_dir: DATA_DIR, db_file: path.join(DATA_DIR, 'payesh.sqlite'),
      school: (store.get('schools', 1) || {}).name || null,
      has_password: !auth.needsSetup(store) ? auth.hasPassword((store.all('users').find(u => u.role === 'manager')) || null) : false });
  }

  if (p === '/api/setup' && m === 'POST') {
    if (!rateLimit('setup:' + ip, 10, 60_000)) return json({ ok: false, error: 'rate_limited' }, 429);
    const body = await readBody(req);
    const r = auth.setup(store, body);
    if (!r.ok) return json(r, 400);
    return json(r);
  }

  if (p === '/api/auth/pair' && m === 'POST') {
    if (!rateLimit('pair:' + ip, 20, 60_000)) return json({ ok: false, error: 'rate_limited' }, 429);
    const body = await readBody(req);
    const r = auth.pair(store, body);
    if (!r.ok) return json(r, 400);
    return json(r);
  }

  if (p === '/api/auth/transfer/redeem' && m === 'POST') {
    if (!rateLimit('transfer:' + ip, 20, 60_000)) return json({ ok: false, error: 'rate_limited' }, 429);
    const body = await readBody(req);
    const r = auth.redeemTransfer(store, body.code, body);
    return json(r, r.ok ? 200 : 400);
  }



  /* «یک‌بار ورود، همیشه داخل»: دستگاهِ مورد اعتماد بی‌صدا نشست تازه می‌گیرد */
  if (p === '/api/auth/refresh' && m === 'POST') {
    if (!rateLimit('refresh:' + ip, 60, 60_000)) return json({ ok: false, error: 'rate_limited' }, 429);
    const body = await readBody(req);
    const r = auth.refreshWithDevice(store, body);
    if (!r.ok) return json(r, 401);
    return json(r);
  }

  /* نجاتِ مدیر: اگر حساب مدیر رمز ندارد و کاربر پشتِ خودِ رایانهٔ مدرسه است،
     یک‌بار می‌تواند شماره + رمز بسازد و بلافاصله وارد شود. (فقط از خود دستگاه) */
  if (p === '/api/auth/claim' && m === 'POST') {
    const remote = String((req.socket && req.socket.remoteAddress) || '').replace('::ffff:', '');
    const local = remote === '::1' || remote === '127.0.0.1' || remote.startsWith('127.');
    if (!local) return json({ ok: false, error: 'local_only' }, 403);
    if (!rateLimit('claim:' + ip, 10, 60_000)) return json({ ok: false, error: 'rate_limited' }, 429);
    const body = await readBody(req);
    const mgr = store.all('users').find(u => u.role === 'manager' && u.active !== false);
    if (!mgr) return json({ ok: false, error: 'no_manager' }, 400);
    const phone = normDigitsLocal(body.phone || mgr.phone || '');
    if (phone.length !== 11) return json({ ok: false, error: 'bad_phone' }, 400);
    const set = auth.setPassword(store, mgr.id, body.password);
    if (!set.ok) return json(set, 400);
    /* شمارهٔ همراه = نام کاربری؛ روی خود دستگاه اجازه داریم آن را با شمارهٔ دلخواه مدیر هم‌تراز کنیم */
    if (!mgr.phone || normDigitsLocal(mgr.phone) !== phone) {
      store.update('users', mgr.id, { phone });
      store.audit({ user_id: mgr.id, role: 'manager', action: 'phone_reset', collection: 'users' });
    }
    store.audit({ user_id: mgr.id, role: 'manager', action: 'password_claim', collection: 'users' });
    const dev = auth.login(store, { phone, password: body.password, name: 'رایانهٔ مدرسه', platform: 'server' });
    return json(dev.ok ? Object.assign({ ok: true }, dev) : { ok: true, need_login: true });
  }

  if (p === '/api/auth/login' && m === 'POST') {
    /* محدودیت ورود به ازای «همان شماره» شمرده می‌شود، نه به ازای یک آدرس.
       در مدرسه همهٔ گوشی‌ها یک آدرس مشترک دارند؛ اگر سقف روی آدرس بود،
       ورودِ گروهی کاربران همدیگر را بیرون می‌گذاشت و پیام «رمز اشتباه»
       می‌گرفتند. سقف کلیِ آدرس هم بالا است تا حملهٔ انبوه بسته بماند. */
    const body = await readBody(req);
    const who = normDigitsLocal(body.phone || '');
    if (!rateLimit('login-ip:' + ip, 240, 60_000)) return json({ ok: false, error: 'rate_limited' }, 429);
    if (who && !rateLimit('login-user:' + who, 20, 60_000)) return json({ ok: false, error: 'rate_limited' }, 429);
    const r = auth.login(store, body);
    if (!r.ok) {
      store.audit({ action: 'login_failed', role: 'system', collection: 'users', after: { ip } });
      return json(r, 401);
    }
    store.audit({ user_id: r.user.id, role: r.user.role, action: 'login', collection: 'users' });
    return json(r);
  }

  if (p === '/api/auth/unlock' && m === 'POST') {
    if (!rateLimit('unlock:' + ip, 30, 60_000)) return json({ ok: false, error: 'rate_limited' }, 429);
    const body = await readBody(req);
    /* قفل موقت پس از چند PIN اشتباه — روی همان دستگاه، ذخیره‌شده در پایگاه‌داده */
    const devKey = 'lock:' + sha256(String(body.device_token || ip)).slice(0, 32);
    const lock = store.getMeta(devKey, null);
    if (lock && lock.until && Date.parse(lock.until) > Date.now()) {
      return json({ ok: false, error: 'locked', until: lock.until, tries: lock.tries }, 429);
    }
    const r = body && body.password
      ? auth.unlockWithPassword(store, body)
      : auth.unlock(store, body);
    if (!r.ok) {
      const tries = ((lock && lock.tries) || 0) + 1;
      if (tries >= 8) {
        store.setMeta(devKey, { tries, until: new Date(Date.now() + 10 * 60_000).toISOString() });
        store.audit({ role: 'system', action: 'pin_locked', collection: 'devices', after: { ip } });
      } else {
        store.setMeta(devKey, { tries, until: null });
      }
      return json(r, 401);
    }
    store.setMeta(devKey, { tries: 0, until: null });
    return json(r);
  }

  /* از این‌جا به بعد نیاز به نشست */
  const actor = actorFrom(req);
  if (!actor && p.startsWith('/api/')) return json({ ok: false, error: 'unauthorized' }, 401);

  if (p === '/api/me' && m === 'GET') {
    return json({ ok: true, user: userRow(actor.user), role: actor.role, device_id: actor.device ? actor.device.id : null });
  }

  if (p === '/api/auth/logout' && m === 'POST') {
    auth.logout(store, actor.session);
    return json({ ok: true });
  }

  if (p === '/api/auth/transfer' && m === 'POST') {
    const r = auth.createTransfer(store, actor.user.id, actor.device ? actor.device.id : null);
    return json(Object.assign(r, { public_url: cfg.publicUrl(store) || null }));
  }

  if (p === '/api/auth/pin' && m === 'POST') {
    const body = await readBody(req);
    const r = auth.changePin(store, actor.device, body.pin);
    return json(r, r.ok ? 200 : 400);
  }

  if (p === '/api/bootstrap' && m === 'GET') {
    const school = store.get('schools', 1) || {};
    const year = store.all('school_years').find(y => y.active) || {};
    return json({
      ok: true, server_time: nowISO(),
      school: { id: 1, name: school.name, type: school.type, level: school.level, city: school.city, capabilities: school.capabilities || {} },
      year: { title: year.title || '' },
      user: Object.assign({}, userRow(actor.user), { password: auth.passwordOf(store, actor.user) }),
      role: actor.role,
      counts: {
        users: store.count('users'), classes: store.count('classes'),
        attendance: store.count('attendance'), grades: store.count('grades'),
      },
      version: readManifest().version,
      update: store.getMeta('update:last', null) || null,
    });
  }

  if (p === '/api/v1/pull' && m === 'GET') {
    const out = sync.pull(store, actor, { since: q.get('since'), collections: q.get('collections') });
    return json(out);
  }

  if (p === '/api/sync' && m === 'POST') {
    const body = await readBody(req, 8 * 1024 * 1024);
    const ctx = { device_id: actor.device ? actor.device.id : null, ip };
    const out = sync.push(store, actor, body, ctx);
    /* ثبت‌های تازه در صندوقچهٔ ابری آینه می‌شوند تا اگر «مدرسه» دستگاهی
       دیگر باشد، همان‌ها را هم ببیند. خطای ابر هرگز جلوی ثبت را نمی‌گیرد. */
    if (out && out.ok && (out.applied || []).length) {
      const okUids = new Set((out.applied || []).map(a => a.uid));
      const fresh = (Array.isArray(body && body.ops) ? body.ops : []).filter(op => okUids.has(String(op && op.uid || '')));
      if (fresh.length) {
        outbox.mirror(store, actor, fresh, ctx)
          .then(m => { if (m && m.count) console.log('[outbox] ' + m.count + ' ثبت در صندوقچه آینه شد'); })
          .catch(() => { /* ابر در دسترس نیست — داده روی همین دستگاه محفوظ است */ });
      }
    }
    return json(out);
  }

  /* ── صندوقچهٔ آفلاین: وضعیت، اعمال دستی، خلاصهٔ دانش‌آموز ── */
  if (p === '/api/outbox/state' && m === 'GET') {
    return json(await outbox.state(store));
  }

  /* ── همگام‌سازی زنده: هر دستگاه هر ۱ ثانیه همین را می‌پرسد ────────── */
  if (p === '/api/live/rev' && m === 'GET') {
    return json({
      ok: true, rev: live.localRev(store), at: new Date().toISOString(),
      every_ms: live.INTERVAL_MS, cloud: !!(await live.cloudCfg(store)),
    });
  }

  if (p === '/api/live/state' && m === 'GET') {
    const st = live.status(store);
    let remote = null;
    try { remote = await live.readRemote(store); } catch (e) { remote = null; }
    const ob = await outbox.state(store);
    return json({ ok: true, every_ms: live.INTERVAL_MS, local_rev: st.local_rev,
      published_rev: st.published_rev, seen_rev: st.seen_rev, last: st.last,
      remote: remote ? { rev: remote.rev, at: remote.at, by: remote.by } : null,
      cloud: ob.cloud, bucket: ob.bucket, pending: ob.pending });
  }

  if (p === '/api/outbox/drain' && m === 'POST') {
    if (!outbox.SERVER_ROLES.has(actor.role)) return json({ ok: false, error: 'forbidden' }, 403);
    const out = await outbox.drain(store);
    const snap = await outbox.pushSnapshot(store).catch(() => ({ ok: false }));
    /* نسخهٔ گوشی (بدون سرور) هم تازه می‌شود: رمزها + دادهٔ هر نفر */
    const published = await outbox.publishAll(store).catch(() => null);
    return json(Object.assign({}, out, { snapshot: snap, published }));
  }

  /* انتشار دستی بستهٔ گوشی (وقتی مدیر کاربر یا رمزی را عوض کرده) */
  if (p === '/api/outbox/publish' && m === 'POST') {
    if (!outbox.SERVER_ROLES.has(actor.role)) return json({ ok: false, error: 'forbidden' }, 403);
    const r = await outbox.publishAll(store);
    return json(Object.assign({ ok: !!(r.auth && r.auth.ok) }, r));
  }

  /* آنچه گوشی لازم دارد: نشانی صندوقچه + کلید (فقط برای کاربر واردشده) */
  if (p === '/api/phone/config' && m === 'GET') {
    let c = s3mem.usingMeta(store).get();
    if (!c.bucket && c.accessKey) { try { c = await s3mem.ensureBucket(store); } catch (e) { /* بعداً */ } }
    return json({
      ok: true,
      config: { endpoint: c.endpoint, bucket: c.bucket, region: c.region, prefix: c.prefix, accessKey: c.accessKey, secret: c.secret, pathStyle: c.pathStyle },
      ready: !!(c.endpoint && c.bucket && c.accessKey && c.secret),
    });
  }

  if (p === '/api/outbox/snapshot' && m === 'GET') {
    const sid = Number(q.get('student_id'));
    if (!sid) return json({ ok: false, error: 'bad_student' }, 400);
    if (['parent', 'student'].includes(actor.role)) {
      /* ولی/دانش‌آموز فقط خلاصهٔ همان فرزند خودش را می‌بیند */
      const scope = policy.buildScope(store, actor.user);
      if (!scope.all && !scope.studentIds.has(sid)) return json({ ok: false, error: 'forbidden' }, 403);
    }
    return json(await outbox.readSnapshot(store, sid));
  }

  /* پروندهٔ یک دانش‌آموز با اسکوپ */
  const sm = p.match(/^\/api\/students\/(\d+)$/);
  if (sm && m === 'GET') {
    const id = Number(sm[1]);
    const scope = policy.buildScope(store, actor.user);
    if (!scope.all && !scope.studentIds.has(id)) return json({ ok: false, error: 'out_of_scope' }, 403);
    const u = store.get('users', id);
    if (!u || u.role !== 'student') return json({ ok: false, error: 'not_found' }, 404);
    return json({
      ok: true, student: userRow(u),
      attendance: store.byRef('attendance', 'ref2', id),
      grades: store.byRef('grades', 'ref2', id),
      internships: store.byRef('internships', 'ref2', id),
    });
  }

  /* ── مدیر ── */
  if (p.startsWith('/api/admin/') && actor.role !== 'manager') {
    return json({ ok: false, error: 'forbidden' }, 403);
  }

  if (p === '/api/admin/stats' && m === 'GET') {
    const today = new Date().toISOString().slice(0, 10);
    const att = store.all('attendance').filter(a => a.date === today);
    const present = att.filter(a => a.status === 'present').length;
    const students = store.count('users', " AND json_extract(data,'$.role')='student'");
    return json({
      ok: true, today, students,
      attendance_today: att.length,
      present_today: present,
      absent_today: att.filter(a => a.status === 'absent').length,
      late_today: att.filter(a => a.status === 'late').length,
      grades_pending: store.count('grades', " AND json_extract(data,'$.status')='pending'"),
      devices: store.db.prepare('SELECT COUNT(*) AS n FROM devices WHERE revoked_at IS NULL').get().n,
      audit: store.recentAudit(15),
      stats: store.stats(),
      version: readManifest().version,
    });
  }

  if (p === '/api/admin/pair-code' && m === 'POST') {
    const body = await readBody(req);
    const r = auth.createPairCode(store, Number(body.user_id), actor.user.id);
    return json(r, r.ok ? 200 : 400);
  }

  if (p === '/api/admin/network' && m === 'GET') {
    if (actor.role !== 'manager') return json({ ok: false, error: 'forbidden' }, 403);
    return json({
      ok: true,
      public_url: cfg.publicUrl(store) || null,
      lan_urls: cfg.lanUrls(PORT),
      port: PORT,
      instance: cfg.instanceId(store),
      tunnel: await cfg.tunnelStatus(store, { force: q.get('force') === '1' }),
      public: await tunnel.status(store),
    });
  }

  if (p === '/api/admin/network' && m === 'POST') {
    if (actor.role !== 'manager') return json({ ok: false, error: 'forbidden' }, 403);
    const body = await readBody(req);
    if (body.public_url !== undefined) {
      const u = cfg.normalizeUrl(body.public_url);
      if (u && !/^https:\/\//i.test(u)) return json({ ok: false, error: 'https_required' }, 400);
      cfg.setMeta(store, 'public_url', u);
      /* آدرس دستی = اولویت «custom»؛ تونل خودکار آن را بازنویسی نمی‌کند */
      cfg.setMeta(store, 'tunnel_provider', u ? 'custom' : '');
      store.audit({ user_id: actor.user.id, role: 'manager', action: 'network_public_url', collection: 'config', after: { public_url: u } });
    }
    return json({
      ok: true,
      public_url: cfg.publicUrl(store) || null,
      tunnel: await cfg.tunnelStatus(store, { force: true }),
    });
  }

  /* ── تونل عمومی: دسترسی از هر اینترنتی ─────────────────────────── */
  if (p === '/api/admin/tunnel' && m === 'GET') {
    if (actor.role !== 'manager') return json({ ok: false, error: 'forbidden' }, 403);
    const st = await tunnel.status(store);
    st.probe = await cfg.tunnelStatus(store, { force: q.get('force') === '1' });
    return json(st);
  }

  if (p === '/api/admin/tunnel' && m === 'POST') {
    if (actor.role !== 'manager') return json({ ok: false, error: 'forbidden' }, 403);
    const body = await readBody(req).catch(() => ({}));
    const action = String(body.action || 'refresh');

    if (action === 'enable') {
      const r = await tunnel.enableFunnel(PORT);
      if (r.ok) tunnel.rememberPublicUrl(store, r.url, 'tailscale');
      store.audit({ user_id: actor.user.id, role: 'manager', action: 'tunnel_enable', collection: 'config', after: r });
      return json(Object.assign({ ok: r.ok }, r, { status: await tunnel.status(store) }), r.ok ? 200 : 400);
    }

    if (action === 'login') {
      const r = tunnel.login();
      return json(Object.assign({ ok: r.ok }, r, { status: await tunnel.status(store) }), r.ok ? 200 : 400);
    }

    if (action === 'off') {
      if (body.tailscale_too) await tunnel.disableFunnel(PORT);
      cfg.setMeta(store, 'public_url', '');
      store.audit({ user_id: actor.user.id, role: 'manager', action: 'tunnel_off', collection: 'config' });
      return json({ ok: true, status: await tunnel.status(store) });
    }

    if (action !== 'refresh') return json({ ok: false, error: 'unknown_action' }, 400);

    /* refresh: فقط تشخیص */
    const r = await tunnel.refresh(store, { quiet: false });
    return json(Object.assign({ ok: true }, r, { status: await tunnel.status(store) }));
  }

  /* ── حافظهٔ ابری (صندوقچهٔ S3 ایرانی) ─────────────────────────────── */
  /* پیکربندی صندوقچه برای «هر دستگاهِ واردشده» — گوشی/تبلت هم بدون تایپ کلید می‌داند
     کجا بنویسد (برای وقتی که سیستم مدرسه خاموش است). کلید فقط به کاربر واردشده داده می‌شود. */
  if (p === '/api/cloud/config' && m === 'GET') {
    let c = s3mem.usingMeta(store).get();
    if (!c.bucket && c.accessKey) { try { c = await s3mem.ensureBucket(store); } catch (e) { /* بعداً */ } }
    return json({
      ok: true,
      config: {
        endpoint: c.endpoint, bucket: c.bucket, region: c.region, prefix: c.prefix,
        accessKey: c.accessKey, secret: c.secret, pathStyle: c.pathStyle,
      },
      ready: !!(c.endpoint && c.bucket && c.accessKey && c.secret),
    });
  }

  if (p === '/api/admin/cloud' && m === 'GET') {
    /* اگر نام صندوقچه هنوز معلوم نیست، همین‌جا از حساب می‌پرسیم */
    let view = s3mem.usingMeta(store).get();
    if (!view.bucket && view.accessKey && view.secret) {
      try { view = await s3mem.ensureBucket(store); } catch (e) { /* بی‌اینترنت — همان پیش‌فرض */ }
    }
    const reveal = q.get('reveal') === '1';
    return json({
      ok: true,
      config: Object.assign({}, view, {
        secret: view.secret ? (reveal ? view.secret : '••••••••') : '',
        accessKey: reveal ? view.accessKey : (view.accessKey ? view.accessKey.slice(0, 4) + '…' : ''),
        configured: !!(view.endpoint && view.bucket && view.accessKey && view.secret),
        source: view.source || (s3mem.usingMeta(store).isDefault() ? 'default' : 'saved'),
        built_in: s3mem.usingMeta(store).isDefault(),
      }),
      region_guess: s3mem.regionOf(view),
    });
  }

  if (p === '/api/admin/cloud' && m === 'POST') {
    const body = await readBody(req);
    const cur = s3mem.usingMeta(store).get();
    const next = s3mem.normalize(Object.assign({}, cur, body));
    /* اگر کاربر کلید را با • فرستاد، همان قبلی بماند */
    if (/^•+$/.test(String(body.secret || ''))) next.secret = cur.secret;
    if (/…$/.test(String(body.accessKey || ''))) next.accessKey = cur.accessKey;
    s3mem.usingMeta(store).set(next);
    store.audit({ user_id: actor.user.id, role: 'manager', action: 'cloud_config', collection: 'meta' });
    let out = next;
    if (!out.bucket && out.accessKey && out.secret) {
      try { out = await s3mem.ensureBucket(store); } catch (e) { /* بعداً دوباره */ }
    }
    return json({ ok: true, bucket: out.bucket || null,
      configured: !!(out.endpoint && out.bucket && out.accessKey && out.secret) });
  }

  if (p === '/api/admin/cloud/phone-check' && m === 'POST') {
    if (actor.role !== 'manager') return json({ ok: false, error: 'forbidden' }, 403);
    const steps = [];
    let cfg = s3mem.normalize(s3mem.usingMeta(store).get());
    if (!cfg.bucket) {
      try { cfg = await s3mem.ensureBucket(store); steps.push({ step: 'bucket', ok: !!cfg.bucket, bucket: cfg.bucket || null }); }
      catch (e) { steps.push({ step: 'bucket', ok: false, error: e.message }); }
    } else steps.push({ step: 'bucket', ok: true, bucket: cfg.bucket });
    if (!cfg.bucket) return json({ ok: false, steps });
    let probe = await s3mem.corsProbe(cfg);
    steps.push({ step: 'cors', ok: !!probe.ok, status: probe.status, allow_origin: probe.allow_origin, error: probe.error || null });
    if (!probe.ok && probe.reachable) {
      /* اجازه نبود: همین‌جا می‌گذاریم و دوباره آزمایش می‌کنیم */
      try {
        await s3mem.setCors(cfg);
        steps.push({ step: 'set_cors', ok: true });
      } catch (e) {
        steps.push({ step: 'set_cors', ok: false, error: e.message, status: e.status || 0, detail: String(e.detail || '').slice(0, 200) });
      }
      probe = await s3mem.corsProbe(cfg);
      steps.push({ step: 'cors_after', ok: !!probe.ok, status: probe.status, allow_origin: probe.allow_origin, error: probe.error || null });
    }
    store.audit({ user_id: actor.user.id, role: 'manager', action: 'cloud_phone_check', collection: 'meta' });
    return json({ ok: !!probe.ok, bucket: cfg.bucket, steps });
  }

  if (p === '/api/admin/cloud/reset' && m === 'POST') {
    s3mem.usingMeta(store).clear();
    outbox.forgetPutHashes();
    store.setMeta('live:published', '');
    store.setMeta('live:seen', '');
    store.audit({ user_id: actor.user.id, role: 'manager', action: 'cloud_reset', collection: 'meta' });
    let out = s3mem.usingMeta(store).get();
    try { out = await s3mem.ensureBucket(store); } catch (e) { /* بدون اینترنت */ }
    return json({ ok: true, bucket: out.bucket || null, source: 'default' });
  }

  if (p === '/api/admin/cloud/test' && m === 'POST') {
    const body = await readBody(req);
    const cur = s3mem.usingMeta(store).get();
    const merged = Object.assign({}, cur, body && body.config ? body.config : {});
    if (/^•+$/.test(String(merged.secret || ''))) merged.secret = cur.secret;
    const result = await s3mem.test(s3mem.normalize(merged));
    store.audit({ user_id: actor.user.id, role: 'manager', action: 'cloud_test', collection: 'meta' });
    return json(Object.assign({ ok: !!result.ok }, result));
  }


  if (p === '/api/admin/cloud/cors' && m === 'POST') {
    const body = await readBody(req);
    const cur = s3mem.usingMeta(store).get();
    let cfg = s3mem.normalize(Object.assign({}, cur, body && body.config ? body.config : {}));
    if (/^•+$/.test(String(cfg.secret || ''))) cfg.secret = cur.secret;
    cfg = s3mem.smartParse(cfg);
    try {
      await s3mem.setCors(cfg);
      const back = await s3mem.getCors(cfg);
      store.audit({ user_id: actor.user.id, role: 'manager', action: 'cloud_cors', collection: 'meta' });
      return json({ ok: true, origins: (back && back.origins) || [], applied: s3mem.CORS_XML ? true : true });
    } catch (e) {
      return json({ ok: false, error: e.message, detail: e.detail || null, status: e.status || 0 }, 200);
    }
  }

  /* ── رمز جاری همهٔ کاربران — فقط مدیر، برای اینکه بتواند رمز را بگوید ── */
  if (p === '/api/admin/users/credentials' && m === 'GET') {
    if (actor.role !== 'manager') return json({ ok: false, error: 'forbidden' }, 403);
    const rows = (store.all('users') || []).map(u => ({
      id: u.id, name: u.name, role: u.role,
      phone: u.phone || '', password: auth.passwordOf(store, u),
    }));
    return json({ ok: true, users: rows });
  }

  /* ── حذف دسته‌ای کاربران ──────────────────────────────────────────── */
  if (p === '/api/admin/users/bulk-delete' && m === 'POST') {
    if (actor.role !== 'manager') return json({ ok: false, error: 'forbidden' }, 403);
    const body = await readBody(req);
    const ids = (Array.isArray(body.ids) ? body.ids : []).map(Number)
      .filter(n => Number.isFinite(n) && n > 0 && n !== Number(actor.user.id));
    let deleted = 0;
    for (const id of ids) {
      const user = store.get('users', id);
      if (!user) continue;
      store.remove('users', id);
      /* پیوندهای ولی هم پاک می‌شوند تا «ولیِ بی‌فرزند» نماند */
      const links = (store.all('parent_links') || [])
        .filter(l => Number(l.parent_id) === id || Number(l.student_id) === id);
      for (const l of links) store.remove('parent_links', l.id);
      store.audit({ user_id: actor.user.id, role: 'manager', action: 'user_delete', collection: 'users', record_id: id, before: auth.publicUser(user) });
      deleted += 1;
    }
    if (deleted) outbox.publishAll(store).catch(() => null);
    return json({ ok: true, deleted });
  }

  /* ── ویرایش/حذف کاربر توسط مدیر (نام کاربری = شماره، رمز) ─────────── */
  const um = p.match(/^\/api\/admin\/users\/(\d+)$/);
  if (um && (m === 'PATCH' || m === 'PUT')) {
    if (actor.role !== 'manager') return json({ ok: false, error: 'forbidden' }, 403);
    const id = Number(um[1]);
    const user = store.get('users', id);
    if (!user) return json({ ok: false, error: 'user_not_found' }, 404);
    const body = await readBody(req);
    const patch = {};
    if (body.name) patch.name = String(body.name).trim().slice(0, 80);
    if (body.phone != null) {
      const phone = normDigits(body.phone);
      if (phone && phone.length < 10) return json({ ok: false, error: 'bad_phone' }, 400);
      const dup = phone && auth.phoneTaken(store, phone, id);
      if (dup) return json({ ok: false, error: 'duplicate_phone', name: dup.name }, 409);
      patch.phone = phone;
    }
    if (body.national_id != null) {
      const nid = normDigits(body.national_id);
      if (nid && !validNationalId(nid)) return json({ ok: false, error: 'bad_national_id' }, 400);
      patch.national_id = nid;
    }
    if (body.active != null) patch.active = !!body.active;
    if (body.role && ['student', 'teacher', 'parent', 'vice', 'counselor', 'office', 'staff', 'manager'].includes(body.role)) patch.role = body.role;
    const saved = store.update('users', id, patch);
    let pw = null;
    let shownPassword = null;
    if (body.password) { pw = auth.setPassword(store, id, body.password); shownPassword = String(body.password); }
    else if (body.auto_password) {
      /* «ساخت/بازسازی رمز»: کد ملی، و اگر کد ملی نبود رمز تصادفی —
         هیچ حسابی نباید بی‌رمز بماند. */
      const cur = store.get('users', id) || {};
      const c = auth.credentialsFor(cur);
      if (!c) return json({ ok: false, error: 'no_phone' }, 400);
      pw = auth.setPassword(store, id, c.password);
      shownPassword = c.password;
    }
    store.audit({ user_id: actor.user.id, role: 'manager', action: 'user_update', collection: 'users', record_id: id, after: Object.assign({}, patch, pw ? { password_changed: true } : {}) });
    /* گوشی‌ها بی‌درنگ نام کاربری/رمز تازه را ببینند */
    outbox.publishAll(store).catch(() => null);
    return json({
      ok: true, user: auth.publicUser(store.get('users', id)),
      password: pw && pw.ok ? shownPassword : null,
      password_set: !!(pw && pw.ok), error: pw && !pw.ok ? pw.error : undefined,
    });
  }

  if (um && m === 'DELETE') {
    if (actor.role !== 'manager') return json({ ok: false, error: 'forbidden' }, 403);
    const id = Number(um[1]);
    const user = store.get('users', id);
    if (!user) return json({ ok: false, error: 'user_not_found' }, 404);
    if (id === actor.user.id) return json({ ok: false, error: 'cannot_delete_self' }, 400);
    store.remove('users', id);
    const links = (store.all('parent_links') || [])
      .filter(l => Number(l.parent_id) === id || Number(l.student_id) === id);
    for (const l of links) store.remove('parent_links', l.id);
    store.audit({ user_id: actor.user.id, role: 'manager', action: 'user_delete', collection: 'users', record_id: id, before: auth.publicUser(user) });
    outbox.publishAll(store).catch(() => null);
    return json({ ok: true, deleted: id });
  }

  if (p === '/api/auth/password' && m === 'POST') {
    const body = await readBody(req);
    const r = auth.changeOwnPassword(store, actor.user.id, body.current, body.next);
    if (!r.ok) return json(r, 400);
    store.audit({ user_id: actor.user.id, role: actor.role, action: 'password_change', collection: 'users' });
    return json({ ok: true });
  }

  const pwUser = p.match(/^\/api\/admin\/users\/(\d+)\/password$/);
  if (pwUser && m === 'POST') {
    if (actor.role !== 'manager') return json({ ok: false, error: 'forbidden' }, 403);
    const body = await readBody(req);
    const r = auth.setPassword(store, Number(pwUser[1]), body.password);
    if (!r.ok) return json(r, 400);
    store.audit({ user_id: actor.user.id, role: 'manager', action: 'password_set', collection: 'users', record_id: Number(pwUser[1]) });
    /* رمزِ تازه را برمی‌گردانیم تا همان لحظه در جدول دیده شود */
    return json({ ok: true, password: String(body.password) });
  }

  if (p === '/api/admin/devices' && m === 'GET') return json({ ok: true, devices: auth.listDevices(store) });

  const dm = p.match(/^\/api\/admin\/devices\/([a-f0-9]+)$/);
  if (dm && m === 'DELETE') {
    auth.revokeDevice(store, dm[1]);
    store.audit({ user_id: actor.user.id, role: 'manager', action: 'device_revoke', collection: 'devices' });
    return json({ ok: true });
  }

  if (p === '/api/admin/audit' && m === 'GET') {
    return json({ ok: true, rows: store.recentAudit(Number(q.get('limit') || 100)) });
  }

  /* ── به‌روزرسانی درجا: بررسی، اعمال، بازگشت ─────────────────────── */
  if (p === '/api/admin/update' && m === 'GET') {
    const plan = await update.plan(store, { force: false });
    const last = store.getMeta('update:last', null);
    return json({
      ok: true,
      auto: update.autoCheckEnabled(store),
      auto_apply: update.autoApplyEnabled(store),
      base: String(process.env.PAYESH_UPDATE_BASE || cfg.getMeta(store, 'update_base') || ''),
      bases: update.bases(store),
      running_version: RUNNING_VERSION,
      installed_version: readManifest().version,
      restart_pending: readManifest().version !== RUNNING_VERSION,
      plan,
      last,
      progress: update.status(),
    });
  }

  if (p === '/api/admin/update/check' && m === 'POST') {
    const body = await readBody(req).catch(() => ({}));
    const plan = await update.plan(store, { force: body.force !== false });
    store.setMeta('update:checked', { at: nowISO(), available: !!plan.available, version: plan.remote_version || null, error: plan.ok ? null : plan.error });
    return json({ ok: true, plan });
  }

  if (p === '/api/admin/update/apply' && m === 'POST') {
    if (!rateLimit('update:' + ip, 6, 60_000)) return json({ ok: false, error: 'rate_limited' }, 429);
    const body = await readBody(req).catch(() => ({}));
    const r = await update.apply(store, { force: true, by: actor.user.name || 'manager' });
    if (r.ok && r.applied) {
      /* اگر کد سرور عوض شده، همین پروسه باید دوباره بالا بیاید */
      if (r.restart) scheduleRestart('update');
      return json(Object.assign(r, { restarting: !!(r.restart && autoRestartEnabled()) }));
    }
    return json(r, r.ok ? 200 : 502);
  }

  if (p === '/api/admin/update/rollback' && m === 'POST') {
    const r = update.rollback(store);
    if (r.ok) scheduleRestart('rollback');
    return json(Object.assign(r, { restarting: r.ok && autoRestartEnabled() }), r.ok ? 200 : 400);
  }

  if (p === '/api/admin/update/settings' && m === 'POST') {
    const body = await readBody(req);
    if (body.auto != null) cfg.setMeta(store, 'update_auto', !!body.auto);
    if (body.auto_apply != null) cfg.setMeta(store, 'update_auto_apply', !!body.auto_apply);
    if (body.base != null) {
      const b = String(body.base).trim();
      if (b && !/^https?:\/\//i.test(b)) return json({ ok: false, error: 'bad_url' }, 400);
      cfg.setMeta(store, 'update_base', b);
    }
    return json({ ok: true, auto: update.autoCheckEnabled(store), auto_apply: update.autoApplyEnabled(store), base: cfg.getMeta(store, 'update_base') || '' });
  }

  if (p === '/api/admin/update/restart' && m === 'POST') {
    scheduleRestart('manual');
    return json({ ok: true, restarting: true });
  }

  if (p === '/api/admin/backup' && m === 'POST') {
    const file = store.backupTo(BACKUP_DIR, 48);
    return json({ ok: true, file: path.basename(file), size: fs.statSync(file).size });
  }
  if (p === '/api/admin/backups' && m === 'GET') {
    let files = [];
    try { files = fs.readdirSync(BACKUP_DIR).filter(f => f.endsWith('.sqlite')).sort().reverse(); } catch (e) { /* noop */ }
    return json({ ok: true, files, dir: BACKUP_DIR });
  }
  const bm = p.match(/^\/api\/admin\/backups\/([A-Za-z0-9._-]+)$/);
  if (bm && m === 'GET') {
    const f = safeJoin(BACKUP_DIR, bm[1]);
    if (!f || !sendFile(req, res, f, { download: true, noStore: true })) return json({ ok: false, error: 'not_found' }, 404);
    return null;
  }

  /* ورود دسته‌ای کاربران (CSV از سمت کلاینت پارس می‌شود) */
  if (p === '/api/admin/import' && m === 'POST') {
    const body = await readBody(req, 8 * 1024 * 1024);
    return json(importUsers(body));
  }

  if (p === '/api/admin/export' && m === 'GET') {
    const collection = String(q.get('collection') || 'users');
    if (!policy.collectionAllowed(collection)) return json({ ok: false, error: 'bad_collection' }, 400);
    const rows = store.all(collection);
    return { status: 200, headers: { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="${collection}.csv"` }, body: toCSV(rows) };
  }

  if (p === '/api/admin/settings' && m === 'POST') {
    const body = await readBody(req);
    const s = store.get('schools', 1) || {};
    const patch = {};
    if (body.name) patch.name = String(body.name).slice(0, 80);
    if (body.city != null) patch.city = String(body.city).slice(0, 60);
    if (body.capabilities) patch.capabilities = Object.assign({}, s.capabilities || {}, body.capabilities);
    const saved = store.update('schools', 1, patch);
    return json({ ok: true, school: saved });
  }

  return json({ ok: false, error: 'not_found' }, 404);
}

/* ── ورود دسته‌ای ─────────────────────────────────────────────────── */
function importUsers(body) {
  const kind = body.kind === 'staff' ? 'staff' : 'students';
  const rows = Array.isArray(body.rows) ? body.rows : [];
  const created = [];
  const errors = [];
  const existingNid = new Set(store.all('users').map(u => normDigits(u.national_id)).filter(Boolean));

  for (let i = 0; i < rows.length; i++) {
    const r = rows[i] || {};
    const name = String(r.name || r.full_name || '').trim();
    const nid = normDigits(r.national_id || r.nid || '');
    const phone = normDigits(r.phone || r.mobile || '');
    if (!name) { errors.push({ row: i + 2, error: 'missing_name' }); continue; }
    if (nid && !validNationalId(nid)) { errors.push({ row: i + 2, error: 'bad_national_id', nid }); continue; }
    if (nid && existingNid.has(nid)) { errors.push({ row: i + 2, error: 'duplicate_national_id', nid }); continue; }

    let classId = null;
    if (kind === 'students' && r.class_name) {
      const cls = store.all('classes').find(c => String(c.name).trim() === String(r.class_name).trim());
      if (cls) classId = cls.id;
      else errors.push({ row: i + 2, error: 'class_not_found', class_name: r.class_name, warning: true });
    }

    if (phone && auth.phoneTaken(store, phone, null)) {
      errors.push({ row: i + 2, error: 'duplicate_phone', phone });
      continue;
    }
    /* نام کاربری = شمارهٔ همراه، رمز اولیه = کد ملی (خودکار) */
    const u = store.insert('users', auth.applyDefaultCredentials({
      name, role: kind === 'staff' ? (r.role || 'teacher') : 'student',
      national_id: nid, phone, class_id: classId,
      subject: String(r.subject || ''), position: String(r.position || ''),
      active: true, school_id: 1, created_at: nowISO(),
    }));
    if (nid) existingNid.add(nid);
    created.push(userRow(u));

    /* اگر دانش‌آموز است و نام/تلفن ولی آمده، حساب ولی و پیوند ساخته شود */
    if (kind === 'students' && (r.parent_name || r.parent_phone)) {
      const pName = String(r.parent_name || 'ولی ' + name).trim();
      const pPhone = normDigits(r.parent_phone || '');
      let parent = store.all('users').find(u2 => u2.role === 'parent' && pPhone && normDigits(u2.phone) === pPhone);
      if (!parent) {
        parent = store.insert('users', { name: pName, role: 'parent', phone: pPhone, active: true, school_id: 1, created_at: nowISO() });
      }
      store.insert('parent_links', { parent_id: parent.id, student_id: u.id, relation: r.relation || 'father', created_at: nowISO() });
    }
  }
  store.audit({ role: 'manager', action: 'import_' + kind, collection: 'users', after: { count: created.length } });
  return { ok: true, created: created.length, errors, users: created };
}

function toCSV(rows) {
  if (!rows.length) return '\uFEFF';
  const keys = [...new Set(rows.flatMap(r => Object.keys(r).filter(k => !k.startsWith('_'))))];
  const esc = v => {
    let s = v == null ? '' : String(v);
    if (/^[=+\-@]/.test(s)) s = "'" + s;          /* ضد تزریق فرمول */
    return '"' + s.replace(/"/g, '""') + '"';
  };
  return '\uFEFF' + [keys.join(','), ...rows.map(r => keys.map(k => esc(r[k])).join(','))].join('\n');
}

/* ── سرور ─────────────────────────────────────────────────────────── */
const server = http.createServer(async (req, res) => {
  const started = Date.now();
  const ip = cfg.clientIp(req);
  let url;
  try { url = new URL(req.url, 'http://' + (req.headers.host || 'localhost')); }
  catch (e) { res.writeHead(400).end(); return; }

  /* سرآیندهای امنیتی پایه */
  res.setHeader('referrer-policy', 'no-referrer');
  res.setHeader('permissions-policy', 'geolocation=(), microphone=(), camera=()');

  /* ── اجازهٔ دسترسی برنامه‌های دیگر (CORS) ────────────────────────────
     نسخهٔ اندروید فایل‌هایش را از مبدأ محلی باز می‌کند
     (https://appassets.androidplatform.net) و برای حرف زدن با سیستم مدرسه
     به این سرآیندها نیاز دارد. بدون آن، مرورگر پاسخ را دور می‌ریزد و
     کاربر فقط «به سیستم نرسیدیم» می‌بیند. */
  const origin = String(req.headers.origin || '');
  res.setHeader('access-control-allow-origin', origin || '*');
  res.setHeader('vary', 'Origin');
  res.setHeader('access-control-allow-methods', 'GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS');
  res.setHeader('access-control-allow-headers', 'authorization, content-type, accept, x-requested-with, x-payesh-device');
  res.setHeader('access-control-expose-headers', 'content-length, etag');
  res.setHeader('access-control-max-age', '86400');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  try {
    if (url.pathname.startsWith('/api/')) {
      const out = await api(req, res, url, ip);
      if (out && !res.writableEnded) {
        const body = out.body !== undefined ? out.body : JSON.stringify(out);
        const headers = Object.assign({ 'content-type': 'application/json; charset=utf-8' }, out.headers || {});
        if (out.body === undefined && !headers['content-type']) headers['content-type'] = 'application/json; charset=utf-8';
        res.writeHead(out.status || 200, headers);
        res.end(body);
      }
      return;
    }

    /* دانلودها (نصب‌کننده‌ها و APK) */
    if (url.pathname.startsWith('/downloads/')) {
      const rel = url.pathname.replace('/downloads/', '');
      const file = safeJoin(RELEASES_DIR, rel);
      if (file && sendFile(req, res, file, { download: false })) return;
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }).end('not found');
      return;
    }

    /* صفحهٔ نصب */
    if (url.pathname === '/install') {
      if (sendFile(req, res, path.join(CLIENT_DIR, 'install.html'))) return;
    }

    /* لینک کارت پیوند: /join/ABCD-EFGH */
    if (url.pathname.startsWith('/join/')) {
      if (sendFile(req, res, path.join(CLIENT_DIR, 'index.html'), { noStore: true })) return;
    }

    const rel = url.pathname === '/' ? 'index.html' : url.pathname.replace(/^\/+/, '');
    /* لایهٔ نوشتنی: فایل‌هایی که «به‌روزرسانی» جای داده (وقتی پوشهٔ نصب فقط خواندنی است) */
    const over = safeJoin(OVERLAY_DIR, rel);
    if (over && fs.existsSync(over) && sendFile(req, res, over, { noStore: /\.(html|js|webmanifest)$/.test(rel) })) return;
    const file = safeJoin(CLIENT_DIR, rel);
    if (file && sendFile(req, res, file, { noStore: /\.(html|js|webmanifest)$/.test(rel) })) return;

    /* SPA fallback */
    if (sendFile(req, res, path.join(CLIENT_DIR, 'index.html'), { noStore: true })) return;
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }).end('not found');
  } catch (e) {
    const code = String(e.message || e) === 'body_too_large' ? 413 : 500;
    if (code === 500) console.error('[ERR]', url.pathname, e);
    if (!res.writableEnded) res.writeHead(code, { 'content-type': 'application/json; charset=utf-8' });
    if (!res.writableEnded) res.end(JSON.stringify({ ok: false, error: code === 413 ? 'body_too_large' : 'server_error' }));
  } finally {
    if (process.env.PAYESH_LOG !== '0') {
      const ms = Date.now() - started;
      if (ms > 300 || url.pathname.startsWith('/api/')) {
        console.log(`${req.method} ${url.pathname} ${res.statusCode} ${ms}ms`);
      }
    }
  }
});

/* پاک‌سازی دوره‌ای + بکاپ خودکار */
setInterval(() => { try { auth.prune(store); } catch (e) { /* noop */ } }, 60 * 60 * 1000).unref();
if (process.env.PAYESH_AUTO_BACKUP !== '0') {
  setInterval(() => {
    try { store.backupTo(BACKUP_DIR, 48); } catch (e) { console.error('[backup]', e.message); }
  }, 60 * 60 * 1000).unref();
  try { store.backupTo(BACKUP_DIR, 48); } catch (e) { /* noop */ }
}

/* ── آدرس موقتیِ نسخه‌های قدیمی: در شروع پاک می‌شود ── */
try {
  const purged = tunnel.purgeStalePublicUrl(store);
  if (purged.cleared) console.log('[network] آدرس موقت قدیمی پاک شد:', purged.url);
} catch (e) { /* بی‌خیال */ }

/* ── رمز گوشی: هیچ حسابی نباید «رمزِ گوشی ندارد» بماند ──
   • هر رمز PBKDF2 که هست، همان برای گوشی هم گذاشته می‌شود (همان رمز).
   • حسابی که هیچ رمزی ندارد و کد ملی دارد، رمزش کد ملی می‌شود.
   • رمزهای قدیمی scrypt فقط روی سیستم مدرسه کار می‌کنند؛ گوشی برای آن‌ها
     رمز نمی‌گیرد و مدیر از «ویرایش» رمز تازه می‌گذارد. */
try {
  const users = store.all('users') || [];
  let fixed = 0;
  for (const u of users) {
    const pwIsPbkdf2 = /^pbkdf2\$/.test(String(u.password_hash || ''));
    const phIsPbkdf2 = /^pbkdf2\$/.test(String(u.phone_hash || ''));
    const patch = {};
    if (pwIsPbkdf2 && !phIsPbkdf2) patch.phone_hash = u.password_hash;
    else if (!u.password_hash && !u.phone_hash) {
      const next = auth.applyDefaultCredentials(u);
      if (next.password_hash) { patch.password_hash = next.password_hash; patch.phone_hash = next.password_hash; }
    }
    if (Object.keys(patch).length) { store.update('users', u.id, patch); fixed++; }
  }
  if (fixed) console.log('[auth] رمز گوشی برای ' + fixed + ' حساب تنظیم شد');
} catch (e) {
  console.log('[auth] بررسی رمز گوشی ناموفق:', e.message);
}

/* ── صندوقچهٔ پیش‌فرض: در شروع نام صندوقچه را پیدا می‌کنیم و اجازهٔ CORS را
      هم خودکار می‌گذاریم — گوشی‌ها بدون هیچ کاری می‌توانند بخوانند/بنویسند. ── */
if (process.env.PAYESH_CLOUD_AUTO !== '0') {
  setTimeout(() => {
    s3mem.ensureBucket(store)
      .then(async c => {
        if (!c.bucket) return;
        console.log('[cloud] صندوقچه:', c.bucket, '·', c.endpoint);
        try {
          let probe = await s3mem.corsProbe(c);
          if (!probe.ok && probe.reachable) {
            await s3mem.setCors(c);
            probe = await s3mem.corsProbe(c);
            console.log('[cloud] اجازهٔ CORS خودکار تنظیم شد — ' + (probe.ok ? 'گوشی می‌تواند بخواند ✅' : 'هنوز نه ❌'));
          } else if (probe.ok) {
            console.log('[cloud] اجازهٔ گوشی از قبل باز است ✅');
          } else {
            console.log('[cloud] به صندوقچه نرسیدیم:', probe.detail || probe.error || '');
          }
        } catch (e) {
          console.log('[cloud] تنظیم CORS ناموفق:', e.message);
        }
      })
      .catch(e => console.log('[cloud] تشخیص صندوقچه ناموفق:', e.message));
  }, 2500).unref();
}

/* ── صندوقچهٔ آفلاین: اولین دستگاهی که روشن شود، ثبت‌های بقیه را اعمال می‌کند ── */
if (process.env.PAYESH_OUTBOX_AUTO !== '0') {
  outbox.start(store, { everyMs: Number(process.env.PAYESH_OUTBOX_EVERY_MS || 3 * 60_000) });
}

/* ── راه‌اندازی مجدد خودکار پس از آپدیت ───────────────────────────── */
function autoRestartEnabled() { return process.env.PAYESH_NO_RESTART !== '1'; }
let restarting = false;
function closeServerForRestart() {
  try { server.close(); } catch (e) { /* noop */ }
  try { if (server.closeAllConnections) server.closeAllConnections(); } catch (e) { /* noop */ }
  try { store.close(); } catch (e) { /* noop */ }
}

function scheduleRestart(reason) {
  if (restarting || !autoRestartEnabled()) return;
  restarting = true;
  console.log('[update] راه‌اندازی مجدد (' + reason + ')…');
  setTimeout(() => {
    closeServerForRestart();
    /* اگر «ناظر» (server/start.js) بالای سرِ ماست، خودش دوباره بالا می‌آورد.
       وگرنه خودمان یک نمونهٔ تازه اجرا می‌کنیم. */
    if (process.env.PAYESH_SUPERVISED === '1') {
      setTimeout(() => process.exit(75), 120);
      return;
    }
    setTimeout(() => {
      try {
        const { spawn } = require('child_process');
        const entry = require('path').resolve(process.argv[1] || 'server/index.js');
        const child = spawn(process.execPath, [entry].concat(process.argv.slice(2)), {
          cwd: process.cwd(), env: process.env, stdio: 'inherit', detached: true,
        });
        child.on('error', err => console.error('[update] اجرای مجدد ناموفق:', err.message));
        child.unref();
      } catch (e) {
        console.error('[update] اجرای مجدد ناموفق:', e.message);
      }
      setTimeout(() => process.exit(0), 250);
    }, 600);
  }, 120);
}

function lanAddresses() {
  const out = [];
  const ifs = os.networkInterfaces();
  for (const name of Object.keys(ifs)) {
    for (const a of ifs[name] || []) {
      if (a.family === 'IPv4' && !a.internal) out.push(a.address);
    }
  }
  return out;
}

let listenTries = 0;
server.on('error', err => {
  if (err && err.code === 'EADDRINUSE' && listenTries < 12) {
    listenTries++;
    console.log('[server] درگاه ' + PORT + ' هنوز آزاد نشده — تلاش ' + listenTries);
    setTimeout(() => server.listen(PORT, HOST), 500);
    return;
  }
  console.error('[server]', err && err.message);
});

server.listen(PORT, HOST, () => {
  const ips = lanAddresses();
  const mf = readManifest();
  console.log('');
  console.log('  پایش-لوکال  ·  نسخهٔ ' + mf.version);
  console.log('  ─────────────────────────────────────────');
  console.log('  آدرس روی همین سیستم : http://localhost:' + PORT);
  ips.forEach(ip => console.log('  آدرس در شبکهٔ مدرسه : http://' + ip + ':' + PORT));
  console.log('  داده               : ' + path.join(DATA_DIR, 'payesh.sqlite'));
  console.log('  بکاپ               : ' + BACKUP_DIR);
  console.log('  راه‌اندازی         : ' + (auth.needsSetup(store) ? 'انجام نشده — از مرورگر اول را انجام دهید' : 'انجام شده'));
  const pub = cfg.publicUrl(store);
  console.log('  آدرس عمومی (همه)   : ' + (pub || 'تنظیم نشده — پنل مدیر ← شبکه'));
  console.log('');
  /* تونل عمومی: اگر Tailscale Funnel روشن باشد، آدرس را برمی‌داریم */
  try { tunnel.start(store, { port: PORT }); } catch (e) { console.error('tunnel start failed', e.message); }

  /* همگام‌سازی زنده: هر ۱ ثانیه — تغییرها به حافظهٔ مشترک می‌روند و
     تغییرهای گوشی‌ها همان‌جا برداشته می‌شوند. */
  try { live.start(store, { everyMs: Number(process.env.PAYESH_LIVE_MS || live.INTERVAL_MS) }); } catch (e) { console.error('live start failed', e.message); }

  /* بررسی خودکار نسخهٔ منتشرشده (اگر «نصب خودکار» روشن باشد، خودش اعمال می‌کند) */
  try {
    update.start(store, {
      onApply: async (plan) => {
        const r = await update.apply(store, { force: false, by: 'auto' });
        if (r.ok && r.applied && r.restart) scheduleRestart('auto');
        return r;
      },
    });
  } catch (e) { console.error('update start failed', e.message); }
});

process.on('SIGINT', () => { store.close(); process.exit(0); });
process.on('SIGTERM', () => { store.close(); process.exit(0); });
